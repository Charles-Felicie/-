/* ============================================================
   Ward Aesthetics Program — Shared JS
   Unified storage + data model across charity / normal / admin
   ============================================================ */

/* ---------------- Storage (wa_ namespace) ---------------- */
const Store = {
  _mem: {},                       /* localStorage 不可用（本地双击打开 / 隐私模式）时的内存兜底 */
  get(k, d){
    try{
      const v = localStorage.getItem('wa_' + k);
      if(v !== null) return JSON.parse(v);
    }catch(e){ /* 读取失败则用内存兜底 */ }
    return Object.prototype.hasOwnProperty.call(this._mem, k) ? this._mem[k] : d;
  },
  set(k, v){
    this._mem[k] = v;
    try{ localStorage.setItem('wa_' + k, JSON.stringify(v)); }catch(e){ /* 写入失败不影响页面使用 */ }
  }
};
const $ = id => document.getElementById(id);

/* ---------------- Shared constants ---------------- */
/* Color numbers only (no product links / shopping disabled for now) */
const COLORS = [
  ['P01','#C9553A'],['P02','#E76F51'],['P03','#F4A261'],
  ['P04','#E9C46A'],['P05','#8A6F5C'],['P06','#5B4232'],
  ['P07','#D88C9A'],['P08','#A8DADC'],['P09','#6D6875'],
  ['P10','#84A59D'],['P11','#F2CC8F'],['P12','#3D405B'],
];
const RECOMMENDED = ['P01','P03','P04','P10'];
const GOODS = [
  ['🧴','lotion','润肤乳（公益装）'],['💄','lipstick','口红（爱心捐赠）'],
  ['🧼','soap','手工香皂'],['🎨','artkit','绘画材料包']
];
const MOODS = [
  ['happy','开心','😊','为你匹配元气橘调妆容'],
  ['calm','平静','😌','为你匹配清透裸妆'],
  ['tired','疲惫','😪','为你匹配温柔提气妆容'],
  ['anxious','紧张','😟','为你匹配舒缓大地色妆容'],
  ['excited','期待','🤩','为你匹配闪耀派对妆'],
  ['low','低落','😔','为你匹配暖色治愈妆'],
];

/* ---------------- Session ---------------- */
function getSession(){ return Store.get('session', null); }      // {type:'n'|'c', name}
function setSession(type, name){ Store.set('session', {type, name}); }
function clearSession(){ Store.set('session', null); }

/* ---------------- User accounts ---------------- */
function getUsers(type){ return Store.get('users_' + type, {}); }   // type: 'n' | 'c'
function saveUsers(type, u){ Store.set('users_' + type, u); }
function ensureUserObj(u){
  return Object.assign({avatar:null, follows:[], cart:[], delC:0, delW:0, nickname:''}, u);
}

/* ---------------- Works ---------------- */
function getWorks(type, name){ return Store.get('works_' + type + '_' + name, []); }
function saveWorks(type, name, list){ Store.set('works_' + type + '_' + name, list); }
/*
  work = {
    id, img, colors:[P01,...], time,
    sel: 'pending' | 'selected' | 'rejected',   // admin selection (normal works)
    gal: 1 | 0,                                  // gallery visibility (admin delete)
    likes: n, distId
  }
*/
function allWorks(type){
  const users = getUsers(type), out = [];
  Object.keys(users).forEach(name => {
    getWorks(type, name).forEach(w => out.push(Object.assign({}, w, {owner:name, type})));
  });
  return out;
}
function galleryWorks(){
  return allWorks('n').concat(allWorks('c')).filter(w => w.gal !== 0);
}
function updateWork(type, owner, id, patch){
  const list = getWorks(type, owner);
  const w = list.find(x => x.id === id);
  if(w){ Object.assign(w, patch); saveWorks(type, owner, list); }
  return w;
}

/* ---------------- Comments (gallery chat) ---------------- */
function getComments(){ return Store.get('comments', []); }
function saveComments(list){ Store.set('comments', list); }
/* {id, type:'n'|'c', user, text, time, del:0|1, workId?} */
function addComment(type, user, text, workId){
  const list = getComments();
  const c = {id:Date.now() + Math.floor(Math.random()*999), type, user, text, time:nowText(), del:0};
  if(workId != null) c.workId = workId;   /* 画廊墙按作品筛选评论时使用 */
  list.push(c); saveComments(list); return c;
}

/* ---------------- Records (likes / comments per user) ---------------- */
function getRecords(type, name){ return Store.get('records_' + type + '_' + name, []); }
function addRecord(type, name, rec){
  const list = getRecords(type, name);
  list.unshift(Object.assign({time:nowText()}, rec));
  Store.set('records_' + type + '_' + name, list);
}

/* ---------------- Distributions (admin selected -> charity) ---------------- */
function getDist(){ return Store.get('dist', []); }
function saveDist(list){ Store.set('dist', list); }
/*
  {id, workId, img, colors, painter, charity,
   status:'waiting'|'accepted'|'rejected', time,
   photo, thanks, replies:[{text,time}]}
*/
function addDistribution(work){
  const list = getDist();
  const charityUsers = Object.keys(getUsers('c'));
  if(!charityUsers.length) return null;
  const charity = charityUsers[Math.floor(Math.random()*charityUsers.length)];
  const d = {
    id:Date.now(), workId:work.id, img:work.img, colors:work.colors||[],
    painter:work.owner, charity,
    status:'waiting', time:nowText(),
    photo:null, thanks:null, replies:[]
  };
  list.push(d); saveDist(list);
  return d;
}

/* ---------------- Messages ---------------- */
function getMsgs(type, name){ return Store.get('msgs_' + type + '_' + name, []); }
function addMsg(type, name, m){
  const list = getMsgs(type, name);
  list.unshift(Object.assign({time:nowText(), read:false}, m));
  Store.set('msgs_' + type + '_' + name, list);
}

/* ---------------- Admin ---------------- */
function getAdmin(){
  return Store.get('admin', {user:'wardbeauty', pass:'123456', emp:'20266202', avatar:null});
}
function saveAdmin(a){ Store.set('admin', a); }

/* ---------------- Locale time ---------------- */
function nowText(){ return new Date().toLocaleString('zh-CN', {hour12:false}); }

/* ---------------- Helpers ---------------- */
const AVATAR_COLORS = ['#F4A261','#E76F51','#E9C46A','#84A59D','#A8DADC','#D88C9A','#8A6F5C','#6D6875'];
function avatarColor(name){
  let h = 0;
  for(const ch of String(name||'')) h = (h*31 + ch.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
function esc(s){
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function avatarHTML(user, img, cls){
  cls = cls || 'avatar-sm';
  if(img) return `<div class="${cls}"><img src="${img}" style="width:100%;height:100%;object-fit:cover"></div>`;
  return `<div class="${cls}" style="background:${avatarColor(user)}">${esc(String(user)[0]||'?')}</div>`;
}
function colorName(no){
  const c = COLORS.find(x => x[0] === no);
  if(c) return c[1];
  /* 色号素材库（S001…S113）也走这里取色 */
  const s = (typeof shadeById === 'function') ? shadeById(no) : null;
  return s ? s.hex : '#ccc';
}
function readImageFile(file){
  return new Promise(res => {
    const rd = new FileReader();
    rd.onload = e => res(e.target.result);
    rd.readAsDataURL(file);
  });
}

/* ---------------- Toast ---------------- */
let toastTimer;
function toast(msg){
  let el = $('toast');
  if(!el){
    el = document.createElement('div');
    el.id = 'toast'; el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1900);
}

/* ---------------- Modal ---------------- */
function openModal(title, bodyHTML, footHTML){
  closeModal();
  const mask = document.createElement('div');
  mask.className = 'modal-mask';
  mask.id = 'modalMask';
  mask.innerHTML =
    `<div class="modal-box">
       <div class="modal-head"><b></b><button class="btn btn-sm" id="modalClose">✕</button></div>
       <div class="modal-body"></div>
       <div class="modal-foot" style="${footHTML ? '' : 'display:none'}"></div>
     </div>`;
  document.body.appendChild(mask);
  mask.querySelector('.modal-head b').textContent = title;
  mask.querySelector('.modal-body').innerHTML = bodyHTML;
  if(footHTML) mask.querySelector('.modal-foot').innerHTML = footHTML;
  mask.addEventListener('click', e => { if(e.target === mask) closeModal(); });
  $('modalClose').onclick = closeModal;
  return mask;
}
function closeModal(){
  const m = $('modalMask');
  if(m) m.remove();
}

/* ---------------- Mini hash router ----------------
   Usage: Router.init({home:'me'}, {me:{el,enter}, ...}) */
const Router = {
  routes:{}, home:'',
  init(home, routes){
    this.home = home; this.routes = routes;
    window.addEventListener('hashchange', () => this.resolve());
    this.resolve();
  },
  current(){
    const h = location.hash.replace(/^#\/?/, '').split('?')[0];
    return h || this.home;
  },
  go(path){
    location.hash = '#/' + path;
    if(this.current() === path) this.resolve();
  },
  resolve(){
    const name = this.current();
    const r = this.routes[name] || this.routes[this.home];
    Object.values(this.routes).forEach(x => x.el.classList.remove('active'));
    r.el.classList.add('active');
    document.querySelectorAll('[data-route]').forEach(b =>
      b.classList.toggle('on', b.dataset.route === name));
    if(r.enter) r.enter();
    window.scrollTo(0,0);
  }
};

/* ============================================================
   【美妆作画板块扩展】—— 以下均为纯增量，不影响原有页面
   ① 颜色情绪说明（悬停 / 触摸气泡）
   ② 美妆笔刷引擎（5 支笔触 + 1 支橡皮）
   ③ 颜色工具函数
   ============================================================ */

/* ---------------- ① 颜色情绪说明数据 ----------------
   每个色号：情绪 Emotional / 意象 Imagery / 氛围 Atmosphere        */
const COLOR_MOOD = {
  P01:{name:'陶土砖红',emotion:'笃定 · 踏实',imagery:'秋日砖墙、陶土器皿、旧木桌',
       atmosphere:'沉稳厚重，像被午后阳光晒暖的陶器'},
  P02:{name:'珊瑚橘',emotion:'明朗 · 想要拥抱',imagery:'初熟的柿子、夕阳镶边的云',
       atmosphere:'温暖外放，靠近一点就觉得被照顾'},
  P03:{name:'杏子橘',emotion:'松弛 · 轻盈',imagery:'蜜桃绒皮、晨光里的薄纱',
       atmosphere:'柔软透亮，不喧哗的甜'},
  P04:{name:'暖阳黄',emotion:'期待 · 雀跃',imagery:'正午阳光、成熟的麦穗',
       atmosphere:'开阔明亮，像有人在门口喊你出去玩'},
  P05:{name:'可可棕',emotion:'安定 · 被包裹',imagery:'可可粉、旧书封皮、毛呢大衣',
       atmosphere:'安静的暖，适合用来安放情绪'},
  P06:{name:'深栗棕',emotion:'沉静 · 向内收',imagery:'深秋树影、浓咖啡与夜谈',
       atmosphere:'低调却有分量，是画面里可以依靠的底色'},
  P07:{name:'玫瑰粉',emotion:'柔软 · 被珍视',imagery:'初开的玫瑰、绒布玩偶',
       atmosphere:'甜而不腻，像有人轻轻握住你的手'},
  P08:{name:'雾青',emotion:'呼吸 · 平静',imagery:'清晨薄雾、浅海的浅滩',
       atmosphere:'清透微凉，帮情绪降一点温'},
  P09:{name:'灰紫',emotion:'沉静 · 留白',imagery:'暮色天空、干枯的薰衣草',
       atmosphere:'克制的温柔，适合独处时使用'},
  P10:{name:'灰绿',emotion:'安心 · 生长',imagery:'雨后苔藓、旧陶罐里的薄荷',
       atmosphere:'安静的生命力，不争不抢'},
  P11:{name:'奶油黄',emotion:'柔软 · 被治愈',imagery:'奶油蛋糕、洗旧的棉布',
       atmosphere:'甜甜的暖，像被毯子裹住'},
  P12:{name:'午夜蓝',emotion:'沉静 · 有力量',imagery:'深夜星空、静水深流',
       atmosphere:'深邃稳定，是画面里最有分量的收束'}
};
function colorMood(no){ return COLOR_MOOD[no] || null; }

/* ---------------- 颜色工具 ---------------- */
function hexA(hex, a){
  hex = String(hex || '#000').replace('#','');
  if(hex.length === 3) hex = hex.split('').map(c => c + c).join('');
  const n = parseInt(hex, 16);
  return 'rgba(' + ((n>>16)&255) + ',' + ((n>>8)&255) + ',' + (n&255) + ',' + a + ')';
}
function rgb2lab(r, g, b){
  const f = v => { v /= 255; return v > 0.04045 ? Math.pow((v+0.055)/1.055, 2.4) : v/12.92; };
  const R = f(r), G = f(g), B = f(b);
  let x = (R*0.4124 + G*0.3576 + B*0.1805) / 0.95047;
  let y = (R*0.2126 + G*0.7152 + B*0.0722);
  let z = (R*0.0193 + G*0.1192 + B*0.9505) / 1.08883;
  const q = t => t > 0.008856 ? Math.cbrt(t) : (7.787*t + 16/116);
  x = q(x); y = q(y); z = q(z);
  return [116*y - 16, 500*(x-y), 200*(y-z)];
}
function hex2lab(hex){
  hex = String(hex).replace('#','');
  if(hex.length === 3) hex = hex.split('').map(c => c + c).join('');
  const n = parseInt(hex, 16);
  return rgb2lab((n>>16)&255, (n>>8)&255, n&255);
}
/* 取最接近的色号（用于纹样/画布颜色归因，带缓存） */
const _nearestCache = {};
function nearestColorNo(hex){
  if(_nearestCache[hex]) return _nearestCache[hex];
  const L = hex2lab(hex);
  let best = COLORS[0][0], bd = 1e9;
  COLORS.forEach(([no, c]) => {
    const l = hex2lab(c);
    const d = Math.hypot(l[0]-L[0], l[1]-L[1], l[2]-L[2]);
    if(d < bd){ bd = d; best = no; }
  });
  _nearestCache[hex] = best;
  return best;
}

/* ---------------- ② 颜色气泡（悬停 / 触摸） ---------------- */
let _moodTip = null, _moodTimer = null, _moodHideT = null;
function ensureMoodTip(){
  if(_moodTip) return _moodTip;
  _moodTip = document.createElement('div');
  _moodTip.className = 'mood-tip';
  document.body.appendChild(_moodTip);
  /* 鼠标移到气泡上（例如去点「查看商品页」链接）时不收起 */
  _moodTip.addEventListener('mouseenter', () => { clearTimeout(_moodHideT); clearTimeout(_moodTimer); });
  _moodTip.addEventListener('mouseleave', scheduleMoodHide);
  return _moodTip;
}
/* 延迟收起：给鼠标留出从色块移到气泡的时间 */
function scheduleMoodHide(){
  clearTimeout(_moodHideT);
  _moodHideT = setTimeout(hideMoodTip, 280);
}
function paintMoodTip(html, anchor, interactive){
  const el = ensureMoodTip();
  el.innerHTML = html;
  el.classList.toggle('interactive', !!interactive);
  el.classList.add('show');
  /* 先显示再量尺寸，避免读到 0 */
  requestAnimationFrame(() => positionMoodTip(anchor));
}
function showMoodTip(no, anchor){
  if(!anchor) return;
  if(typeof shadeById === 'function'){
    const s = shadeById(no);
    if(s){ showShadeTip(s, anchor); return; }
  }
  const m = colorMood(no);
  if(!m) return;
  const c = colorName(no);
  paintMoodTip(
    '<div class="mood-tip-head"><i style="background:' + c + '"></i><b>' + no + ' · ' + m.name + '</b></div>' +
    '<div class="mood-tip-row"><span>情绪</span><em>' + m.emotion + '</em></div>' +
    '<div class="mood-tip-row"><span>意象</span><em>' + m.imagery + '</em></div>' +
    '<div class="mood-tip-row"><span>氛围</span><em>' + m.atmosphere + '</em></div>',
    anchor, false);
}
function positionMoodTip(anchor){
  if(!_moodTip || !anchor) return;
  const r = anchor.getBoundingClientRect();
  const t = _moodTip.getBoundingClientRect();
  const vw = window.innerWidth, vh = window.innerHeight;
  let left = r.left + r.width/2 - t.width/2;
  left = Math.max(10, Math.min(vw - t.width - 10, left));
  let top = r.top - t.height - 12;
  const above = top > 8;
  if(!above) top = Math.min(vh - t.height - 10, r.bottom + 12);
  _moodTip.style.left = left + 'px';
  _moodTip.style.top  = Math.max(8, top) + 'px';
  _moodTip.classList.toggle('below', !above);
}
function hideMoodTip(){ if(_moodTip) _moodTip.classList.remove('show'); }

/* 事件委托：任何带 data-no 的元素悬停/触摸都弹气泡，重渲染后依然有效 */
document.addEventListener('mouseover', e => {
  const el = e.target.closest && e.target.closest('[data-no]');
  if(el && el.dataset.no){ clearTimeout(_moodTimer); showMoodTip(el.dataset.no, el); }
});
document.addEventListener('mouseout', e => {
  const el = e.target.closest && e.target.closest('[data-no]');
  if(el && el.dataset.no) scheduleMoodHide();
});
document.addEventListener('touchstart', e => {
  const el = e.target.closest && e.target.closest('[data-no]');
  if(el && el.dataset.no){
    showMoodTip(el.dataset.no, el);
    clearTimeout(_moodTimer);
    _moodTimer = setTimeout(hideMoodTip, 2800);   /* 触摸：自动消失 */
  }
}, {passive:true});
window.addEventListener('scroll', hideMoodTip, true);
window.addEventListener('resize', hideMoodTip);
document.addEventListener('click', e => {
  if(!e.target.closest || !e.target.closest('.mood-tip')) hideMoodTip();
});

/* ---------------- ③ 美妆笔刷定义 ----------------
   size 基准直径 / spacing 盖章间距(占直径比) / flow 单次落笔不透明度
   hardness 边缘硬度(0 最柔 → 1 最锐) / scatter 粒子散布 / grain 粉质颗粒
   gloss 水光高光 / jitter 手抖感 / vThin 速度联动变细 / erase 擦除  */
const BRUSHES = [
  { id:'matte',  name:'哑光口红', icon:'💄', tip:'饱和厚实 · 粉绒质感',
    size:22, spacing:0.055, flow:0.96, hardness:0.86, grain:0.55 },
  { id:'glaze',  name:'水光唇釉', icon:'✨', tip:'通透果冻 · 水亮反光',
    size:19, spacing:0.045, flow:0.30, hardness:0.42, gloss:0.62 },
  { id:'blush',  name:'粉雾腮红', icon:'🌸', tip:'蓬松颗粒 · 雾面无边界',
    size:52, spacing:0.032, flow:0.048, hardness:0.02, scatter:0.55, scatterCount:10, grain:0.30 },
  { id:'liner',  name:'眼线液笔', icon:'🖋️', tip:'锐利干净 · 速度联动粗细',
    size:3.4, spacing:0.09, flow:1, hardness:1, vThin:0.55 },
  { id:'gel',    name:'眼线胶笔', icon:'🖊️', tip:'哑光绒感 · 有体积',
    size:8.5, spacing:0.05, flow:0.80, hardness:0.58, jitter:0.10, grain:0.34 },
  { id:'eraser', name:'橡皮擦',   icon:'🧽', tip:'擦除已绘制的内容',
    size:34, spacing:0.05, flow:1, hardness:0.45, erase:true }
];
function getBrush(id){ return BRUSHES.find(b => b.id === id) || BRUSHES[0]; }

/* ---------------- ③ 笔刷引擎 ----------------
   createBrushEngine(canvas, { bg, maxUndo, onPaint(color, brush), onStrokeEnd() })
   返回 { setBrush, setColor, setSize, undo, clear, reset, state, stampAt }   */
function createBrushEngine(canvas, opts){
  opts = opts || {};
  const ctx = canvas.getContext('2d');
  const S = {
    brush: BRUSHES[0],
    color: '#E76F51',
    sizeScale: 1,
    drawing: false,
    last: null,
    sm: null,
    carry: 0,
    lastTime: 0,
    undo: [],
    maxUndo: opts.maxUndo || 20,
    onPaint: opts.onPaint || function(){},
    onStrokeEnd: opts.onStrokeEnd || function(){},
    bg: opts.bg || '#ffffff'
  };

  function toLocal(e){
    const r = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - r.left) * (canvas.width / r.width),
      y: (e.clientY - r.top ) * (canvas.height / r.height)
    };
  }
  function snapshot(){
    try{
      S.undo.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
      if(S.undo.length > S.maxUndo) S.undo.shift();
    }catch(err){ /* 跨域画布忽略 */ }
  }
  function fillBg(){
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = S.bg;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  /* 单个笔点 */
  function dab(x, y, scale){
    const b = S.brush;
    const r = Math.max(0.6, b.size * S.sizeScale * (scale || 1) / 2);

    /* 橡皮：destination-out，只擦不画 */
    if(b.erase){
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.globalAlpha = 1;
      const eg = ctx.createRadialGradient(x, y, r * Math.min(0.95, b.hardness), x, y, r);
      eg.addColorStop(0, 'rgba(0,0,0,1)');
      eg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = eg;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
      ctx.restore();
      return;
    }

    ctx.save();
    ctx.globalAlpha = Math.min(1, b.flow);

    if(b.hardness >= 0.97){
      ctx.fillStyle = S.color;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
    }else{
      const inner = Math.max(0, r * b.hardness);
      const g = ctx.createRadialGradient(x, y, inner, x, y, r);
      g.addColorStop(0, hexA(S.color, 1));
      g.addColorStop(1, hexA(S.color, 0));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
    }

    /* 粉质颗粒：极淡的提亮点，制造"粉"的哑光颗粒 */
    if(b.grain){
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, b.flow * b.grain * 0.12);
      ctx.fillStyle = '#ffffff';
      const n = Math.max(2, Math.round(r * 0.45));
      for(let i = 0; i < n; i++){
        const a = Math.random() * 6.2832, d = Math.random() * r * 0.85;
        ctx.fillRect(x + Math.cos(a)*d, y + Math.sin(a)*d, 1, 1);
      }
      ctx.globalCompositeOperation = 'source-over';
    }

    /* 水光高光：左上偏移的白色反光点 */
    if(b.gloss){
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, b.gloss * 0.6);
      const hx = x - r*0.30, hy = y - r*0.34, hr = Math.max(0.8, r*0.44);
      const g2 = ctx.createRadialGradient(hx, hy, 0, hx, hy, hr);
      g2.addColorStop(0, 'rgba(255,255,255,.95)');
      g2.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(hx, hy, hr, 0, 6.2832); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.restore();
  }

  /* 一次"盖章"（含散布 / 手抖） */
  function stamp(x, y, scale){
    const b = S.brush;
    const r = b.size * S.sizeScale * (scale || 1) / 2;
    let jx = 0, jy = 0;
    if(b.jitter){
      const a = Math.random()*6.2832, d = Math.random()*r*b.jitter*2;
      jx = Math.cos(a)*d; jy = Math.sin(a)*d;
    }
    if(b.scatter){
      const n = b.scatterCount || 6;
      for(let i = 0; i < n; i++){
        const a = Math.random()*6.2832, d = Math.random()*r*b.scatter*1.7;
        dab(x + jx + Math.cos(a)*d, y + jy + Math.sin(a)*d, (scale||1) * (0.55 + Math.random()*0.75));
      }
    }else{
      dab(x + jx, y + jy, scale);
    }
  }

  /* 沿路径按间距连续盖章（carry 保证间距跨段连续） */
  function strokeTo(p, speed){
    const b = S.brush;
    if(!S.last){ S.last = p; S.carry = 0; return; }
    let scale = 1;
    if(b.vThin) scale = Math.max(0.32, 1 - b.vThin * Math.min(1, (speed || 0) / 26));
    const step = Math.max(0.7, b.size * S.sizeScale * b.spacing * Math.max(0.4, scale));
    const dx = p.x - S.last.x, dy = p.y - S.last.y;
    const dist = Math.hypot(dx, dy);
    if(dist < 0.02) return;
    const ux = dx/dist, uy = dy/dist;
    let d = S.carry;
    while(d <= dist){
      stamp(S.last.x + ux*d, S.last.y + uy*d, scale);
      d += step;
    }
    S.carry = d - dist;
    S.last = p;
  }
  function begin(p){
    snapshot();
    S.drawing = true;
    S.last = p; S.sm = {x:p.x, y:p.y}; S.carry = 0;
    S.lastTime = performance.now();
    stamp(p.x, p.y, 1);              /* 落笔即出效果 */
    S.onPaint(S.color, S.brush);     /* 一笔只回调一次，记录用色 */
  }
  function end(p){
    if(!S.drawing) return;
    if(p){ strokeTo(p, 0); }
    S.drawing = false; S.last = null; S.sm = null;
    S.onStrokeEnd();
  }

  canvas.addEventListener('pointerdown', e => {
    if(e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    try{ canvas.setPointerCapture(e.pointerId); }catch(err){}
    begin(toLocal(e));
  });
  canvas.addEventListener('pointermove', e => {
    if(!S.drawing) return;
    e.preventDefault();
    const p = toLocal(e);
    const k = 0.65;
    S.sm.x += (p.x - S.sm.x) * k;
    S.sm.y += (p.y - S.sm.y) * k;
    const now = performance.now();
    const dt = Math.max(1, now - S.lastTime);
    const speed = Math.hypot(S.sm.x - S.last.x, S.sm.y - S.last.y) / dt * 16;
    S.lastTime = now;
    strokeTo({x:S.sm.x, y:S.sm.y}, speed);
  }, {passive:false});
  canvas.addEventListener('pointerup', e => {
    try{ canvas.releasePointerCapture(e.pointerId); }catch(err){}
    end(toLocal(e));
  });
  canvas.addEventListener('pointercancel', () => end(null));

  return {
    state: S,
    setBrush(id){
      const b = getBrush(id);
      S.brush = b;
      canvas.style.cursor = 'crosshair';
      return b;
    },
    setColor(hex){ S.color = hex; },
    setSize(k){ S.sizeScale = Math.max(0.25, Math.min(3, k)); },
    undo(){
      const d = S.undo.pop();
      if(!d) return false;
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
      ctx.putImageData(d, 0, 0);
      S.onStrokeEnd();
      return true;
    },
    clear(){ snapshot(); fillBg(); S.onStrokeEnd(); },
    reset(){ S.undo.length = 0; fillBg(); S.onStrokeEnd(); }
  };
}

/* ============================================================
   ④ 色号素材库（六大品牌 · 113 个实测色号）
   数据来源：《六大品牌化妆品色号-潘通色卡对照汇总》
   每条色号都带产品线与官方商品页链接，供悬停气泡展示
   ============================================================ */
const SHADE_BRANDS = [
  { id:'YSL', cn:'圣罗兰', en:'YSL Beauty', site:'https://www.yslbeautycn.com/' },
  { id:'MAY', cn:'美宝莲', en:'Maybelline New York', site:'https://www.maybellinechina.com/' },
  { id:'ARMANI', cn:'阿玛尼', en:'Giorgio Armani Beauty', site:'https://www.giorgioarmanibeauty.cn/' },
  { id:'LOREAL', cn:'欧莱雅', en:'L\'Oréal Paris', site:'https://www.lorealparis.com.cn/' },
  { id:'LANCOME', cn:'兰蔻', en:'Lancôme', site:'https://www.lancome.com.cn/' },
  { id:'3CE', cn:'3CE', en:'3CE', site:'https://www.3cecosmetics.com/' },
];

const SHADE_LINES = [
  { id:'L01', b:'YSL', name:'圣罗兰纯口红「方管」Rouge Pur Couture', short:'纯口红「方管」', url:'https://www.yslbeauty.co.uk/makeup/lips/lipsticks/rouge-pur-couture/WW-51083YSL.html', src:'YSL Beauty 官网', note:'唇部试色照片为渐变无纯色块，颜色取自该色号官方色号图中的纯色背景色带（std<1）' },
  { id:'L02', b:'YSL', name:'圣罗兰高定皮革四色眼影盘 Couture Mini Clutch', short:'高定皮革四色眼影盘', url:'https://www.yslbeauty.com/int/makeup/eye/eyeshadow/couture-mini-clutch/WW-51079YSL.html', src:'YSL Beauty 官网', note:'四色盘单格纯色块（含细闪质地，取中位数颜色）' },
  { id:'L03', b:'YSL', name:'圣罗兰高定皮革腮红 Make Me Blush', short:'高定皮革腮红 Make Me Blush', url:'https://www.yslbeauty.com/int/makeup/face/powder/make-me-blush-bold-blurring-blush/WW-51348YSL.html', src:'YSL Beauty 官网', note:'腮红粉块条带中心均匀区域（避开文字与碎粉边缘）' },
  { id:'L04', b:'YSL', name:'圣罗兰眉笔 Dessin des Sourcils', short:'眉笔 Dessin des Sourcils', url:'https://www.yslbeauty.co.uk/makeup/eyes/brows/dessin-des-sourcils/171YSL.html', src:'YSL Beauty 官网', note:'' },
  { id:'L05', b:'MAY', name:'Super Stay Matte Ink 超持久哑光液体唇膏', short:'Super Stay Matte Ink 超持久哑光液体唇膏', url:'https://www.maybelline.com/lip-makeup/lipstick/superstay-matte-ink-liquid-lipstick/', src:'Maybelline 官网 · Super Stay Matte Ink', note:'' },
  { id:'L06', b:'MAY', name:'The City Mini Palette 城市迷你眼影盘', short:'The City Mini Palette 城市迷你眼影盘', url:'https://www.maybelline.com/eye-makeup/eyeshadow/the-city-mini-eyeshadow-palette', src:'Maybelline 官网', note:'盘内6格编号：1=左上宽格,2=左下,3=中下,4=中列竖格,5=右上,6=右下宽格（从左到右按列分组）' },
  { id:'L07', b:'MAY', name:'Fit Me 定制腮红', short:'Fit Me 定制腮红', url:'https://www.maybelline.com/face-makeup/blush-and-bronzer/fit-me-blush', src:'Maybelline 官网', note:'碎粉饼色卡，已避开文字与裂纹取纯块' },
  { id:'L08', b:'MAY', name:'Express Brow 2-in-1 双头眉笔', short:'Express Brow 2-in-1 双头眉笔', url:'https://www.maybelline.com/eye-makeup/eyebrow-makeup/express-brow-2-in-1-pencil-and-powder-eyebrow-makeup', src:'Maybelline 官网', note:'取自色号色样柱纯色区域' },
  { id:'L09', b:'ARMANI', name:'全新阿玛尼传奇「红管」', short:'阿玛尼传奇「红管」', url:'https://www.armanibeauty.com/makeup/lip-makeup/lipstick/lip-maestro/ww-00072-arm.html', src:'Armani Beauty 官网', note:'' },
  { id:'L10', b:'ARMANI', name:'权力 pro 持久丝绒哑光粉底液', short:'权力 Pro 持久丝绒哑光粉底液', url:'https://www.giorgioarmanibeauty-usa.com/makeup/foundation-makeup/liquid-foundation/power-fabric-foundation/A20177.html', src:'Armani Beauty 官网', note:'' },
  { id:'L11', b:'LOREAL', name:'欧莱雅白管口红 低饱和裸色系', short:'白管口红 低饱和裸色系', url:'https://search.jd.com/Search?keyword=%E6%AC%A7%E8%8E%B1%E9%9B%85%E7%99%BD%E7%AE%A1%E5%8F%A3%E7%BA%A2&enc=utf-8', src:'京东 · 欧莱雅自营旗舰店', note:'ΔE（参考）≈5.5 ｜ 口红膏体可见区域取中位数色' },
  { id:'L12', b:'LOREAL', name:'黑胖子气垫 无惧瑕疵', short:'黑胖子气垫 无惧瑕疵', url:'https://detail.tmall.com/item.htm?id=569393324376', src:'欧莱雅官方旗舰店 · 天猫', note:'' },
  { id:'L13', b:'LOREAL', name:'法式炫色 欧莱雅全新卓韵霜', short:'法式炫色 卓韵霜', url:'https://detail.tmall.com/item.htm?id=603887061525', src:'欧莱雅官方旗舰店 · 天猫', note:'' },
  { id:'L14', b:'LANCOME', name:'Blush Subtil 柔美腮红', short:'Blush Subtil 柔美腮红', url:'https://zh.lancome-usa.com/makeup/face-makeup/blushes-and-bronzers/blush-subtil-powder-blush/LAN357.html', src:'兰蔻官网（中文）', note:'' },
  { id:'L15', b:'LANCOME', name:'Idôle Goddess Dimension 单色眼影', short:'Idôle Goddess Dimension 单色眼影', url:'https://zh.lancome-usa.com/makeup/eye-makeup/eyeshadow-and-palettes/idole-goddess-dimension-mono-eyeshadow/01266-LAC.html', src:'兰蔻官网（中文）', note:'' },
  { id:'L16', b:'LANCOME', name:'Le Crayon Khôl 眼线笔', short:'Le Crayon Khôl 眼线笔', url:'https://zh.lancome-usa.com/makeup/eye-makeup/eye-liners-and-eye-pencils/le-crayon-khol-eyeliner-pencil/138847.html', src:'兰蔻官网（中文）', note:'' },
  { id:'L17', b:'LANCOME', name:'Le Stylo 防水眼线笔', short:'Le Stylo 防水眼线笔', url:'https://zh.lancome-usa.com/makeup/eye-makeup/eye-liners-and-eye-pencils/le-stylo-waterproof-eyeliner-pencil/00447-LAC.html', src:'兰蔻官网（中文）', note:'' },
  { id:'L18', b:'LANCOME', name:'Idôle Tint 液体眼影眼线', short:'Idôle Tint 液体眼影眼线', url:'https://zh.lancome-usa.com/makeup/eye-makeup/eyeshadow-and-palettes/idole-tint-liquid-eyeshadow-and-eyeliner/00878-LAC.html', src:'兰蔻官网（中文）', note:'' },
  { id:'L19', b:'3CE', name:'单色腮红', short:'单色腮红', url:'https://www.3cecosmetics.com/all-products/cheeks/blush/3ce-face-blush', src:'3CE 官网', note:'' },
  { id:'L20', b:'3CE', name:'九色眼影 Overtake 橘棕盘', short:'九色眼影 Overtake 橘棕盘', url:'https://www.3cecosmetics.com/all-products/eyes/eyeshadow/3ce-multi-eye-color-palette', src:'3CE 官网', note:'' },
  { id:'L21', b:'3CE', name:'九色眼影 SMOOTHER 深棕盘', short:'九色眼影 SMOOTHER 深棕盘', url:'https://www.3cecosmetics.com/all-products/eyes/eyeshadow/3ce-multi-eye-color-palette', src:'3CE 官网', note:'' },
  { id:'L22', b:'3CE', name:'九色眼影 OLIVE GROVE 青木绿盘', short:'九色眼影 OLIVE GROVE 青木绿盘', url:'https://www.3cecosmetics.com/all-products/eyes/eyeshadow/3ce-multi-eye-color-palette', src:'3CE 官网', note:'' },
  { id:'L23', b:'3CE', name:'方格单色眼影', short:'方格单色眼影', url:'https://www.3cecosmetics.com/all-products/eyes/eyeshadow/3ce-color-grid-eyeshadow', src:'3CE 官网', note:'' },
  { id:'L24', b:'3CE', name:'光环眼线液笔 My Ring Eye Liner', short:'光环眼线液笔', url:'https://www.3cecosmetics.com/all-products/eyes/eyeliner/3ce-my-ring-eye-liner', src:'3CE 官网 · My Ring Eye Liner', note:'' },
  { id:'L25', b:'3CE', name:'九色/方格眼影盘副色', short:'九色/方格眼影盘副色', url:'https://www.3cecosmetics.com/all-products/eyes/eyeshadow/3ce-multi-eye-color-palette', src:'3CE 官网', note:'' },
  { id:'L26', b:'', name:'基础色 Basic', short:'基础色', url:'', src:'', note:'为黄／绿／蓝／紫四色系补充的基础色，不单独对应产品' },
];

/* 色号：id / 所属产品线 / 色名 / HEX / Pantone 编号 / Pantone 名 / 质地 / ΔE / 单独备注 */
const SHADES = [
  ['S001', 'L01', 'NM 裸色缪斯', '#CD6655', '17-1444', 'ginger', '', null],
  ['S002', 'L01', 'N8 烟粉裸', '#C55257', '17-1545', 'cranberry', '', null],
  ['S003', 'L01', 'R1966 无法复刻的红棕', '#AC1E1A', '18-1551', 'aura-orange', '', 6.4, '唇部试色照片为渐变无纯色块，颜色取自该色号官方色号图中的纯色背景色带（std<1）；最近潘通色 ΔE≈6.4，匹配仅供参考'],
  ['S004', 'L01', 'O154 甜茶橘', '#D1392B', '18-1564', 'poinciana', '', null],
  ['S005', 'L02', '#710 午夜马提尼-1', '#DCBEB0', '14-1310', 'cameo-rose', '细闪', null],
  ['S006', 'L02', '#710 午夜马提尼-2', '#C28D77', '16-1422', 'cork', '细闪', null],
  ['S007', 'L02', '#710 午夜马提尼-3', '#6B4F4D', '18-1415', 'marron', '细闪', null],
  ['S008', 'L02', '#710 午夜马提尼-4', '#D1A88E', '15-1316', 'maple-sugar', '细闪', null],
  ['S009', 'L02', '#200 马拉喀什日落-1', '#F6D0B8', '12-0913', 'alesan', '细闪', null],
  ['S010', 'L02', '#200 马拉喀什日落-2', '#CB7763', '17-1341', 'tawny-orange', '细闪', null],
  ['S011', 'L02', '#200 马拉喀什日落-3', '#8F4A3B', '19-1245', 'arabian-spice', '细闪', null],
  ['S012', 'L02', '#200 马拉喀什日落-4', '#AE5443', '18-1536', 'hot-sauce', '细闪', null],
  ['S013', 'L03', '54 Berry Bang', '#CD6B7B', '17-1927', 'desert-rose', '', null],
  ['S014', 'L03', '37 Peachy Nude', '#EE8677', '16-1529', 'burnt-coral', '', null],
  ['S015', 'L03', '57 Coral Clash', '#F5AC9D', '14-1419', 'peach-pearl', '', null],
  ['S016', 'L03', '44 Nude Lavallière', '#B3838E', '16-1708', 'lilas', '', null],
  ['S017', 'L03', '42 Babydoll Pink', '#F7B0D7', '14-2710', 'lilac-sachet', '', 6.7, '腮红粉块条带中心均匀区域（避开文字与碎粉边缘）；最近潘通色 ΔE≈6.7，匹配仅供参考'],
  ['S018', 'L03', '69 Lavender Lust', '#F7F2F9', '11-4001', 'brilliant-white', '', null, '腮红粉块条带中心均匀区域（避开文字与碎粉边缘）；色号本身为极浅薰衣草白，接近白色'],
  ['S019', 'L04', 'N°2 深棕色', '#854627', '18-1244', 'ginger-bread', '', null, '色号色卡圆形色块（避开文字与笔身）'],
  ['S020', 'L04', 'N°4 灰棕色', '#8A7768', '17-0808', 'taupe-gray', '', null, '色号色卡圆形色块；注意图中标注文字为「灰白色」，文档正文记为「灰棕色」'],
  ['S021', 'L05', '05 Loyalist', '#DC7B6B', '16-1532', 'Crabapple', '', 4.1, 'ΔE=4.1'],
  ['S022', 'L05', '15 Lover', '#C75674', '17-1926', 'Fruit Dove', '', 2.2, 'ΔE=2.2'],
  ['S023', 'L05', '20 Pioneer', '#AB031C', '18-1659', 'Goji Berry', '', 4.8, 'ΔE=4.8'],
  ['S024', 'L05', '50 Voyager', '#721619', '19-1555', 'Red Dahlia', '', 5.6, 'ΔE=5.6'],
  ['S025', 'L05', '60 Poet', '#EE7E70', '16-1543', 'Fusion Coral', '', 5.5, 'ΔE=5.5'],
  ['S026', 'L05', '80 Ruler', '#9E2338', '19-1863', 'Scooter', '', 3.2, 'ΔE=3.2'],
  ['S027', 'L05', '120 Artist', '#BF1755', '18-1951', 'Love Potion', '', 1.9, 'ΔE=1.9'],
  ['S028', 'L05', '155 Savant', '#BA4152', '17-1641', 'Chrysanthemum', '', 3.9, 'ΔE=3.9'],
  ['S029', 'L05', '335 Hustler', '#AC2A29', '18-1555', 'Molten Lava', '', 3.1, 'ΔE=3.1'],
  ['S030', 'L05', '525 Vixen', '#47241E', '19-1317', 'Bitter Chocolate', '', 7.4, 'ΔE=7.4'],
  ['S031', 'L05', '285 Thrill Seeker', '#111612', '19-3911', 'Black Beauty', '', null, '近黑色号，测色时放宽暗部阈值'],
  ['S032', 'L06', 'Rooftop Bronzes-1', '#E2C8AA', '13-1010', 'Gray Sand', '', null],
  ['S033', 'L06', 'Rooftop Bronzes-2', '#D6B58E', '14-1122', 'Sheepskin', '', null],
  ['S034', 'L06', 'Rooftop Bronzes-3', '#926A4F', '18-1030', 'Thrush', '', null],
  ['S035', 'L06', 'Rooftop Bronzes-4', '#D6BEB1', '14-1210', 'Shifting Sand', '', null, '闪片格，std略高；盘内6格编号：1=左上宽格,2=左下,3=中下,4=中列竖格,5=右上,6=右下宽格（从左到右按列分组）'],
  ['S036', 'L06', 'Rooftop Bronzes-5', '#836952', '18-1018', 'Otter', '', null],
  ['S037', 'L06', 'Rooftop Bronzes-6', '#5E4B43', '19-0916', 'Rain Drum', '', null],
  ['S038', 'L06', 'Blushed Avenue-1', '#F2B59E', '14-1219', 'Peach Parfait', '', null],
  ['S039', 'L06', 'Blushed Avenue-2', '#C36C62', '17-1540', 'Apricot Brandy', '', null],
  ['S040', 'L06', 'Blushed Avenue-3', '#B06B69', '17-1520', 'Canyon Rose', '', null],
  ['S041', 'L06', 'Blushed Avenue-4', '#CB8968', '16-1332', 'Pheasant', '', null],
  ['S042', 'L06', 'Blushed Avenue-5', '#EA8D7C', '16-1529', 'Burnt Coral', '', null],
  ['S043', 'L06', 'Blushed Avenue-6', '#753553', '19-2430', 'Purple Potion', '', null],
  ['S044', 'L06', 'Diamond District-1', '#EDC6AD', '13-1114', 'Bellini', '', null],
  ['S045', 'L06', 'Diamond District-2', '#DBA9A1', '15-1515', 'Mellow Rose', '', null],
  ['S046', 'L06', 'Diamond District-3', '#6B3541', '19-1617', 'Burgundy', '', null],
  ['S047', 'L06', 'Diamond District-4', '#E6CAAE', '13-1010', 'Gray Sand', '', null, '金色大闪片格，std最高(约19)，颜色为中位数估计；盘内6格编号：1=左上宽格,2=左下,3=中下,4=中列竖格,5=右上,6=右下宽格（从左到右按列分组）'],
  ['S048', 'L06', 'Diamond District-5', '#AE8C7B', '16-1221', 'Roebuck', '', null],
  ['S049', 'L06', 'Diamond District-6', '#114143', '19-4914', 'Deep Teal', '', null],
  ['S050', 'L07', '10 Buff', '#B17960', '17-1430', 'Pecan Brown', '', null],
  ['S051', 'L07', '25 Pink', '#DEA898', '14-1316', 'Dusty Pink', '', null],
  ['S052', 'L07', '30 Rose', '#EC8878', '16-1529', 'Burnt Coral', '', null],
  ['S053', 'L07', '35 Coral', '#E89D80', '15-1333', 'Canyon Sunset', '', null],
  ['S054', 'L07', '45 Plum', '#C07671', '17-1524', 'Desert Sand', '', null],
  ['S055', 'L07', '55 Berry', '#BE6460', '18-1629', 'Faded Rose', '', null],
  ['S056', 'L08', '248 Light Blonde', '#C49A7E', '16-1331', 'Toast', '', null],
  ['S057', 'L08', '255 Soft Brown', '#744F3A', '18-1031', 'Toffee', '', null],
  ['S058', 'L08', '257 Medium Brown', '#684D3E', '18-1222', 'Cocoa Brown', '', null],
  ['S059', 'L08', '262 Black Brown', '#433832', '19-0840', 'Delicioso', '', null],
  ['S060', 'L09', '#100 绝色', '#C5645F', '18-1629', 'Faded Rose', '', 3.4, 'ΔE（参考）≈3.4 ｜ 唇部试色图中心区域取中位数色'],
  ['S061', 'L09', '#208 焦糖奶咖', '#C45B45', '17-1444', 'ginger', '', 5.7, 'ΔE（参考）≈5.7 ｜ 唇部试色图中心区域取中位数色'],
  ['S062', 'L09', '#214 暧昧', '#BE6057', '17-1540', 'Apricot Brandy', '', 2.8, 'ΔE（参考）≈2.8 ｜ 唇部试色图中心区域取中位数色'],
  ['S063', 'L09', '#520 粉纱', '#D25D60', '17-1644', 'Spiced Coral', '', 3.0, 'ΔE（参考）≈3.0 ｜ 唇部试色图中心区域取中位数色'],
  ['S064', 'L09', '#321 心动粉', '#C55E5C', '17-1644', 'Spiced Coral', '', 2.9, 'ΔE（参考）≈2.9 ｜ 唇部试色图中心区域取中位数色'],
  ['S065', 'L09', '#405 传奇番茄红', '#A93D2A', '18-1355', 'Rooibos Tea', '', 5.5, 'ΔE（参考）≈5.5 ｜ 唇部试色图中心区域取中位数色'],
  ['S066', 'L10', '#1.6 粉调一白', '#F9D3B9', '12-0913', 'alesan', '', 1.4, 'ΔE（参考）≈1.4 ｜ 粉底色带内部区域取中位数色'],
  ['S067', 'L10', '#1.5 中性一白', '#FCDFC7', '12-0911', 'Nude', '', 2.8, 'ΔE（参考）≈2.8 ｜ 粉底色带内部区域取中位数色'],
  ['S068', 'L10', '#2 黄调一白', '#F6DABB', '12-0911', 'Nude', '', 5.2, 'ΔE（参考）≈5.2 ｜ 粉底色带内部区域取中位数色'],
  ['S069', 'L10', '#3 粉调二白', '#F6CEB6', '12-0913', 'alesan', '', 1.0, 'ΔE（参考）≈1.0 ｜ 粉底色带内部区域取中位数色'],
  ['S070', 'L10', '#4.1 中性二白', '#F7CA9E', '13-1017', 'Almond Cream', '', 7.4, 'ΔE（参考）≈7.4 ｜ 粉底色带内部区域取中位数色'],
  ['S071', 'L10', '#5 中性健康色', '#ECB790', '13-1017', 'Almond Cream', '', 4.8, 'ΔE（参考）≈4.8 ｜ 粉底色带内部区域取中位数色'],
  ['S072', 'L11', '【木质奶杏】#195 冷奶杏', '#A6574A', '18-1536', 'hot-sauce', '', 6.5, 'ΔE（参考）≈6.5 ｜ 口红膏体可见区域取中位数色'],
  ['S073', 'L11', '【乌龙茶棕】#196 冷栗棕', '#954B43', '19-1245', 'arabian-spice', '', 4.2, 'ΔE（参考）≈4.2 ｜ 口红膏体可见区域取中位数色'],
  ['S074', 'L11', '【伯爵红茶】#197 冷赤豆', '#AA4C4C', '18-1633', 'Garnet Rose', '', 5.5],
  ['S075', 'L11', '【玫瑰粉棕】#198 冷粉棕', '#A24A47', '18-1633', 'Garnet Rose', '', 5.5],
  ['S076', 'L11', '【低饱冷粉】#199 冷美人', '#9E504D', '18-1633', 'Garnet Rose', '', 7.3, 'ΔE（参考）≈7.3 ｜ 口红膏体可见区域取中位数色'],
  ['S077', 'L12', '200+替换装 中性象牙白', '#FAE6DD', '12-1108', 'Dew', '', 5.6, 'ΔE（参考）≈5.6 ｜ 官方色号方块中心区域取中位数色'],
  ['S078', 'L12', '240+替换装 中性自然色', '#F3D4BC', '12-0913', 'alesan', '', 2.9, 'ΔE（参考）≈2.9 ｜ 官方色号方块中心区域取中位数色'],
  ['S079', 'L12', '300+替换装 暖调陶瓷白', '#F4DDC2', '12-0911', 'Nude', '', 5.2, 'ΔE（参考）≈5.2 ｜ 官方色号方块中心区域取中位数色'],
  ['S080', 'L12', '320+替换装 暖调象牙白', '#E5C2A5', '13-1015', 'Honey Peach', '', 2.6, 'ΔE（参考）≈2.6 ｜ 官方色号方块中心区域取中位数色'],
  ['S081', 'L13', '4.11号-赛博蓝黑【New】', '#11243B', '19-3911', 'Black Beauty', '', 20.6, 'ΔE（参考）≈20.6 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S082', 'L13', '4.21号-朋克烟紫【New】', '#311F4D', '19-2430', 'Purple Potion', '', 28.1, 'ΔE（参考）≈28.1 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S083', 'L13', '6.17号-橄榄茶棕', '#223532', '19-4914', 'Deep Teal', '', 9.3, 'ΔE（参考）≈9.3 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S084', 'L13', '6.73号-薄荷青棕', '#4D3A2B', '19-0840', 'Delicioso', '', 7.5, 'ΔE（参考）≈7.5 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S085', 'L13', '6.13号-榛果冷茶', '#493729', '19-0840', 'Delicioso', '', 6.6, 'ΔE（参考）≈6.6 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S086', 'L13', '6.41号-焦糖暖棕', '#523631', '19-1012', 'French Roast', '', 5.1, 'ΔE（参考）≈5.1 ｜ 模特发丝区域取深色像素中位数（受光线/发丝高光影响较大）'],
  ['S087', 'L14', 'Folie Rouge 暖调砖红', '#BC584A', '18-1536', 'hot-sauce', '哑光', 4.9, 'H=7° S=61% V=74% ｜ ΔE≈4.9 ｜ 哑光 ｜ 深邃砖红色调，复古浓烈，塑造富有故事感的面部气色兰蔻…'],
  ['S088', 'L14', 'Orange Phoria 橘子橙', '#D1815F', '16-1332', 'Pheasant', '缎光', 7.0, 'H=18° S=55% V=82% ｜ ΔE≈7.0 ｜ 缎光 ｜ 明亮橘子橙，鲜活热烈，塑造明媚富有朝气的面部色彩兰蔻…'],
  ['S089', 'L14', 'Pink Ôh La La 樱花粉', '#EAA1B6', '14-1911', 'candy-pink', '哑光', 2.3, 'H=343° S=31% V=92% ｜ ΔE≈2.3 ｜ 哑光 ｜ 柔和甜嫩樱花粉，超细粉末与肌肤相融，打造自然通透的少女元气红晕兰蔻…'],
  ['S090', 'L14', 'Berry Bisou 莓果紫', '#814656', '19-1617', 'Burgundy', '缎光', 8.2, 'H=344° S=46% V=51% ｜ ΔE≈8.2 ｜ 缎光 ｜ 浆果莓果调，冷调莓紫，丝滑上脸，朦胧浆果氛围感颊彩Lancôme…'],
  ['S091', 'L14', 'I don’t give a Fuchsia 紫玫红', '#C65775', '17-1926', 'Fruit Dove', '哑光', 0.9, 'H=344° S=56% V=78% ｜ ΔE≈0.9 ｜ 哑光 ｜ 浓郁玫紫红色，高显色妆效，演绎浓烈浪漫氛围感Lancôme…'],
  ['S092', 'L15', '05 Meteor Smoke 卡布奇诺棕', '#956756', '18-1030', 'Thrush', '哑光', 5.8, 'H=16° S=42% V=58% ｜ ΔE≈5.8 ｜ 哑光 ｜ 可可深棕，深邃大地，高晕染力，塑造眼部深邃轮廓感…'],
  ['S093', 'L15', '11 Sparking Comet 金棕色', '#755041', '18-1031', 'Toffee', '细闪', 3.7, 'H=17° S=44% V=46% ｜ ΔE≈3.7 ｜ 细闪 ｜ 纯粹金色碎闪，阳光鎏金棕，细碎闪耀打造眼部高光时刻Lancôme…'],
  ['S094', 'L15', '07 Midnight Eclipse 幻梦紫', '#A382C3', '14-2710', 'lilac-sachet', '珠光闪', 28.8, 'H=270° S=33% V=76% ｜ ΔE≈28.8 ｜ 珠光闪 ｜ 深紫珠光，暗夜幻梦紫调，打造神秘浪漫的暗夜氛围感眼眸Lancôme…'],
  ['S095', 'L15', '06 Nude Dusk 米杏色', '#D1BBAC', '14-1210', 'Shifting Sand', '哑光', 1.8, 'H=24° S=18% V=82% ｜ ΔE≈1.8 ｜ 哑光 ｜ 奶油米杏，温润柔和，作为画布般的柔和打底色调Lancôme…'],
  ['S096', 'L15', '12 Lunar Glow 冷月蓝', '#CDD1EB', '11-4001', 'brilliant-white', '虹彩细闪', 15.8, 'H=232° S=13% V=92% ｜ ΔE≈15.8 ｜ 虹彩细闪 ｜ 薄透冰蓝幻彩，月光冷调青蓝，朦胧幻彩打造冷调月光眼眸Lancôme…'],
  ['S097', 'L16', 'Black Coffee 黑咖啡棕', '#1C160F', '19-3911', 'Black Beauty', '缎光', 5.8, 'H=32° S=46% V=11% ｜ ΔE≈5.8 ｜ 缎光 ｜ 咖啡棕调，柔和不锐利，打造自然温柔的棕调眼线效果兰蔻…'],
  ['S098', 'L17', '02 NOIR INTENSE 纯黑', '#0D0B08', '19-3911', 'Black Beauty', '哑光炭黑', 4.8, 'H=36° S=38% V=5% ｜ ΔE≈4.8 ｜ 哑光炭黑 ｜ 浓黑哑光，顺滑精准勾勒眼线，锐利深邃，全天候防水持妆兰蔻…'],
  ['S099', 'L18', '10 Ruby Fever 深玫紫', '#4D1E2B', '19-1617', 'Burgundy', '液体缎光', 11.0, 'H=343° S=61% V=30% ｜ ΔE≈11.0 ｜ 液体缎光 ｜ 黑加仑深玫红紫，大气端庄，可做创意深玫紫眼线色彩兰蔻…'],
  ['S100', 'L19', 'ROSE BEIGE 蜜桃橘', '#DB988C', '16-1520', 'Lobster Bisque', '柔雾哑光', 4.8, 'H=9° S=36% V=86% ｜ ΔE≈4.8 ｜ 柔雾哑光 ｜ 裸桃子橙，毛茸茸蜜桃质感，柔和温暖元气氛围感颊彩3CE…'],
  ['S101', 'L19', 'DELECTABLE 草莓牛奶粉', '#F8A8B0', '14-1714', 'quartz-pink', '柔雾哑光', 1.4, 'H=354° S=32% V=97% ｜ ΔE≈1.4 ｜ 柔雾哑光 ｜ 鲜活浅粉果汁感，打造清透鲜活的少女颊彩，自然服帖持久上妆3CE…'],
  ['S102', 'L19', 'MISSING DAWN 朦胧紫', '#DBAEC9', '14-1911', 'candy-pink', '缎光', 11.2, 'H=324° S=21% V=86% ｜ ΔE≈11.2 ｜ 缎光 ｜ 明亮薰衣草紫，高级柔和氛围感冷调颊彩3CE…'],
  ['S103', 'L20', '橘棕主色', '#62280D', '18-1541', 'Brandy Brown', '哑光 + 珠光', 3.1, 'H=19° S=87% V=38% ｜ ΔE≈3.1 ｜ 哑光 + 珠光 ｜ 美拉德暖橘棕，层次丰富，演绎秋日落日温暖氛围感眼妆…'],
  ['S104', 'L20', '橘棕主色', '#BE805F', '16-1332', 'Pheasant', '哑光 + 珠光', 4.0, 'H=21° S=50% V=75% ｜ ΔE≈4.0 ｜ 哑光 + 珠光 ｜ 美拉德暖橘棕，层次丰富，演绎秋日落日温暖氛围感眼妆…'],
  ['S105', 'L20', '橘棕主色', '#B16F43', '16-1429', 'Sunburn', '哑光 + 珠光', 8.3, 'H=24° S=62% V=69% ｜ ΔE≈8.3 ｜ 哑光 + 珠光 ｜ 美拉德暖橘棕，层次丰富，演绎秋日落日温暖氛围感眼妆…'],
  ['S106', 'L20', '橘棕主色', '#E6AE7B', '13-1017', 'Almond Cream', '哑光 + 珠光', 12.0, 'H=29° S=47% V=90% ｜ ΔE≈12.0 ｜ 哑光 + 珠光 ｜ 美拉德暖橘棕，层次丰富，演绎秋日落日温暖氛围感眼妆…'],
  ['S107', 'L21', '栗棕', '#98715C', '18-1030', 'Thrush', '全哑光', 4.7, 'H=21° S=39% V=60% ｜ ΔE≈4.7 ｜ 全哑光 ｜ 大地深棕、冷炭灰，全哑光质地，打造沉稳深邃中性氛围感眼妆3CE…'],
  ['S108', 'L22', '橄榄墨绿 橄榄绿', '#887E52', '17-1038', 'Tigers Eye', '哑光', 12.1, 'H=49° S=40% V=53% ｜ ΔE≈12.1 ｜ 哑光 ｜ 暗调橄榄墨绿，森系沉静草木色彩，适配创意艺术向眼妆表达…'],
  ['S109', 'L23', '#CITRUS FOLD 10 鲜柠色 浅柠黄', '#F6E6BF', '13-1010', 'Gray Sand', '珠光闪', 11.2, 'H=43° S=22% V=96% ｜ ΔE≈11.2 ｜ 珠光闪 ｜ 清新柠檬鲜黄，明快灵动，为妆容注入鲜活元气感…'],
  ['S110', 'L23', '#MINT ZEST 02 猫薄荷 薄荷绿', '#84D3BE', '13-1107', 'Whisper Pink', '珠光闪', 33.7, 'H=164° S=37% V=83% ｜ ΔE≈33.7 ｜ 珠光闪 ｜ 雾感薄荷绿，冰凉夏意，塑造夏日氛围感眼妆…'],
  ['S111', 'L24', 'ASH LAVENDER 薰衣草紫', '#62404E', '19-1620', 'Huckleberry', '缎光', 6.6, 'H=335° S=35% V=38% ｜ ΔE≈6.6 ｜ 缎光 ｜ 暮紫调创意眼线，柔和梦幻，赋予眼妆浪漫想象空间3CE…'],
  ['S112', 'L25', '浅烟熏蓝', '#687C96', '18-1210', 'Driftwood', '', 20.4, 'H=214° S=31% V=59% ｜ ΔE≈20.4 ｜ —'],
  ['S113', 'L25', '冰川蓝', '#97A7DC', '14-2710', 'lilac-sachet', '', 33.3, 'H=226° S=31% V=86% ｜ ΔE≈33.3 ｜ —'],
  ['S114', 'L26', '晨曦黄', '#F7D24B', '', '', '', null, ''],
  ['S115', 'L26', '蜜柑黄', '#E8B84B', '', '', '', null, ''],
  ['S116', 'L26', '麦穗黄', '#D9A93B', '', '', '', null, ''],
  ['S117', 'L26', '奶油黄', '#F3E08A', '', '', '', null, ''],
  ['S118', 'L26', '蜂蜜黄', '#C7A34A', '', '', '', null, ''],
  ['S119', 'L26', '苔原绿', '#6FB98A', '', '', '', null, ''],
  ['S120', 'L26', '松针绿', '#4E9E6A', '', '', '', null, ''],
  ['S121', 'L26', '嫩芽绿', '#A8C68F', '', '', '', null, ''],
  ['S122', 'L26', '湖心绿', '#3F7F5C', '', '', '', null, ''],
  ['S123', 'L26', '苜蓿绿', '#8FBF7F', '', '', '', null, ''],
  ['S124', 'L26', '晴空蓝', '#4E7FD1', '', '', '', null, ''],
  ['S125', 'L26', '深海蓝', '#33569E', '', '', '', null, ''],
  ['S126', 'L26', '湖蓝', '#6C9BE0', '', '', '', null, ''],
  ['S127', 'L26', '晨雾蓝', '#9CC3EA', '', '', '', null, ''],
  ['S128', 'L26', '蓝莓蓝', '#2C4B8F', '', '', '', null, ''],
  ['S129', 'L26', '紫藤紫', '#8A6BC1', '', '', '', null, ''],
  ['S130', 'L26', '暮色紫', '#6B4A9E', '', '', '', null, ''],
  ['S131', 'L26', '薰衣草紫', '#B39BD8', '', '', '', null, ''],
  ['S132', 'L26', '桑葚紫', '#513A82', '', '', '', null, ''],
  ['S133', 'L26', '奥兰紫', '#A98BD1', '', '', '', null, ''],
  ['S134', 'L26', '基础灰', '#8E8E8E', '', '', '', null, ''],
];

/* ===== 每一种颜色，一句关于生命的诗（Prompt 第 7 条文案） ===== */
const SHADE_POEMS = {
  S001: "清晨第一口温热的牛奶，柔软地滑过舌尖，窗外的风也轻轻替新的一天翻开了第一页。",
  S002: "一朵被晨露吻过的玫瑰，指尖触到微凉的花瓣，连沉默也有了温柔的颜色。",
  S003: "壁炉里一簇安静的火，木香与暖意缓缓漫开，提醒我们，心中总有不肯熄灭的光。",
  S004: "午后剥开一颗熟透的橘子，清甜的香气忽然涌出来，把阳光也变成了可以尝到的滋味。",
  S005: "晚风吹过浅粉色的云，柔软的光落在掌心，连夜晚也藏着一场尚未说完的春天。",
  S006: "晒过太阳的木头，带着干燥而温暖的气息，轻轻触碰，便想起那些被岁月珍藏的拥抱。",
  S007: "雨后深褐色的泥土，湿润、沉静，悄悄托住一颗尚在生长的种子。",
  S008: "枫糖融进温热的牛奶，甜香缓缓升起，让每个平凡的早晨都值得期待。",
  S009: "日落前最后一缕杏色的光，轻轻抚过脸颊，把远方也照得温暖而明亮。",
  S010: "熟杏在阳光下裂开一道甜蜜的缝，果香四溢，仿佛整个夏天都在轻轻歌唱。",
  S011: "一锅慢慢熬开的香料茶，温厚的气息绕着屋檐，给归家的人留一盏灯。",
  S012: "落日亲吻大地时溅起的红，热烈得仿佛能听见心跳，催促每一颗种子勇敢向上。",
  S013: "玫瑰与莓果相遇时溢出的红，花香里带着果实的微酸，叫人重新相信生命的丰盛。",
  S014: "一颗柔软的桃子被阳光晒暖，绒毛轻触指尖，空气里满是夏日甜甜的呼吸。",
  S015: "珊瑚色的海面迎来第一道晨光，咸咸的海风拂过脸颊，世界又明亮了一些。",
  S016: "暮色里一枝淡紫的花，安静地散发幽香，让温柔拥有不必言说的力量。",
  S017: "樱花树下飘落的一片粉色花瓣，轻轻落在掌心，仿佛春天专程来赴一个约。",
  S018: "一小片薰衣草色的晨雾，清凉地贴近肌肤，远处的风正把新的故事送来。",
  S019: "森林深处的老树根，粗粝的纹理里藏着泥土的气息，稳稳地托住每一次向上的生长。",
  S020: "雨后石阶上薄薄的雾，清凉而安宁，让世界暂时慢下来，听一听自己的呼吸。",
  S021: "秋日咬开的海棠果，酸甜的汁水漫上舌尖，清亮的风正穿过枝头。",
  S022: "鸽子掠过粉色的天空，翅膀带起轻柔的风，远方有人把思念折成一封信。",
  S023: "枝头熟透的枸杞，酸甜中藏着鲜活的生命力，仿佛每一粒果实都在悄悄发光。",
  S024: "深红的大丽花迎风舒展，花瓣层层叠叠，风穿过花园时，带来远行的勇气。",
  S025: "珊瑚礁旁跃起的一束阳光，海水清凉，浪花轻响，连沉睡的鱼群也开始舞蹈。",
  S026: "一颗红莓落进清晨的溪水，鲜明的颜色随着水波荡开，把小小的欢喜送向远方。",
  S027: "石榴籽在唇齿间迸出酸甜，鲜亮的果汁里藏着热烈的心愿。",
  S028: "秋日菊花迎着风摇曳，淡淡的草木香里，有一种不慌不忙的坚韧。",
  S029: "火山岩缝间升起的一抹红，带着炽热的温度，告诉世界，生命从不缺少重新开始的力量。",
  S030: "一块微苦的黑巧克力在舌尖慢慢融化，浓郁的香气过后，留下温厚而悠长的甜。",
  S031: "夜空最深处的黑，安静地拥抱万千星光，让每一个尚未抵达的梦都有地方安放。",
  S032: "沙滩上被晨光照亮的细沙，指间流过微凉的颗粒，海浪正轻轻唤醒远方。",
  S033: "阳光晒暖的羊毛毯，柔软地裹住肩头，空气里有晒过棉布的干净气息。",
  S034: "林间鸟雀停驻的树枝，木香沉稳，枝叶摇动时，传来轻轻的啁啾。",
  S035: "黄昏里流动的沙丘，细碎的光在指尖闪烁，每一粒沙都记得风曾来过。",
  S036: "河边被水浸润的石头，温润而沉静，水声绕过它，继续奔向广阔的天地。",
  S037: "雨滴落在深色屋瓦上，一声一声敲出安稳的节奏，让心在雨声里慢慢舒展。",
  S038: "桃子奶油在舌尖化开，甜香轻盈，连空气都变得像一场柔软的梦。",
  S039: "熟杏被暖阳晒出蜜意，指尖沾上一点果香，便想起夏天悠长的午后。",
  S040: "山谷间一朵被风吹红的野玫瑰，带着泥土的气息，倔强地把花开给世界。",
  S041: "秋日林间的落叶与鸟羽，踩过松软的泥土，听见生命在寂静中轻轻走动。",
  S042: "夕阳把珊瑚染成暖橘色，海风咸咸地吹来，浪花捎来远方的问候。",
  S043: "紫色浆果浸入一杯幽香的果茶，微酸之后泛起甘甜，像藏在夜色里的小小奇迹。",
  S044: "一杯桃杏色的气泡饮料，清甜的果香随着细小气泡升起，阳光在杯沿闪闪发亮。",
  S045: "一朵刚刚舒展的柔粉玫瑰，花瓣轻薄，微风经过时，留下淡淡的甜香。",
  S046: "葡萄酒色的浆果在枝头熟成，浓郁的香气里，藏着时间慢慢酿出的温柔。",
  S047: "一把撒在晨光里的细金砂，轻轻晃动便有星光落下，仿佛快乐也有了声音。",
  S048: "林间鹿影掠过暖褐色的树丛，草叶带着露水，远处的森林安静而丰饶。",
  S049: "深海与青绿森林交会的地方，潮汐低声呼吸，万物在看不见的深处蓄积力量。",
  S050: "碧根果外壳的温暖棕色，带着坚果的醇香，仿佛大地将丰收轻轻放在掌心。",
  S051: "一朵被薄雾包裹的粉玫瑰，柔软的花香在清晨散开，连时间也放轻了脚步。",
  S052: "玫瑰与珊瑚交换了一个吻，花香混着海风，给每一次呼吸添上一点明亮。",
  S053: "峡谷尽头燃烧的晚霞，暖风拂过岩壁，天空正把一天的故事说给大地听。",
  S054: "沙漠边缘熟透的李子，酸甜的气息与干燥的风交织，荒野里也有丰盈的果实。",
  S055: "一颗覆着薄霜的莓果，微酸的滋味唤醒舌尖，深处仍藏着温柔的甜。",
  S056: "刚出炉的浅色吐司，麦香暖暖地飘在空气里，普通的清晨也有值得期待的味道。",
  S057: "太妃糖在温热的锅里慢慢融化，甜香绕着厨房，让人想起有人等你回家。",
  S058: "可可豆被轻轻研磨，醇厚的香气从掌心升起，带着踏实而宁静的力量。",
  S059: "深烘咖啡落下最后一滴浓香，苦与甜在舌尖相遇，清醒的心又有了出发的勇气。",
  S060: "一朵在风里轻轻摇曳的旧玫瑰，花香沉静而绵长，仿佛温柔从来不需要大声宣告。",
  S061: "焦糖落进一杯热咖啡，甜香与微苦缓缓交融，掌心捧着暖意，日子便有了回甘。",
  S062: "熟杏与晚风交换了秘密，果香若有若无，心里却悄悄开出一朵花。",
  S063: "粉色薄纱接住了落日的光，轻盈地拂过脸颊，连呼吸也染上温柔的暖意。",
  S064: "第一次尝到草莓时涌起的甜，心跳悄悄加快，仿佛春天正从胸口发芽。",
  S065: "阳光下刚摘下的番茄，果皮饱满，酸甜清新，带着菜园里鲜活的泥土气息。",
  S066: "晨光落在一片杏花白的云上，轻轻柔柔地照亮肌肤，也照亮心里未说出口的愿望。",
  S067: "一张被阳光晒暖的白纸，干净、柔软，等待每一个新的故事落笔。",
  S068: "蜂蜜滴进温牛奶，甜润的香气缓缓升起，平凡的日子也有了金色的暖意。",
  S069: "清晨第一朵粉杏花映在水面，微风掠过，花影轻轻摇晃，生命正安静地舒展。",
  S070: "杏仁奶油在舌尖化开，细腻而温润，仿佛被世界轻轻接住。",
  S071: "阳光晒过的小麦与杏仁，带着饱满的谷物香，踏实地盛放着大地的生命力。",
  S072: "杏仁木被暖阳晒出淡淡香气，指腹掠过细腻的木纹，仿佛摸到了时光温柔的肌理。",
  S073: "一盏刚泡开的乌龙茶，茶香微涩，热气轻轻拂面，生活的滋味在唇齿间慢慢舒展。",
  S074: "伯爵茶遇见熟透的红豆，清雅的茶香里浮起一丝甜，有人在漫长的午后递来一颗糖。",
  S075: "玫瑰花瓣落入温热的红茶，花香沉静，茶味绵长，温柔有了可以触摸的形状。",
  S076: "薄雾中一枝冷粉色的花，露水沿着花瓣滑落，清凉的风里仍有不肯凋谢的春意。",
  S077: "清晨窗台上一滴晶莹的露水，触之微凉，映着天光，把希望藏进透明的闪烁里。",
  S078: "阳光晒暖的杏仁与麦穗，柔和的香气里有大地的踏实，也有日子缓慢成熟的甜。",
  S079: "一只盛着温水的白瓷杯，掌心感受到细腻的暖，安静里也有生活的回声。",
  S080: "蜜桃色的晨光洒在白色窗帘上，轻轻晃动的光影里，连空气都带着甜甜的暖意。",
  S081: "深夜海面映着远处的蓝色星光，风吹过时浪声低沉，而每颗星都在为远航的人指路。",
  S082: "暮色里升起的一缕紫烟，带着雨后花园的湿润气息，把尚未实现的梦悄悄送向天空。",
  S083: "橄榄树下泡开的一杯茶，叶片带着清苦的草木香，微风经过，森林正缓缓呼吸。",
  S084: "薄荷叶被指尖轻轻揉碎，清凉的香气直抵鼻尖，仿佛夏日的溪水从心间流过。",
  S085: "榛果落进一杯冷茶，坚果的醇香与茶叶的清气相遇，让宁静也拥有悠长的回味。",
  S086: "焦糖在锅里慢慢熬出琥珀色，甜香包裹着整个厨房，幸福原来可以如此具体。",
  S087: "砖墙边盛开的红花，被阳光晒得暖暖的，花香混着泥土气息，藏着历经风雨仍然盛放的力量。",
  S088: "刚剥开的橘子，汁水在指间闪亮，清新的果香一下子填满房间，连心情也跟着跳起舞来。",
  S089: "樱花落进春天的掌心，柔软的花瓣带着淡淡清香，风一吹，整个世界都轻盈起来。",
  S090: "紫莓在舌尖轻轻破开，酸甜的汁液染亮味蕾，深色的果实也有明亮的灵魂。",
  S091: "玫瑰与莓果共同酿出的一场盛宴，花香浓烈，果味鲜明，每一瓣都在认真地活着。",
  S092: "卡布奇诺表面细密的奶泡，咖啡香温厚地漫开，让忙碌的世界暂时停在一口温暖里。",
  S093: "金色流星划过暖棕色的夜空，微光闪烁，仿佛每一次抬头，都能重新遇见星星。",
  S094: "紫色的梦落在午夜的湖面，水波泛着幽微的光，远处的月亮正把秘密说给星辰听。",
  S095: "黄昏时一捧温热的杏仁，带着淡淡的谷物香，安稳而柔和，一句轻轻说出的“我在这里”。",
  S096: "月光落进清澈的冰湖，凉意轻轻贴近指尖，湖底仍有星光，为每一个梦留着位置。",
  S097: "一杯浓咖啡在清晨升起热气，微苦的香气里藏着甘甜，安静地陪伴每一次新的开始。",
  S098: "深夜无边的天幕，静静承接星星的闪耀，让所有尚未说出口的愿望都有了归处。",
  S099: "黑加仑与深玫瑰在暮色里相遇，果香幽深，花瓣柔软，仿佛沉静的心也能盛开一场热烈的春天。",
  S100: "一颗刚从枝头摘下的蜜桃，绒毛轻蹭指尖，甜甜的果香里，藏着阳光晒过的温度。",
  S101: "草莓落进一杯冰凉的牛奶，酸甜在舌尖化开，清新的香气里，春天正踮起脚尖走来。",
  S102: "黎明时分浮在花园上的淡紫薄雾，带着露水的清凉，轻轻吻过每一片刚苏醒的叶子。",
  S103: "秋日篝火映红了树梢，木柴的香气在空气里旋转，温暖的火光正邀请生命尽情舒展。",
  S104: "秋日熟果的橘棕外皮，指尖一碰便留下阳光的温度，果香把丰收写进每一个平凡的日子。",
  S105: "落日把大地染成暖棕色，风掠过金黄的草丛，带着青草与泥土混合的气息奔向远方。",
  S106: "杏仁浸在温暖的奶油里，淡淡的坚果香缓缓散开，仿佛世界递来一封柔软的信。",
  S107: "栗子从秋叶间滚落，外壳粗糙而坚实，剥开之后，里面藏着温热、绵软的甜。",
  S108: "古老橄榄树的叶影落在大地上，风穿过枝头发出细碎的沙沙声，绿色的生命从不急着回答时间。",
  S109: "柠檬被轻轻切开，清冽的香气瞬间迸发，酸甜的阳光从舌尖一路照亮心房。",
  S110: "一片薄荷叶浸入清凉的溪水，凉意顺着指尖蔓延，夏天也因此变得透明而轻盈。",
  S111: "黄昏的薰衣草田被晚风轻轻抚过，淡淡的花香浮在空气里，远方的星星正一颗颗亮起。",
  S112: "海雾笼罩着被潮水打磨的木头，咸湿的风穿过指缝，海浪把远方的消息轻轻送来。",
  S113: "冰川融水映着清晨的天空，凉凉的水声流过耳畔，晶莹的光里，藏着春天终将抵达的约定。",
  S114: "清晨第一缕阳光落在窗台，暖意慢慢摊开，新的一天便有了明亮的底色。",
  S115: "剥开一颗蜜柑，甜香随着果皮绽开，连风都染上了一点雀跃。",
  S116: "成熟的麦田在风里起伏，沉甸甸的谷粒低头，把四季的等待酿成金色。",
  S117: "一勺奶油在热吐司上融化，柔软的甜香里，藏着被好好照顾的安心。",
  S118: "蜂巢深处慢慢酿成的琥珀，甜得踏实，让每一次呼吸都慢下来。",
  S119: "石缝里的苔藓安静生长，潮湿的绿意在指尖蔓延，生命从不惧怕角落。",
  S120: "松针上挂着清晨的露水，林间的空气清冽，脚步也跟着轻快起来。",
  S121: "一颗种子顶开泥土，蜷曲的嫩芽伸向光，柔弱里藏着整个春天。",
  S122: "湖心沉着一片安静的绿，水波轻轻荡开，把喧嚣都推得很远。",
  S123: "苜蓿在草场上铺成柔软的毯，风一过，绿色的浪就一层层跑向天边。",
  S124: "正午的天空蓝得没有一丝犹豫，云被风吹散，心也跟着开阔起来。",
  S125: "深海在寂静中呼吸，光从很远的地方落下来，那里也有生命在发光。",
  S126: "雨后的湖面映着晴空，凉润的风掠过睫毛，把烦恼洗得干干净净。",
  S127: "薄雾浮在清晨的河面，天光一点点透出来，世界正慢慢醒来。",
  S128: "一粒蓝莓在齿间裂开，酸甜的汁水漫开，小小的果实也有饱满的力量。",
  S129: "紫藤垂在旧墙边，一串串花影轻轻晃，把时间摇成了缓慢的诗。",
  S130: "日落之后天空留下的那抹紫，温柔地合上一天，也替明天留了盏灯。",
  S131: "薰衣草田在风里起伏，香气贴着皮肤走，烦躁的心也因此变得轻盈。",
  S132: "桑葚在掌心染出深紫，甜里带一点涩，是夏日最认真的味道。",
  S133: "紫罗兰开在窗边，安静地香着，有些美好从不需要被大声说出。",
  S134: "灰色是所有颜色的休止符，也是黎明到来前，世界温柔的呼吸。",
};
/* ===== 色系显式归类（Prompt 第 6 条：修正错乱的分类，优先于 HSV 自动归类） ===== */
const SHADE_FAMILY_OVERRIDE = {
  S001: '橙',
  S007: '黑',
  S010: '橙',
  S011: '黑',
  S012: '橙',
  S015: '橙',
  S016: '紫',
  S017: '红',
  S019: '黑',
  S021: '橙',
  S022: '红',
  S025: '橙',
  S027: '红',
  S030: '黑',
  S032: '橙',
  S033: '橙',
  S034: '橙',
  S035: '橙',
  S037: '黑',
  S038: '橙',
  S039: '橙',
  S040: '橙',
  S041: '橙',
  S044: '橙',
  S045: '橙',
  S046: '紫',
  S047: '橙',
  S050: '橙',
  S051: '橙',
  S052: '橙',
  S053: '橙',
  S054: '橙',
  S055: '橙',
  S057: '黑',
  S058: '黑',
  S059: '黑',
  S060: '橙',
  S061: '橙',
  S062: '橙',
  S065: '橙',
  S072: '橙',
  S073: '橙',
  S084: '黑',
  S085: '黑',
  S086: '黑',
  S089: '红',
  S091: '红',
  S093: '黑',
  S100: '橙',
  S103: '黑',
  S108: '绿',
  S109: '黄',
  S114: '黄',
  S115: '黄',
  S116: '黄',
  S117: '黄',
  S118: '黄',
  S119: '绿',
  S120: '绿',
  S121: '绿',
  S122: '绿',
  S123: '绿',
  S124: '蓝',
  S125: '蓝',
  S126: '蓝',
  S127: '蓝',
  S128: '蓝',
  S129: '紫',
  S130: '紫',
  S131: '紫',
  S132: '紫',
  S133: '紫',
};

const SHADE_MAP = {}, SHADE_LINE_MAP = {}, SHADE_BRAND_MAP = {}, SHADE_BY_LINE = {};
SHADE_BRANDS.forEach(b => { SHADE_BRAND_MAP[b.id] = b; });
SHADE_LINES.forEach(l => {
  l.brand = SHADE_BRAND_MAP[l.b] || null;
  SHADE_LINE_MAP[l.id] = l;
  SHADE_BY_LINE[l.id] = [];
});
Object.assign(SHADE_FAMILY_OVERRIDE, {
  /* 【Prompt 2026-10-15】归入红色 */ S001:'红', S012:'红', S021:'红', S025:'红', S010:'红',
  S060:'红', S061:'红', S062:'红', S065:'红', S072:'红', S073:'红', S051:'红', S052:'红',
  S055:'红', S038:'红', S039:'红', S045:'红',
  /* 归入棕色 */ S005:'棕', S006:'棕', S007:'棕', S008:'棕', S009:'棕', S011:'棕',
  S019:'棕', S020:'棕', S032:'棕', S033:'棕', S034:'棕', S035:'棕', S036:'棕', S037:'棕',
  S041:'棕', S047:'棕', S048:'棕', S056:'棕', S057:'棕', S058:'棕', S059:'棕', S084:'棕',
  S085:'棕', S086:'棕', S093:'棕', S104:'棕', S105:'棕', S106:'棕', S107:'棕',
  /* 归入紫色 */ S040:'紫', S054:'紫',
  /* 黑色系新增基础灰 */ S134:'黑'
});
SHADES.forEach(row => {
  const s = {
    id: row[0], line: row[1], name: row[2], hex: row[3],
    pantone: row[4], pantoneName: row[5],
    finish: row[6] || '', dE: (row[7] === null || row[7] === undefined) ? null : row[7],
    note: row[8] || '',
    poem: SHADE_POEMS[row[0]] || ''
  };
  s.lineObj = SHADE_LINE_MAP[s.line] || null;
  SHADE_MAP[s.id] = s;
  (SHADE_BY_LINE[s.line] = SHADE_BY_LINE[s.line] || []).push(s);
});

/* ===== 九大色系（红橙黄绿蓝紫黑灰白）：按 HSV 自动归类，青调并入绿色系 ===== */
const SHADE_FAMILY_ORDER = ['红', '橙', '黄', '绿', '蓝', '紫', '棕', '黑', '白'];
function colorFamilyOf(hex){
  const r = parseInt(hex.slice(1, 3), 16) / 255,
        g = parseInt(hex.slice(3, 5), 16) / 255,
        b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  const v = max, s = max ? d / max : 0;
  if(v < 0.18) return '黑';
  if(s < 0.14){ return v > 0.82 ? '白' : (v > 0.42 ? '灰' : '黑'); }
  let h;
  if(max === r) h = 60 * (((g - b) / d) % 6);
  else if(max === g) h = 60 * ((b - r) / d + 2);
  else h = 60 * ((r - g) / d + 4);
  if(h < 0) h += 360;
  if(h < 15 || h >= 345) return '红';
  if(h < 45) return '橙';
  if(h < 70) return '黄';
  if(h < 200) return '绿';
  if(h < 255) return '蓝';
  return '紫';
}
/* 归类索引：SHADE_BY_FAMILY[色系] = [色号对象…]（保持素材库顺序） */
const SHADE_BY_FAMILY = {};
SHADE_FAMILY_ORDER.forEach(f => { SHADE_BY_FAMILY[f] = []; });
Object.keys(SHADE_MAP).sort().forEach(id => {
  const s = SHADE_MAP[id];
  s.family = SHADE_FAMILY_OVERRIDE[s.id] || colorFamilyOf(s.hex);   /* 人工归类优先 */
  /* 素材库试色图；基础色（S114+）无产品图，气泡里改渲染色块 */
  s.img = (s.line === 'L26') ? '' : ('assets/shades/' + s.id + '.png');
  (SHADE_BY_FAMILY[s.family] = SHADE_BY_FAMILY[s.family] || []).push(s);
});
function shadeCountOfFamily(fam){
  if(!fam || fam === 'ALL') return SHADES.length;
  return (SHADE_BY_FAMILY[fam] || []).length;
}

function shadeById(id){ return SHADE_MAP[id] || null; }
function shadeCountOfBrand(brandId){
  return shadeLinesOf(brandId).reduce((n, l) => n + (SHADE_BY_LINE[l.id] || []).length, 0);
}
function shadeLinesOf(brandId){
  if(!brandId || brandId === 'ALL') return SHADE_LINES.slice();
  return SHADE_LINES.filter(l => l.b === brandId);
}
/* 该色号的官方商品页；没有精确商品页时退回品牌官网 */
function hostOf(u){ return String(u || '').replace(/^https?:\/\//, '').split('/')[0].toLowerCase(); }
/* 一个色号可能给出两条入口：
   ① 精确商品页（该色号所属产品线的官方页面）
   ② 品牌中国官网（与商品页不同源时补充，便于国内网络访问） */
function shadeLinks(s){
  const l = s.lineObj, b = l && l.brand;
  const out = [];
  if(l && l.url) out.push({ url: l.url, label: l.src || '官方商品页', primary: true });
  if(b && b.site && (!out.length || hostOf(out[0].url) !== hostOf(b.site))){
    out.push({ url: b.site, label: b.cn + ' 中国官网', primary: !out.length });
  }
  return out;
}
/* 兼容：取首选链接 */
function shadeLink(s){
  const a = shadeLinks(s);
  return a.length ? a[0] : null;
}

/* 色号详情气泡：产品试色图 + 产品信息 + 官方商品页链接 */
/* 色号详情气泡：试色图 + 产品信息 + 「一句关于生命的诗」；色值 / 取色原则已按需求移除 */
function showShadeTip(s, anchor){
  const l = s.lineObj || {}, b = l.brand || {};
  const links = shadeLinksOn() ? shadeLinks(s) : [];
  let rows = '<div class="mood-tip-head"><i style="background:' + s.hex + '"></i>' +
          '<b>' + s.id + ' · ' + esc(s.name) + '</b></div>';
  if(b && b.cn) rows += '<div class="mood-tip-row"><span>' + PT('tip_brand') + '</span><em>' +
       esc(b.cn + (b.en ? ' · ' + b.en : '')) + '</em></div>';
  rows += '<div class="mood-tip-row"><span>' + PT('tip_product') + '</span><em>' +
       esc(l.name || PT('tip_base')) + '</em></div>';
  if(s.finish) rows += '<div class="mood-tip-row"><span>' + PT('tip_finish') + '</span><em>' +
       esc(s.finish) + '</em></div>';
  if(s.poem) rows += '<div class="mood-tip-poem"><i>' + PT('tip_poem') + '</i>' + esc(s.poem) + '</div>';
  const thumb = s.img
    ? '<img class="mood-tip-img" src="' + esc(s.img) + '" alt="' + esc(s.name) + '" loading="lazy" onerror="this.style.display=\'none\'">'
    : '<span class="mood-tip-chip" style="background:' + esc(s.hex) + '"></span>';
  let h = '<div class="mood-tip-flex">' + thumb +
          '<div class="mood-tip-info">' + rows + '</div></div>';
  links.forEach(function(k, i){
    h += '<a class="mood-link' + (i ? ' mood-link-alt' : '') + '" href="' + esc(k.url) + '"' +
         ' target="_blank" rel="noopener noreferrer">' +
         (i ? PT('link_site') : PT('link_product')) + esc(k.label) + ' ›</a>';
  });
  paintMoodTip(h, anchor, true);
}


/* =========================================================================
   【作画板块多语言】 Prompt 第 2 条：系统切到英语 / 法语时，作画板块同步更换。
   PT(key) 读取当前语言（全局 lang）下的文案；applyPaintI18n() 刷新所有 [data-p]。
   ========================================================================= */
const PAINT_I18N = {
  zh: {
    /* 顶部导航 / 面包屑 */
    nav_home:'首页', nav_gallery:'画作展示', nav_me:'个人中心', nav_portal:'‹ 门户',
    p_login:'登录', p_intro:'项目介绍', p_tryon:'虚拟试妆', p_tryon_r:'试妆结果',
    p_me:'个人中心', p_works:'我的作品', p_cart:'我的购物车', p_follows:'我的关注',
    p_donations:'我的捐赠', p_history:'浏览记录', p_msgs:'消息',
    p_rules:'作画规则', p_colors:'选择颜色', p_opening:'开始作画', p_canvas:'画布作画',
    p_pattern:'AI 纹样化', p_confirm:'确认提交',
    nav_prev_title:'返回上一页', nav_next_title:'前进到下一页',
    nav_first:'已经在最前面一页', nav_last:'已经在最后面一页',
    nav_back:'返回：', nav_fwd:'前进：',
    /* 语言设置 */
    lang_title:'语言', lang_zh:'简体中文', lang_en:'English', lang_fr:'Français',
    /* 首页入口 */
    home_bn1:'公益画展 · 让爱被看见', home_bn2:'AI 试妆 · 遇见更好的自己',
    home_bn3:'色彩疗愈 · 病房美学课堂', home_bn4:'爱心捐赠 · 公益产品领取',
    home_e1:'作画', home_e1d:'选择色号自由创作，可捐赠或自购定制头巾口罩',
    home_e2:'AI 试妆', home_e2d:'情绪智能匹配妆容，体验最新产品',
    home_e3:'项目介绍', home_e3d:'了解“戴上春天”的故事与参与方式',
    home_e4:'我的作品', home_e4d:'作品历史、评选状态与捐赠记录',
    /* 作画规则（叠在拼贴页之上） */
    rule_title:'作画规则',
    rule1:'① 选色：从欧莱雅产品色号库中挑选“颜料”，色号即颜料。',
    rule2:'② 创作：在画布上自由作画，可保存草稿；AI 会将作品转为可印花的四方连续纹样。',
    rule3:'③ 提交：选择认捐（一键捐赠实物）或自己购买定制产品；作品进入审核。',
    brush_matte:'哑光口红', brush_glaze:'水光唇釉', brush_blush:'粉状腮红',
    brush_liner:'眼线液笔', brush_gel:'眼线胶笔', brush_eraser:'橡皮擦',
    bt_matte:'饱和厚实 · 粉绒质感', bt_glaze:'通透果冻 · 水亮反光', bt_blush:'蓬松颗粒 · 雾面无边界',
    bt_liner:'锐利干净 · 速度联动粗细', bt_gel:'哑光绒感 · 有体积', bt_eraser:'擦除已绘制的内容',
    rule_hint:'点击这里 · 开始作画',
    /* 品牌拼贴页 */
    collage_kicker:'Colour Atelier', collage_title:'开始作画',
    collage_sub:'六大品牌 · 色彩盛宴 · 点亮你的专属色号',
    /* 开场 */
    open_headline:'六大品牌 · 色彩盛宴',
    open_sub:'133 种色彩语言，等待你的笔尖',
    open_skip:'跳过开场 ›', open_replay:'重播开场',
    open_b0:'圣罗兰', open_b1:'巴黎欧莱雅', open_b2:'3CE', open_b3:'阿玛尼', open_b4:'兰蔻', open_b5:'美宝莲',
    poem1:'颜色是生命能量的表达。',
    poem2:'愿这些小小的色彩，成为你可以看见、可以触摸、可以记住的温柔',
    /* 色轮 */
    wheel_title:'选色转盘',
    wheel_sub:'把鼠标放在色轮上，选择你想要的色系吧！',
    wheel_chosen:'已选色号（点击可移除）：', wheel_go:'用已选色号开始作画 ›',
    wheel_back:'返回完整色号库', wheel_replay:'重播开场',
    wheel_n:'{0} 个色号', wheel_fam_note:' · 点击颜色选择作画色号，鼠标放在色号上可以查看颜色对应产品型号与“一句生命的诗”',
    wheel_empty:'该色系暂无色号', wheel_none:'尚未选择任何色号',
    fam_红:'红色系', fam_棕:'棕色系', fam_橙:'橙色系', fam_黄:'黄色系', fam_绿:'绿色系', fam_蓝:'蓝色系',
    fam_紫:'紫色系', fam_黑:'黑色系', fam_灰:'灰色系', fam_白:'白色系',
    tip_brand:'品牌', tip_product:'产品', tip_finish:'质地', tip_base:'基础色',
    tip_poem:'一句关于生命的诗',
    link_product:'查看商品页 · ', link_site:'品牌官网 · ',
    /* 画布 */
    c_title:'画布作画', c_sub:'选择画笔与色号，在画布上自由创作',
    c_sub2:'自由挑选“哑光口红”“水光唇釉”“粉雾腮红”“眼线液笔”“眼线胶笔”五种作画效果',
    c_used:'本次使用色号（悬停色块可查看颜色寓意）：',
    c_size:'笔刷大小', c_undo:'撤销', c_clear:'清空画布',
    c_mini:'AI 纹样预览', c_live:'实时', c_mock_flat:'平铺', c_mock_scarf:'头巾', c_mock_mask:'口罩',
    c_mini_desc:'作品将自动转为可印花的四方连续纹样，实时预览。',
    c_expand:'展开工作台 ›', c_save:'保存草稿', c_load:'读取草稿', c_share:'分享',
    c_ai:'AI 纹样化', c_done:'完成 ›',
    brush_matte:'哑光口红', brush_gloss:'水光唇釉', brush_blush:'粉雾腮红',
    brush_liner:'眼线液笔', brush_glitter:'细闪高光', brush_eraser:'橡皮擦',
    c_undo1:'已撤销一步', c_undo0:'没有可撤销的操作', c_cleared:'画布已清空',
    c_saved:'草稿已保存', c_nodraft:'暂无草稿', c_loaded:'草稿已读取',
    share_title:'1:1 配捐提示', share_body:'您每分享一幅作品，<b>欧莱雅配捐一份“美的包裹”</b>，让公益可持续。',
    share_sub:'分享后作品将进入画作展示页，被更多人看见。', share_later:'稍后再说', share_now:'立即分享',
    share_title:'1:1 matching donation', share_body:'For every work you share, <b>L’Oréal matches with a “Beauty Parcel”</b> to keep the programme going.',
    share_sub:'Your work will appear in the gallery and be seen by more people.', share_later:'Later', share_now:'Share now',
    share_title:'Don doublé 1:1', share_body:'Pour chaque œuvre partagée, <b>L’Oréal offre un « Colis de beauté »</b> pour rendre le programme durable.',
    share_sub:'Votre œuvre apparaîtra dans la galerie et sera vue par plus de monde.', share_later:'Plus tard', share_now:'Partager',
    c_shared:'已分享，感谢配捐', c_share_t:'1:1 配捐提示',
    /* AI 纹样工作台 */
    pat_title:'AI 纹样化', pat_sub:'把作品扫描成可印花的四方连续纹样，可直接用于头巾、口罩',
    pat_scan:'扫描作品', pat_add:'添加纹样元件', pat_dup:'复制选中', pat_spread:'错落铺开',
    pat_top:'置顶', pat_del:'删除选中', pat_undo:'撤销',
    pat_hint:'单击元件选中 → <b>拖动</b>移动 · <b>拖四角</b>缩放 · <b>拖顶部圆点</b>旋转（按住 Shift 吸附 15°）· 也可用右侧滑块精确调整',
    pat_hint_a:'拖动', pat_hint_b:'拖四角', pat_hint_c:'拖顶部圆点',
    pat_s1:'扫描与抠图', pat_s1d:'自动识别画布上的主体、去掉白色底，得到可重复排列的纹样元件。',
    pat_empty:'尚未扫描 · 点击「扫描作品」', pat_thr:'去底强度',
    pat_s2:'四方连续底纹', pat_arrange:'排列', pat_grid:'网格', pat_offset:'半错位', pat_mirror:'镜像',
    pat_density:'密度', pat_gap:'间距', pat_build:'生成底纹', pat_clearbg:'清除底纹',
    pat_s3:'面料预览', pat_s4:'选中元件', pat_sel_none:'未选中元件 · 点击画布中的纹样元件',
    pat_size:'大小', pat_angle:'角度', pat_reset:'重置元件', pat_dup2:'再复制一个',
    pat_s5:'导出与应用', pat_export:'导出纹样 PNG', pat_back:'‹ 回到画布', pat_apply:'带着纹样去提交 ›',
    pat_nocanvas:'请先回到画布作画', pat_blank:'画布还是空的 · 先画几笔再来纹样化吧', pat_blank2:'画布还是空的',
    pat_scanned:'已扫描作品 · 提取纹样元件', pat_scanfirst:'请先扫描作品', pat_added:'已添加纹样元件',
    pat_nocopy:'没有可复制的元件', pat_copied:'已复制元件 · 可继续拖动 / 缩放 / 旋转',
    pat_noadd:'请先添加纹样元件', pat_spread_ok:'已错落铺开 ', pat_spread_ok2:' 个元件（大小与角度随机）',
    pat_nosel:'请先选中一个元件', pat_deled:'已删除', pat_bgcleared:'底纹已清除（单独元件保留）',
    pat_undone:'已撤销', pat_exported:'纹样已导出 PNG', pat_exportfail:'导出失败', pat_next:'下一步：提交作品 ›',
    pat_applied:'纹样已应用到作品', pat_motif:'纹样底', pat_subject:'主体已提取',
    /* 提交确认 */
    cf_title:'提交确认', cf_pick:'请选择作品去向：',
    cf_donate:'认捐（一键捐赠实物）', cf_buy:'自己购买（C2M 定制）',
    cf_used:'所用颜色介绍，戳我了解：', cf_audit:'作品提交后进入审核，审核通过将发放优惠券，可在信息栏查看。',
    cf_pv:'印花效果预览', cf_pvd:'作品经 AI 纹样化后，印在头巾 / 口罩上的效果', cf_redo:'重新调整纹样 ›',
    mod_product:'商品介绍 · ', mod_close:'关闭', mod_go:'前往商品页 ›',
    mod_cart_off:'购物车功能暂未开放',
    sub_donate_t:'提交认捐作品', sub_buy_t:'提交自购定制作品',
    sub_donate_ok:'认捐作品已提交，等待审核', sub_buy_ok:'定制订单已提交（C2M）',
    paint_need:'请至少选择一个色号'
  },
  en: {
    nav_home:'Home', nav_gallery:'Gallery', nav_me:'Profile', nav_portal:'‹ Portal',
    p_login:'Sign in', p_intro:'About', p_tryon:'Virtual Try-On', p_tryon_r:'Result',
    p_me:'Profile', p_works:'My Works', p_cart:'My Cart', p_follows:'Following',
    p_donations:'Donations', p_history:'History', p_msgs:'Messages',
    p_rules:'Paint Rules', p_colors:'Choose Colours', p_opening:'Start Painting', p_canvas:'Canvas',
    p_pattern:'AI Patternify', p_confirm:'Confirm',
    nav_prev_title:'Back to previous page', nav_next_title:'Forward to next page',
    nav_first:'Already at the first page', nav_last:'Already at the last page',
    nav_back:'Back: ', nav_fwd:'Forward: ',
    lang_title:'Language', lang_zh:'简体中文', lang_en:'English', lang_fr:'Français',
    home_bn1:'Charity Art Exhibition · Let Love Be Seen', home_bn2:'AI Try-On · Meet a Brighter You',
    home_bn3:'Colour Therapy · Ward Aesthetics Workshop', home_bn4:'Kind Donations · Free Charity Products',
    home_e1:'Paint', home_e1d:'Pick shades and create freely — donate or order your own scarf and mask',
    home_e2:'AI Try-On', home_e2d:'Mood-matched makeup, one tap to a beautiful new look',
    home_e3:'About', home_e3d:'The story of “Wearing Spring” and how to join',
    home_e4:'My Works', home_e4d:'Your creations, selection status and donation records',
    rule_title:'Paint Rules',
    rule1:'① Choose: pick your “pigment” from the L’Oréal shade library — a shade is the pigment.',
    rule2:'② Create: paint freely on the canvas and save drafts; AI turns your work into a printable seamless pattern.',
    rule3:'③ Submit: choose to donate (one-tap physical gift) or buy your own custom piece; works go to review.',
    brush_matte:'Matte lipstick', brush_glaze:'Glossy lip tint', brush_blush:'Powder blush',
    brush_liner:'Liquid eyeliner', brush_gel:'Gel eyeliner', brush_eraser:'Eraser',
    bt_matte:'Rich and dense · velvety', bt_glaze:'Translucent jelly · wet shine', bt_blush:'Airy grains · soft haze',
    bt_liner:'Crisp and clean · speed-reactive', bt_gel:'Matte velvet · with volume', bt_eraser:'Erase what you painted',
    rule_hint:'Tap here · Start painting',
    collage_kicker:'Colour Atelier', collage_title:'Start Painting',
    collage_sub:'Six brands · A feast of colour · Light up your own shades',
    open_headline:'SIX BRANDS · A FEAST OF COLOUR',
    open_sub:'133 shades of colour, waiting for your brush',
    open_skip:'Skip intro ›', open_replay:'Replay intro',
    open_b0:'Saint Laurent', open_b1:'L’Oréal Paris', open_b2:'3CE', open_b3:'Giorgio Armani',
    open_b4:'Lancôme', open_b5:'Maybelline',
    poem1:'Colour is the expression of life’s energy.',
    poem2:'May these small colours become a tenderness you can see, touch and remember.',
    wheel_title:'Wheel of Colour',
    wheel_sub:'Hover over the wheel and choose the colour family you like!',
    wheel_chosen:'Selected shades (tap to remove):', wheel_go:'Start painting with these shades ›',
    wheel_back:'Back to the full library', wheel_replay:'Replay intro',
    wheel_n:'{0} shades', wheel_fam_note:' · Click a colour to pick your painting shade; hover a shade to see its product model and “A Poem of Life”.',
    wheel_empty:'No shades in this family yet', wheel_none:'No shade selected yet',
    fam_红:'Reds', fam_棕:'Browns', fam_橙:'Oranges', fam_黄:'Yellows', fam_绿:'Greens', fam_蓝:'Blues',
    fam_紫:'Purples', fam_黑:'Blacks', fam_灰:'Greys', fam_白:'Whites',
    tip_brand:'Brand', tip_product:'Product', tip_finish:'Finish', tip_base:'Basic shade',
    tip_poem:'A poem for life',
    link_product:'View product · ', link_site:'Official site · ',
    c_title:'Canvas', c_sub:'Pick a brush and shades, then create freely on the canvas',
    c_sub2:'Freely pick among five effects: matte lipstick, glossy glaze, misty blush, liquid eyeliner and gel eyeliner',
    c_used:'Shades in use (hover a swatch to read its meaning):',
    c_size:'Brush size', c_undo:'Undo', c_clear:'Clear canvas',
    c_mini:'AI pattern preview', c_live:'live', c_mock_flat:'Flat', c_mock_scarf:'Scarf', c_mock_mask:'Mask',
    c_mini_desc:'Your artwork is automatically turned into a printable seamless pattern, previewed live.',
    c_expand:'Open workbench ›', c_save:'Save draft', c_load:'Load draft', c_share:'Share',
    c_ai:'AI Patternify', c_done:'Done ›',
    brush_matte:'Matte lipstick', brush_gloss:'Glossy lip tint', brush_blush:'Powder blush',
    brush_liner:'Liquid eyeliner', brush_glitter:'Fine shimmer', brush_eraser:'Eraser',
    c_undo1:'Undone one step', c_undo0:'Nothing to undo', c_cleared:'Canvas cleared',
    c_saved:'Draft saved', c_nodraft:'No draft yet', c_loaded:'Draft loaded',
    c_shared:'Shared — thank you for the matching donation', c_share_t:'1:1 matching donation',
    pat_title:'AI Patternify', pat_sub:'Scan your artwork into a printable seamless pattern for scarves and masks',
    pat_scan:'Scan artwork', pat_add:'Add motif', pat_dup:'Duplicate', pat_spread:'Scatter',
    pat_top:'Bring to front', pat_del:'Delete', pat_undo:'Undo',
    pat_hint:'Tap a motif to select → <b>drag</b> to move · <b>drag a corner</b> to scale · <b>drag the top dot</b> to rotate (hold Shift to snap to 15°) · or fine-tune with the sliders',
    pat_hint_a:'drag', pat_hint_b:'drag a corner', pat_hint_c:'drag the top dot',
    pat_s1:'Scan & cut-out', pat_s1d:'Detects the subject on the canvas and removes the white background to create a repeatable motif.',
    pat_empty:'Not scanned yet · tap “Scan artwork”', pat_thr:'Background removal',
    pat_s2:'Seamless ground', pat_arrange:'Layout', pat_grid:'Grid', pat_offset:'Half-offset', pat_mirror:'Mirror',
    pat_density:'Density', pat_gap:'Spacing', pat_build:'Build ground', pat_clearbg:'Clear ground',
    pat_s3:'Fabric preview', pat_s4:'Selected motif', pat_sel_none:'No motif selected · tap a motif on the canvas',
    pat_size:'Size', pat_angle:'Angle', pat_reset:'Reset motif', pat_dup2:'Duplicate again',
    pat_s5:'Export & apply', pat_export:'Export pattern PNG', pat_back:'‹ Back to canvas', pat_apply:'Submit with this pattern ›',
    pat_nocanvas:'Go back to the canvas and paint first', pat_blank:'The canvas is empty · paint a few strokes first', pat_blank2:'The canvas is empty',
    pat_scanned:'Artwork scanned · motif extracted', pat_scanfirst:'Please scan the artwork first', pat_added:'Motif added',
    pat_nocopy:'No motif to duplicate', pat_copied:'Motif duplicated · drag / scale / rotate it',
    pat_noadd:'Add a motif first', pat_spread_ok:'Scattered ', pat_spread_ok2:' motifs (random size and angle)',
    pat_nosel:'Select a motif first', pat_deled:'Deleted', pat_bgcleared:'Ground cleared (individual motifs kept)',
    pat_undone:'Undone', pat_exported:'Pattern exported as PNG', pat_exportfail:'Export failed', pat_next:'Next: submit your work ›',
    pat_applied:'Pattern applied to your work', pat_motif:'pattern', pat_subject:'Subject extracted',
    cf_title:'Confirm submission', cf_pick:'Where should this work go?',
    cf_donate:'Donate (one-tap physical gift)', cf_buy:'Buy for myself (C2M custom)',
    cf_used:'Tap a colour to read its story:', cf_audit:'After submission the work goes to review; once approved a coupon is issued and shown in Messages.',
    cf_pv:'Print preview', cf_pvd:'How the patternified work looks printed on a scarf / mask', cf_redo:'Adjust the pattern ›',
    mod_product:'Product · ', mod_close:'Close', mod_go:'View product page ›',
    mod_cart_off:'Cart is not available yet',
    sub_donate_t:'Submit donation work', sub_buy_t:'Submit custom order',
    sub_donate_ok:'Donation submitted, pending review', sub_buy_ok:'Custom order submitted (C2M)',
    paint_need:'Please select at least one shade'
  },
  fr: {
    nav_home:'Accueil', nav_gallery:'Galerie', nav_me:'Profil', nav_portal:'‹ Portail',
    p_login:'Connexion', p_intro:'Le projet', p_tryon:'Essai virtuel', p_tryon_r:'Résultat',
    p_me:'Profil', p_works:'Mes œuvres', p_cart:'Mon panier', p_follows:'Abonnements',
    p_donations:'Mes dons', p_history:'Historique', p_msgs:'Messages',
    p_rules:'Règles de création', p_colors:'Choisir les couleurs', p_opening:'Commencer', p_canvas:'Toile',
    p_pattern:'Motif IA', p_confirm:'Confirmer',
    nav_prev_title:'Page précédente', nav_next_title:'Page suivante',
    nav_first:'Vous êtes déjà à la première page', nav_last:'Vous êtes déjà à la dernière page',
    nav_back:'Retour : ', nav_fwd:'Suivant : ',
    lang_title:'Langue', lang_zh:'简体中文', lang_en:'English', lang_fr:'Français',
    home_bn1:'Exposition caritative · Que l’amour se voie', home_bn2:'Essai virtuel · Rencontrez une version plus lumineuse de vous',
    home_bn3:'Chromothérapie · Atelier d’esthétique en chambre', home_bn4:'Dons solidaires · Produits caritatifs',
    home_e1:'Créer', home_e1d:'Choisissez des nuances et créez librement — faites un don ou commandez votre foulard et masque',
    home_e2:'Essai virtuel', home_e2d:'Un maquillage assorti à votre humeur, en un geste',
    home_e3:'Le projet', home_e3d:'L’histoire de « Porter le printemps » et comment participer',
    home_e4:'Mes œuvres', home_e4d:'Vos créations, leur statut et vos dons',
    rule_title:'Règles de création',
    rule1:'① Choisir : choisissez votre « pigment » dans la bibliothèque de nuances L’Oréal — la nuance est le pigment.',
    rule2:'② Créer : peignez librement sur la toile et enregistrez des brouillons ; l’IA transforme votre œuvre en motif imprimable sans raccord.',
    rule3:'③ Envoyer : choisissez de faire un don (don physique en un clic) ou d’acheter votre pièce personnalisée ; l’œuvre passe en validation.',
    brush_matte:'Rouge à lèvres mat', brush_glaze:'Brillant à lèvres', brush_blush:'Fard à joues poudré',
    brush_liner:'Eyeliner liquide', brush_gel:'Eyeliner gel', brush_eraser:'Gomme',
    bt_matte:'Riche et dense · velouté', bt_glaze:'Gelée translucide · brillance humide', bt_blush:'Grains aériens · voile flou',
    bt_liner:'Net et précis · sensible à la vitesse', bt_gel:'Velours mat · avec du volume', bt_eraser:'Effacer ce que vous avez peint',
    rule_hint:'Cliquez ici · Commencer à créer',
    collage_kicker:'Atelier des couleurs', collage_title:'Commencer',
    collage_sub:'Six marques · Une fête des couleurs · Illuminez vos nuances',
    open_headline:'SIX MARQUES · UNE FÊTE DES COULEURS',
    open_sub:'133 nuances de couleur, en attente de votre pinceau',
    open_skip:'Passer l’intro ›', open_replay:'Rejouer l’intro',
    open_b0:'Saint Laurent', open_b1:'L’Oréal Paris', open_b2:'3CE', open_b3:'Giorgio Armani',
    open_b4:'Lancôme', open_b5:'Maybelline',
    poem1:'La couleur est l’expression de l’énergie de la vie.',
    poem2:'Puissent ces petites couleurs devenir une tendresse que l’on peut voir, toucher et garder en mémoire.',
    wheel_title:'La roue des couleurs',
    wheel_sub:'Neuf familles qui se fondent l’une dans l’autre · survolez ou touchez un segment pour voir ses nuances · survolez une nuance pour la fiche produit',
    wheel_chosen:'Nuances choisies (cliquez pour retirer) :', wheel_go:'Commencer avec ces nuances ›',
    wheel_back:'Retour à la bibliothèque complète', wheel_replay:'Rejouer l’intro',
    wheel_n:'{0} nuances', wheel_fam_note:' · Cliquez une couleur pour choisir votre nuance ; survolez une nuance pour voir le modèle produit et « Un poème de vie ».',
    wheel_empty:'Aucune nuance dans cette famille', wheel_none:'Aucune nuance choisie',
    fam_红:'Rouges', fam_棕:'Bruns', fam_橙:'Oranges', fam_黄:'Jaunes', fam_绿:'Verts', fam_蓝:'Bleus',
    fam_紫:'Violets', fam_黑:'Noirs', fam_灰:'Gris', fam_白:'Blancs',
    tip_brand:'Marque', tip_product:'Produit', tip_finish:'Fini', tip_base:'Nuance de base',
    tip_poem:'Un poème pour la vie',
    link_product:'Voir le produit · ', link_site:'Site officiel · ',
    c_title:'Toile', c_sub:'Choisissez un pinceau et des nuances, puis créez librement',
    c_sub2:'Choisissez librement parmi cinq effets : rouge mat, gloss, fard brume, eyeliner liquide et eyeliner gel',
    c_used:'Nuances utilisées (survolez une pastille pour son sens) :',
    c_size:'Taille du pinceau', c_undo:'Annuler', c_clear:'Effacer la toile',
    c_mini:'Aperçu du motif IA', c_live:'direct', c_mock_flat:'À plat', c_mock_scarf:'Foulard', c_mock_mask:'Masque',
    c_mini_desc:'Votre œuvre devient automatiquement un motif imprimable sans raccord, en aperçu direct.',
    c_expand:'Ouvrir l’atelier ›', c_save:'Enregistrer', c_load:'Charger', c_share:'Partager',
    c_ai:'Motif IA', c_done:'Terminer ›',
    brush_matte:'Rouge à lèvres mat', brush_gloss:'Brillant à lèvres', brush_blush:'Fard à joues poudré',
    brush_liner:'Eyeliner liquide', brush_glitter:'Enlumineur nacré', brush_eraser:'Gomme',
    c_undo1:'Une étape annulée', c_undo0:'Rien à annuler', c_cleared:'Toile effacée',
    c_saved:'Brouillon enregistré', c_nodraft:'Aucun brouillon', c_loaded:'Brouillon chargé',
    c_shared:'Partagé — merci pour le don doublé', c_share_t:'Don doublé 1:1',
    pat_title:'Motif IA', pat_sub:'Scannez votre œuvre en motif imprimable sans raccord, pour foulards et masques',
    pat_scan:'Scanner l’œuvre', pat_add:'Ajouter un motif', pat_dup:'Dupliquer', pat_spread:'Disperser',
    pat_top:'Au premier plan', pat_del:'Supprimer', pat_undo:'Annuler',
    pat_hint:'Touchez un motif pour le sélectionner → <b>glissez</b> pour déplacer · <b>un coin</b> pour redimensionner · <b>le point du haut</b> pour pivoter (Shift pour un pas de 15°) · ou ajustez avec les curseurs',
    pat_hint_a:'glisser', pat_hint_b:'un coin', pat_hint_c:'le point du haut',
    pat_s1:'Scan & détourage', pat_s1d:'Détecte le sujet sur la toile et retire le fond blanc pour obtenir un motif répétable.',
    pat_empty:'Pas encore scanné · cliquez sur « Scanner l’œuvre »', pat_thr:'Suppression du fond',
    pat_s2:'Fond sans raccord', pat_arrange:'Disposition', pat_grid:'Grille', pat_offset:'Demi-décalage', pat_mirror:'Miroir',
    pat_density:'Densité', pat_gap:'Espacement', pat_build:'Générer le fond', pat_clearbg:'Effacer le fond',
    pat_s3:'Aperçu tissu', pat_s4:'Motif sélectionné', pat_sel_none:'Aucun motif sélectionné · cliquez un motif sur la toile',
    pat_size:'Taille', pat_angle:'Angle', pat_reset:'Réinitialiser', pat_dup2:'Dupliquer encore',
    pat_s5:'Export & application', pat_export:'Exporter le motif PNG', pat_back:'‹ Retour à la toile', pat_apply:'Envoyer avec ce motif ›',
    pat_nocanvas:'Revenez d’abord à la toile pour peindre', pat_blank:'La toile est vide · peignez quelques traits d’abord', pat_blank2:'La toile est vide',
    pat_scanned:'Œuvre scannée · motif extrait', pat_scanfirst:'Scannez d’abord l’œuvre', pat_added:'Motif ajouté',
    pat_nocopy:'Aucun motif à dupliquer', pat_copied:'Motif dupliqué · glissez / redimensionnez / faites tourner',
    pat_noadd:'Ajoutez d’abord un motif', pat_spread_ok:'Dispersé ', pat_spread_ok2:' motifs (taille et angle aléatoires)',
    pat_nosel:'Sélectionnez d’abord un motif', pat_deled:'Supprimé', pat_bgcleared:'Fond effacé (motifs conservés)',
    pat_undone:'Annulé', pat_exported:'Motif exporté en PNG', pat_exportfail:'Échec de l’export', pat_next:'Étape suivante : soumettre l’œuvre ›',
    pat_applied:'Motif appliqué à votre œuvre', pat_motif:'motif', pat_subject:'Sujet extrait',
    cf_title:'Confirmer l’envoi', cf_pick:'Que faire de cette œuvre ?',
    cf_donate:'Faire un don (don physique en un clic)', cf_buy:'Acheter (personnalisation C2M)',
    cf_used:'Touchez une couleur pour lire son histoire :', cf_audit:'Après l’envoi, l’œuvre passe en validation ; une fois validée, un bon est émis et visible dans Messages.',
    cf_pv:'Aperçu d’impression', cf_pvd:'Rendu du motif imprimé sur foulard / masque', cf_redo:'Ajuster le motif ›',
    mod_product:'Produit · ', mod_close:'Fermer', mod_go:'Voir la page produit ›',
    mod_cart_off:'Panier indisponible pour le moment',
    sub_donate_t:'Envoyer un don', sub_buy_t:'Envoyer une commande',
    sub_donate_ok:'Don envoyé, en attente de validation', sub_buy_ok:'Commande envoyée (C2M)',
    paint_need:'Sélectionnez au moins une nuance'
  }
};
function curLang(){
  try { return (typeof lang !== 'undefined' && PAINT_I18N[lang]) ? lang : 'zh'; } catch(e){ return 'zh'; }
}
/* 取当前语言文案；{0}{1} 依次替换 */
function PT(key){
  const d = PAINT_I18N[curLang()] || PAINT_I18N.zh;
  let s = (d[key] !== undefined) ? d[key] : (PAINT_I18N.zh[key] || key);
  for(let i = 1; i < arguments.length; i++) s = s.replace('{' + (i - 1) + '}', arguments[i]);
  return s;
}
function famLabel(f){ return PT('fam_' + f); }
/* 把页面里所有 [data-p] 元素的文字按当前语言刷新 */
function applyPaintI18n(){
  const d = PAINT_I18N[curLang()] || PAINT_I18N.zh;
  document.querySelectorAll('[data-p]').forEach(function(el){
    const k = el.getAttribute('data-p');
    if(d[k] === undefined && PAINT_I18N.zh[k] === undefined) return;
    const v = (d[k] !== undefined) ? d[k] : PAINT_I18N.zh[k];
    if(el.hasAttribute('data-p-html')) el.innerHTML = v; else el.textContent = v;
  });
}
/* 公益端：只展示颜色，不给商品页 / 官网链接（Prompt 第 5 条） */
function shadeLinksOn(){
  try { return (typeof SHADE_SHOW_LINKS === 'undefined') ? true : !!SHADE_SHOW_LINKS; }
  catch(e){ return true; }
}
