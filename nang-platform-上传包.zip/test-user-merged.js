/* ============================================================
   user-merged.html 专项验证（无浏览器）
   她的框架：登录/导航/首页/AI试妆/画廊/个人中心/三语
   我的板块：作画入口后的选色 → 画布 → 纹样 → 提交
   ============================================================ */
const fs = require('fs');
const vm = require('vm');
const path = require('path');

const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18';
const P = p => path.join(ROOT, p);
const out = fs.readFileSync(P('nang-platform/user-merged.html'), 'utf8');
const team = fs.readFileSync(P('team-merge/user.html'), 'utf8');
const myUser = fs.readFileSync(P('nang-platform/user.html'), 'utf8');

let pass = 0, fail = 0;
const G = n => console.log('\n【' + n + '】');
const ok = (l, c, e) => { if (c) { pass++; console.log('  ✅ ' + l); } else { fail++; console.log('  ❌ ' + l + (e ? '  → ' + e : '')); } };

/* ---------- 切段 ---------- */
const scripts = [...out.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const jsAll = scripts.join('\n');
const bodyHtml = out.slice(out.indexOf('<body'), out.indexOf('<script'));

/* ============================================================
   一、脚本语法与标签
   ============================================================ */
G('一、脚本完整性');
scripts.forEach((s, i) => {
  try { new Function(s); ok('脚本段 ' + (i + 1) + ' 语法通过（' + (s.length / 1024).toFixed(0) + 'KB）', true); }
  catch (e) { ok('脚本段 ' + (i + 1) + ' 语法通过', false, e.message); }
});

/* ============================================================
   二、她的框架：逐块核对
   ============================================================ */
G('二、她的框架保持不变');
const teamBlocks = [
  ['顶部导航（欧莱雅标 + 翻页键 + 门户按钮）', /<nav class="topnav" id="topnav"[\s\S]*?id="navBack"[\s\S]*?loreal-logo\.png[\s\S]*?index\.html[\s\S]*?<\/nav>/],
  ['登录/登记页', /id="page-auth"[\s\S]*?authUser[\s\S]*?authPass[\s\S]*?toggleAuthMode\(\);return false;/],
  ['首页（banner + 四个入口 + 项目介绍）', /id="page-home"[\s\S]*?bannerTrack[\s\S]*?home_e1[\s\S]*?tryon\/select[\s\S]*?go\('intro'\)[\s\S]*?me\/works/],
  ['AI 试妆页（select + result）', /id="page-tryon-select"[\s\S]*?id="page-tryon-result"/],
  ['画廊页', /id="page-gallery"/],
  ['个人中心全套（7 页）', /id="page-me"[\s\S]*?id="page-me-works"[\s\S]*?id="page-me-cart"[\s\S]*?id="page-me-follows"[\s\S]*?id="page-me-donations"[\s\S]*?id="page-me-history"[\s\S]*?id="page-me-messages"/]
];
teamBlocks.forEach(([label, re]) => ok(label + ' 原样保留', re.test(out)));

ok('三语字典完整保留（含作画三语 PAINT_I18N）', out.includes("fr: {") && out.includes('PAINT_I18N') && out.includes('function applyPaintI18n'));
ok('她的登录逻辑保留（doAuth / toggleAuthMode）', out.includes('function doAuth()') && out.includes('function toggleAuthMode()'));
ok('她的路由表保留并扩展 pattern', out.includes("'paint/pattern'"));
ok('她的 i18n 应用逻辑保留', out.includes('function applyI18n()'));
ok('她的画廊逻辑保留', out.includes('function renderGallery('));
ok('她的个人中心逻辑保留', out.includes('function renderCart()') && out.includes('function renderMsgs()'));
ok('她的 banner 定时器保留', out.includes("$('bannerTrack').style.transform"));
/* 她的原有文案抽查 */
['戴上春天 · 用户登记', '用创作与善意，把美送到病房', '公益画展 · 让爱被看见', '了解“戴上春天”的故事与参与方式']
  .forEach(w => ok('原文案：' + w, out.includes(w)));

/* ============================================================
   三、我的作画功能
   ============================================================ */
G('三、作画功能导入');
const myPaintHtml = myUser.slice(myUser.indexOf('<!-- ===== Paint: colors'), myUser.indexOf('<!-- ===== Try-on: select ===== -->'));
ok('作画页面 HTML 与我的源码逐字节一致', out.includes(myPaintHtml));
const myPaintJs = myUser.slice(myUser.indexOf('/* ================= Paint: colors ================= */'), myUser.indexOf('/* ================= Try-on ================= */'));
ok('作画脚本与我的源码逐字节一致', out.includes(myPaintJs));
ok('纹样工作台快捷键已导入', out.includes('function patDelete()') === false || out.includes('patDuplicate(); return;'));
checkShades();
function checkShades() {
  const m = out.match(/const SHADES = \[([\s\S]*?)\n\];/);
  const n = m ? (m[1].match(/^\s*\[/gm) || []).length : 0;
  ok('色号库 133 个色号（113 产品色 + 21 基础色）', n === 134, '实际 ' + n);
}
ok('六大品牌', (out.match(/id:'(YSL|MAY|ARMANI|LOREAL|LANCOME|3CE)'/g) || []).length === 6);
ok('九大色系顺序', out.includes("SHADE_FAMILY_ORDER = ['红', '橙', '黄', '绿', '蓝', '紫', '棕', '黑', '白']"));
ok('悬停气泡（产品图 + 商品页链接）', out.includes('mood-tip-img') && out.includes('shadeLinks('));
ok('美妆笔刷套装', out.includes('BRUSHES') && out.includes('createBrushEngine('));
ok('AI 纹样工作台', out.includes('function enterPattern()') && out.includes('function patExport('));

/* ============================================================
   四、接线一致性（onclick / 路由 / 页面元素）
   ============================================================ */
G('四、接线一致性');
/* 1) onclick 引用的函数必须有定义 */
const onclickFns = [...new Set([...out.matchAll(/onclick="([A-Za-z_$][\w$]*)\(/g)].map(m => m[1]))];
const definedFns = new Set([...jsAll.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[1]));
const commonFns = new Set([...out.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[1]));
const missing = onclickFns.filter(fn => !definedFns.has(fn) && !commonFns.has(fn) && !['location', 'alert'].includes(fn));
ok('全部 ' + onclickFns.length + ' 个 onclick 函数都有定义', missing.length === 0, missing.join(', '));

/* 2) go('path') 的 path 必须在路由表里 */
const pathsM = out.match(/const PATHS = \[([\s\S]*?)\];/);
const PATHS = (pathsM[1].match(/'([^']+)'/g) || []).map(s => s.slice(1, -1));
const goCalls = [...new Set([...out.matchAll(/go\('([^']+)'\)/g)].map(m => m[1]))];
const badGo = goCalls.filter(p => !PATHS.includes(p));
ok('全部 ' + goCalls.length + ' 个路由跳转都在路由表内', badGo.length === 0, badGo.join(', '));

/* 3) 每个路由都有对应页面容器 */
const missingPages = PATHS.filter(p => !out.includes('id="page-' + p.replace(/\//g, '-') + '"'));
ok('路由表 ' + PATHS.length + ' 条都对应页面容器', missingPages.length === 0, missingPages.join(', '));

/* 4) 首页「作画」入口 → paint/rules（她的入口，未被改指向） */
ok('首页作画入口指向拼贴页 go(\'paint/colors\')', /onclick="go\('paint\/colors'\)"/.test(out));
ok('作画规则页已删除（Prompt 第 10 条）', !out.includes('page-paint-rules') && !out.includes("go('paint/rules')"));
ok('品牌标已换为欧莱雅（Prompt 第 11 条）', out.includes('loreal-logo.png') && !out.includes('🎨 病房美学计划'));
ok('go() 已支持 paint/pattern 分支', out.includes("if(path === 'paint/pattern') enterPattern();"));

/* 5) 作画段调用到的外部函数都有定义 */
const paintCalls = ['confirmColors', 'enterCanvas', 'renderConfirm', 'enterPattern', 'submitWork', 'saveDraft', 'loadDraft', 'shareWork', 'productModal', 'undoPaint'];
const undef = paintCalls.filter(f => !definedFns.has(f) && !commonFns.has(f));
ok('作画流程关键函数齐全', undef.length === 0, undef.join(', '));

/* ============================================================
   五、运行时冒烟：登录 → 作画全流程
   ============================================================ */
G('五、运行时冒烟（登录 → 选色 → 画布 → 纹样 → 提交）');
const mkEl = id => {
  const cls = new Set();
  const el = {
    id, style: {}, dataset: {}, innerHTML: '', textContent: '', value: '', disabled: false,
    width: 640, height: 640, files: [], childNodes: [], tagName: 'DIV',
    classList: {
      add: c => cls.add(c), remove: c => cls.delete(c), contains: c => cls.has(c),
      toggle: (c, v) => { const on = v === undefined ? !cls.has(c) : !!v; on ? cls.add(c) : cls.delete(c); return on; }
    },
    querySelector: () => null, querySelectorAll: () => [], appendChild(){}, remove(){},
    addEventListener(){}, removeEventListener(){}, setAttribute(){}, getAttribute: () => null,
    getContext: () => CTX, setPointerCapture(){}, releasePointerCapture(){}, focus(){}, blur(){}, click(){},
    insertBefore(){}, contains: () => false, toDataURL: () => 'data:image/png;base64,AAA',
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 640, height: 640 })
  };
  return el;
};
const CTX = new Proxy({}, {
  get(t, k) {
    if (k === 'measureText') return () => ({ width: 10 });
    if (k === 'getImageData') return () => ({ data: new Uint8ClampedArray(4), width: 1, height: 1 });
    if (k === 'createLinearGradient' || k === 'createRadialGradient') return () => ({ addColorStop() {} });
    if (k === 'canvas') return null;
    return () => {};
  }, set() { return true; }
});
const els = {};
const store = new Map();
const sandbox = {
  console,
  document: {
    getElementById: id => els[id] || (els[id] = mkEl(id)),
    querySelector: () => mkEl('q'), querySelectorAll: () => [],
    createElement: () => mkEl('new'),
    addEventListener(){}, documentElement: { lang: 'zh-CN', setAttribute(){}, removeAttribute(){} },
    body: mkEl('body'), head: mkEl('head')
  },
  localStorage: {
    getItem: k => store.has(k) ? store.get(k) : null,
    setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k), clear: () => store.clear()
  },
  location: { hash: '', href: 'http://localhost/' },
  navigator: { userAgent: 'node' },
  setTimeout: (fn, t) => setTimeout(fn, Math.min(t || 0, 5)), clearTimeout,
  setInterval: () => 0, clearInterval() {},
  requestAnimationFrame: fn => setTimeout(fn, 0),
  addEventListener(){}, scrollTo(){}, alert(){}, Event: function(){},
  FileReader: function(){ this.readAsDataURL = () => {}; this.onload = null; },
  Image: function(){ const s = this; this.src = ''; setTimeout(() => s.onload && s.onload(), 0); }
};
sandbox.window = sandbox; sandbox.globalThis = sandbox;
const ctx = vm.createContext(sandbox);

/* 分两段执行：公共库（已内联）→ 应用脚本 */
try {
  vm.runInContext(scripts[0], ctx, { filename: 'common.js' });
  ok('公共库可执行', true);
} catch (e) { ok('公共库可执行', false, e.message); }

/* 只跑她的框架壳 + 我的作画段（跳过依赖大量 DOM 的其他渲染函数） */
try {
  const i18nHead = out.slice(out.indexOf('/* ================= i18n'), out.indexOf('/* ================= Auth'));
  const authRouter = out.slice(out.indexOf('/* ================= Auth'), out.indexOf('/* ================= Home banner'));
  const paint = out.slice(out.indexOf('/* ================= Paint: colors'), out.indexOf('/* ================= Try-on'));
  vm.runInContext(i18nHead + '\n' + authRouter + '\n' + paint, ctx, { filename: 'framework+paint.js' });
  ok('框架 + 作画脚本可执行', true);
} catch (e) { ok('框架 + 作画脚本可执行', false, e.message); }

try {
  vm.runInContext("currentUser = '小A';", ctx);
  const n = vm.runInContext('COLORS.length', ctx);
  ok('基础调色板仍是她的 12 色（COLORS）', n === 12, '实际 ' + n);
  const shr = vm.runInContext('SHADES.length', ctx);
  ok('色号素材库可读（' + shr + ' 色号）', shr === 134);
  vm.runInContext("go('paint/colors')", ctx);
  ok('进入选色页：page-paint-colors 激活',
    els['page-paint-colors'] && els['page-paint-colors'].classList.contains('active'));
  vm.runInContext("go('paint/canvas')", ctx);
  ok('进入画布页：enterCanvas 已执行（pCtx 就绪）', vm.runInContext('!!pCtx', ctx) === true);
  vm.runInContext("go('paint/pattern')", ctx);
  ok('进入纹样工作台（她的路由已支持）',
    els['page-paint-pattern'] && els['page-paint-pattern'].classList.contains('active'));
  const famOk = vm.runInContext("SHADE_FAMILY_ORDER.length", ctx);
  ok('九大色系可用', famOk === 9);
  const link = vm.runInContext("shadeLinks(SHADE_MAP['S001'])[0].url", ctx);
  ok('色号 → 商品页链接可用', /^https?:\/\//.test(link), link);
} catch (e) { ok('作画流程冒烟', false, e.message); }

/* ============================================================
   六、依赖文件
   ============================================================ */
G('六、依赖文件');
ok('样式表已内联为单文件（css-main）', out.includes('<style id="css-main">') && !out.includes('href="assets/style.css"'));
ok('她的公共库引用已替换为内联增强版', !out.includes('<script src="assets/common.js"></script>'));
ok('试色图目录齐备', fs.existsSync(P('nang-platform/assets/shades')) && fs.readdirSync(P('nang-platform/assets/shades')).length === 113);
['商标.jpg', 'poster1.jpg', 'poster2.jpg', 'poster3.jpg', 'poster4.jpg', '登录页头图.png']
  .forEach(f => ok('素材：' + f, fs.existsSync(P('nang-platform/' + f))));

console.log('\n' + '='.repeat(46));
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('='.repeat(46));
process.exit(fail ? 1 : 0);
