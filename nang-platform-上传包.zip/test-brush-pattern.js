/* 无浏览器回归测试：用极简软件 canvas 桩加载真实的 common.js / user.html 代码 */
const fs = require('fs');
const vm = require('vm');

const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18/nang-platform';

/* ---------------- 极简软件 canvas ---------------- */
function parseColor(s){
  s = String(s).trim();
  if(/^rgba?\(/.test(s)){
    const m = s.match(/[\d.]+/g).map(Number);
    return [m[0], m[1], m[2], m.length > 3 ? Math.round(m[3] * 255) : 255];
  }
  if(s[0] === '#'){
    let h = s.slice(1);
    if(h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 255];
  }
  return ({ white:[255,255,255,255], black:[0,0,0,255] }[s]) || [0,0,0,255];
}

class Ctx {
  constructor(cv){
    this.cv = cv; this.globalAlpha = 1; this.globalCompositeOperation = 'source-over';
    this.fillStyle = '#000'; this.strokeStyle = '#000'; this.lineWidth = 1;
    this.calls = { arc:0, fill:0, fillRect:0, drawImage:0, stroke:0 };
  }
  save(){} restore(){} beginPath(){} closePath(){} moveTo(){} lineTo(){}
  rect(){} quadraticCurveTo(){} bezierCurveTo(){} setLineDash(){}
  translate(){} rotate(){} scale(){} clip(){}
  arc(){ this.calls.arc++; }
  fill(){ this.calls.fill++; }
  stroke(){ this.calls.stroke++; }
  createRadialGradient(){ return { addColorStop(){} }; }
  createLinearGradient(){ return { addColorStop(){} }; }
  clearRect(x,y,w,h){ this._blit(x,y,w,h,[0,0,0,0],true); }
  fillRect(x,y,w,h){ this.calls.fillRect++; this._blit(x,y,w,h,parseColor(this.fillStyle),false); }
  _blit(x,y,w,h,rgba,replace){
    const cv = this.cv, d = cv._data;
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    for(let yy = Math.max(0,y); yy < Math.min(cv.height, y+h); yy++){
      for(let xx = Math.max(0,x); xx < Math.min(cv.width, x+w); xx++){
        const i = (yy*cv.width + xx)*4;
        if(replace){ d[i]=rgba[0]; d[i+1]=rgba[1]; d[i+2]=rgba[2]; d[i+3]=rgba[3]; }
        else{
          const a = (rgba[3]/255) * this.globalAlpha;
          d[i]   = Math.round(d[i]  *(1-a) + rgba[0]*a);
          d[i+1] = Math.round(d[i+1]*(1-a) + rgba[1]*a);
          d[i+2] = Math.round(d[i+2]*(1-a) + rgba[2]*a);
          d[i+3] = Math.round(d[i+3]*(1-a) + 255*a);
        }
      }
    }
  }
  drawImage(src){
    this.calls.drawImage++;
    const a = Array.prototype.slice.call(arguments, 1);
    let sx=0, sy=0, sw=src.width, sh=src.height, dx=0, dy=0, dw=src.width, dh=src.height;
    if(a.length === 2){ dx=a[0]; dy=a[1]; }
    else if(a.length === 4){ dx=a[0]; dy=a[1]; dw=a[2]; dh=a[3]; }
    else if(a.length === 8){ sx=a[0]; sy=a[1]; sw=a[2]; sh=a[3]; dx=a[4]; dy=a[5]; dw=a[6]; dh=a[7]; }
    const dst = this.cv, sd = src._data, dd = dst._data;
    const W = Math.round(dw), H = Math.round(dh);
    for(let y = 0; y < H; y++){
      for(let x = 0; x < W; x++){
        const px = Math.round(dx + x), py = Math.round(dy + y);
        if(px < 0 || py < 0 || px >= dst.width || py >= dst.height) continue;
        const sxp = Math.min(src.width-1,  Math.max(0, Math.round(sx + x*sw/W)));
        const syp = Math.min(src.height-1, Math.max(0, Math.round(sy + y*sh/H)));
        const si = (syp*src.width + sxp)*4, di = (py*dst.width + px)*4;
        const al = (sd[si+3]/255) * this.globalAlpha;
        if(this.globalCompositeOperation === 'destination-out'){
          dd[di+3] = Math.round(dd[di+3] * (1 - al));
        }else{
          dd[di]   = Math.round(dd[di]  *(1-al) + sd[si]*al);
          dd[di+1] = Math.round(dd[di+1]*(1-al) + sd[si+1]*al);
          dd[di+2] = Math.round(dd[di+2]*(1-al) + sd[si+2]*al);
          dd[di+3] = Math.round(dd[di+3]*(1-al) + 255*al);
        }
      }
    }
  }
  getImageData(){ return { data:new Uint8ClampedArray(this.cv._data), width:this.cv.width, height:this.cv.height }; }
  putImageData(img){ this.cv._data.set(img.data); }
}

class Canvas {
  constructor(w, h){
    this._w = 0; this._h = 0;
    this._data = new Uint8ClampedArray(0);
    this._ctx = null; this._ev = {}; this.style = {};
    if(w) this.width = w;
    if(h) this.height = h;
  }
  /* 真实 canvas 改尺寸会自动重新分配像素缓冲，桩里必须显式模拟 */
  get width(){ return this._w; }
  set width(v){ this._w = Math.max(0, v|0); this._alloc(); }
  get height(){ return this._h; }
  set height(v){ this._h = Math.max(0, v|0); this._alloc(); }
  _alloc(){ this._data = new Uint8ClampedArray(this._w * this._h * 4); }
  getContext(){ if(!this._ctx) this._ctx = new Ctx(this); return this._ctx; }
  getBoundingClientRect(){ return { left:0, top:0, width:this.width, height:this.height }; }
  addEventListener(t, fn){ (this._ev[t] = this._ev[t] || []).push(fn); }
  fire(t, ev){
    (this._ev[t] || []).forEach(fn => fn(Object.assign({
      preventDefault(){}, pointerType:'mouse', button:0, pointerId:1, shiftKey:false
    }, ev)));
  }
  setPointerCapture(){} releasePointerCapture(){}
  toDataURL(){ return 'data:image/png;base64,STUB'; }
}

/* ---------------- DOM / 浏览器桩 ---------------- */
const _els = {};
function mkEl(tag){
  if(tag === 'canvas') return new Canvas(0, 0);
  return {
    tagName:'DIV', style:{}, dataset:{}, innerHTML:'', textContent:'', value:'100',
    className:'', classList:{ add(){}, remove(){}, toggle(){}, contains(){ return false; } },
    appendChild(){}, remove(){}, addEventListener(){},
    querySelectorAll(){ return []; },
    getBoundingClientRect(){ return { left:0, top:0, width:100, height:100 }; }
  };
}
const documentStub = {
  createElement: mkEl,
  getElementById: id => _els[id] || (_els[id] = mkEl('div')),
  addEventListener(){}, querySelectorAll(){ return []; },
  body: mkEl('div')
};
const windowStub = { addEventListener(){}, innerWidth:1440, innerHeight:900, location:{ hash:'' } };
const localStorageStub = {
  _s:{}, getItem(k){ return Object.prototype.hasOwnProperty.call(this._s,k) ? this._s[k] : null; },
  setItem(k,v){ this._s[k] = String(v); }
};

const sandbox = {
  document: documentStub, window: windowStub, localStorage: localStorageStub,
  performance: { now: () => Date.now() },
  console, Math, Date, JSON, Object, Array, String, Number, parseInt, parseFloat,
  Promise, setTimeout, clearTimeout, requestAnimationFrame: fn => fn(),
  Image: function(){ this.onload = null; this.src = ''; },
  URL: { createObjectURL(){ return 'blob:x'; }, revokeObjectURL(){} }
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

/* ---------------- 加载真实代码 ---------------- */
vm.runInContext(fs.readFileSync(ROOT + '/assets/common.js', 'utf8'), sandbox, { filename:'common.js' });

/* 从 user.html 抽取真实函数体（括号配平） */
const userSrc = fs.readFileSync(ROOT + '/user.html', 'utf8');
function extractFn(name){
  const start = userSrc.indexOf('function ' + name + '(');
  if(start < 0) throw new Error('未找到函数 ' + name);
  let i = userSrc.indexOf('{', start), depth = 0;
  for(let j = i; j < userSrc.length; j++){
    if(userSrc[j] === '{') depth++;
    else if(userSrc[j] === '}'){
      depth--;
      if(depth === 0) return userSrc.slice(start, j+1);
    }
  }
  throw new Error('函数未闭合 ' + name);
}
['extractMotif','patSelGeom','shapePath','drawPatternInto'].forEach(n => {
  vm.runInContext(extractFn(n), sandbox, { filename:n });
});
/* 注入 user.html 中真实的几何常量（const→var，便于跨脚本访问） */
const constSrc = [/const P_CORNER = [^\n]*;/, /const P_HIT = [^\n]*;/]
  .map(re => (userSrc.match(re) || [''])[0]).filter(Boolean).join('\n').replace(/\bconst\b/g, 'var');
vm.runInContext(constSrc, sandbox, { filename:'geom-consts' });

/* ---------------- 断言工具 ---------------- */
let pass = 0, fail = 0;
function ok(cond, label, extra){
  if(cond){ pass++; console.log('  ✅ ' + label); }
  else{ fail++; console.log('  ❌ ' + label + (extra !== undefined ? '  → ' + extra : '')); }
}
/* const/let 声明不会挂到 vm 全局对象，需用表达式求值读取 */
function G(expr){ return vm.runInContext(expr, sandbox); }

/* ============ 测试 1：颜色数据完整性 ============ */
console.log('\n【测试 1】颜色情绪数据 COLOR_MOOD');
const CM = G('COLOR_MOOD'), COLORS = G('COLORS');
ok(Object.keys(CM).length === COLORS.length, 'COLOR_MOOD 覆盖全部色号（' + Object.keys(CM).length + '/' + COLORS.length + '）');
const lackField = COLORS.filter(([no]) => {
  const m = CM[no];
  return !m || !m.name || !m.emotion || !m.imagery || !m.atmosphere;
});
ok(lackField.length === 0, '每个色号都有 名称/情绪/意象/氛围', lackField.map(x => x[0]).join(','));
ok(G("colorMood('P07').name") === '玫瑰粉', 'colorMood() 取值正确');
ok(G("hexA('#E76F51',0.5)") === 'rgba(231,111,81,0.5)', 'hexA() 输出正确 rgba');
ok(G("nearestColorNo('#E76F51')") === 'P02', 'nearestColorNo() 命中同色号 P02');

/* ============ 测试 2：笔刷引擎 ============ */
console.log('\n【测试 2】笔刷引擎（5 支美妆笔触 + 橡皮）');
const BRUSHES = G('BRUSHES');
ok(BRUSHES.length === 6, 'BRUSHES 共 6 支（' + BRUSHES.length + '）');
ok(BRUSHES.filter(b => b.erase).length === 1, '其中有且仅有 1 支橡皮');

const expected = {
  matte:'哑光口红', glaze:'水光唇釉', blush:'粉雾腮红',
  liner:'眼线液笔', gel:'眼线胶笔', eraser:'橡皮擦'
};
Object.keys(expected).forEach(id => {
  ok(sandbox.getBrush(id).name === expected[id], '笔刷定义存在：' + id + ' → ' + expected[id]);
});

const cv = new Canvas(400, 400);
const c2d = cv.getContext('2d');
const painted = [];
const eng = sandbox.createBrushEngine(cv, { bg:'#ffffff', onPaint(c){ painted.push(c); } });
eng.reset();

const dabCounts = {};
['matte','glaze','blush','liner','gel','eraser'].forEach(id => {
  eng.setBrush(id);
  eng.setColor('#E76F51');
  eng.setSize(1);
  c2d.calls.arc = 0;
  cv.fire('pointerdown', { clientX:50, clientY:200 });
  for(let x = 60; x <= 350; x += 6) cv.fire('pointermove', { clientX:x, clientY:200 });
  cv.fire('pointerup', { clientX:350, clientY:200 });
  dabCounts[id] = c2d.calls.arc;
});
ok(Object.values(dabCounts).every(v => v > 0), '6 支笔都能落笔（dab 数 ' + JSON.stringify(dabCounts) + '）');
const paramSets = new Set(BRUSHES.map(b => [b.size, b.spacing, b.flow, b.hardness, b.scatter||0, b.gloss||0].join('|')));
ok(paramSets.size === 6, '6 支笔的参数组合互不相同（各具质感）');
ok(dabCounts.blush > dabCounts.matte * 3, '粉雾腮红因粒子散布产生最多笔点（' + dabCounts.blush + ' vs 哑光口红 ' + dabCounts.matte + '）');
ok(G("BRUSHES.find(b=>b.id==='glaze').gloss") > 0, '水光唇釉带高光参数');
ok(G("BRUSHES.find(b=>b.id==='liner').hardness") === 1 && G("BRUSHES.find(b=>b.id==='liner').vThin") > 0,
   '眼线液笔为硬边且速度联动变细');
ok(G("BRUSHES.find(b=>b.id==='gel').jitter") > 0, '眼线胶笔带手绘抖动，笔触有体积');
ok(G("BRUSHES.find(b=>b.id==='eraser').erase") === true, '橡皮使用 erase 擦除模式');
ok(painted.length === 6 && painted.every(c => c === '#E76F51'), '每笔回调一次且色值正确');

/* 橡皮必须用 destination-out */
eng.setBrush('eraser'); eng.setSize(1);
c2d.globalCompositeOperation = 'source-over';
cv.fire('pointerdown', { clientX:100, clientY:100 });
ok(true, '橡皮落笔无异常');
cv.fire('pointerup', { clientX:100, clientY:100 });

/* 撤销 */
c2d.calls.fillRect = 0;
ok(eng.undo() === true, 'undo() 成功回退一步');
ok(eng.undo() === true, '连续 undo 可用');
eng.clear();
ok(c2d.calls.fillRect > 0, 'clear() 会重绘白底');

/* ============ 测试 3：抠图算法 ============ */
console.log('\n【测试 3】作品扫描抠图 extractMotif');
const srcCv = new Canvas(100, 100);
const sc = srcCv.getContext('2d');
sc.fillStyle = '#ffffff'; sc.fillRect(0, 0, 100, 100);
sc.fillStyle = '#C9553A'; sc.fillRect(40, 40, 20, 20);
const motif = sandbox.extractMotif(srcCv, 238, 18);
ok(!!motif, '能从白底上提取主体');
if(motif){
  ok(motif.width === 26 && motif.height === 26,
     '裁切到主体外接框 + 3px 留白（得到 ' + motif.width + '×' + motif.height + '，期望 26×26）',
     motif.width + 'x' + motif.height);
  const cx = (13*26 + 13)*4;
  ok(motif._data[cx+3] === 255, '主体中心像素不透明（alpha=' + motif._data[cx+3] + '）');
  const corner = 3*4;
  ok(motif._data[corner+3] === 0, '四角背景已透明（alpha=' + motif._data[corner+3] + '）');
}
const blankCv = new Canvas(60, 60);
const bc = blankCv.getContext('2d'); bc.fillStyle = '#ffffff'; bc.fillRect(0, 0, 60, 60);
ok(sandbox.extractMotif(blankCv, 238, 18) === null, '空白画布返回 null（提示用户先作画）');

/* ============ 测试 4：纹样对象几何 ============ */
console.log('\n【测试 4】纹样元件几何（选中框 / 旋转手柄）');
const o = { x:100, y:100, w:80, h:60, rot:0 };
let g = sandbox.patSelGeom(o);
ok(g.corners.length === 4, '返回 4 个角点');
ok(Math.abs(g.corners[0].x - 60) < 0.01 && Math.abs(g.corners[0].y - 70) < 0.01, '未旋转时角点坐标正确');
ok(g.rot.y < g.corners[0].y, '旋转手柄在上方（' + Math.round(g.rot.y) + ' < ' + Math.round(g.corners[0].y) + '）');
const o2 = { x:100, y:100, w:80, h:60, rot:Math.PI/2 };
const g2 = sandbox.patSelGeom(o2);
ok(Math.abs(g2.corners[0].x - 130) < 0.01 && Math.abs(g2.corners[0].y - 60) < 0.01,
   '旋转 90° 后角点随之旋转', '(' + Math.round(g2.corners[0].x) + ',' + Math.round(g2.corners[0].y) + ')');

/* ============ 测试 5：形状路径 ============ */
console.log('\n【测试 5】面料轮廓 shapePath');
['flat','scarf','mask'].forEach(k => {
  const c = new Canvas(200, 200), x = c.getContext('2d');
  let threw = false;
  try{ sandbox.shapePath(x, k, 200, 200); }catch(e){ threw = true; }
  ok(!threw, '轮廓可绘制：' + k);
});

/* ---------------- 汇总 ---------------- */
console.log('\n════════════════════════════');
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('════════════════════════════');
process.exit(fail ? 1 : 0);
