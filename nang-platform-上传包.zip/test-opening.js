/* ============================================================
   开场（品牌三角）+ 命运色轮 专项验证
   覆盖：user.html（源头） 与 user-merged.html（融合版）
   ============================================================ */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let pass = 0, fail = 0;
function ok(label, cond){
  if(cond){ pass++; console.log('  ✓ ' + label); }
  else { fail++; console.log('  ✗ ' + label); }
}

const mine = fs.readFileSync(path.join(__dirname, 'user.html'), 'utf8');
const merged = fs.readFileSync(path.join(__dirname, 'user-merged.html'), 'utf8');
const css = fs.readFileSync(path.join(__dirname, 'assets', 'style.css'), 'utf8');
const collage = fs.existsSync(path.join(__dirname, 'assets', 'brand-collage.jpg'));

console.log('=== 一、九大色系数据 ===');
/* 在 VM 里跑 common.js，验证归类函数与索引 */
const stubs = {
  document: { addEventListener(){}, querySelector(){return null}, querySelectorAll(){return []}, getElementById(){return null}, createElement(){return {style:{},classList:{add(){},remove(){}}}} },
  window: { addEventListener(){} },
  localStorage: { getItem(){return null}, setItem(){}, removeItem(){} },
  location: { hash:'' }, navigator: { userAgent:'test' }, setInterval(){}, clearInterval(){}, setTimeout(){}, clearTimeout(){}
};
stubs.window.document = stubs.document;
let ctx = vm.createContext(stubs);
let commonErr = null;
try { vm.runInContext(fs.readFileSync(path.join(__dirname, 'assets', 'common.js'), 'utf8'), ctx); }
catch(e){ commonErr = e; }
ok('common.js 可在 Node 环境执行' + (commonErr ? ' → ' + commonErr.message : ''), !commonErr);
ok('SHADE_FAMILY_ORDER = 九大色系（红橙黄绿蓝紫棕黑白）',
   JSON.stringify(vm.runInContext('SHADE_FAMILY_ORDER', ctx)) === JSON.stringify(['红','橙','黄','绿','蓝','紫','棕','黑','白']));
const famOf = vm.runInContext('colorFamilyOf', ctx);
ok('归类：青色 #00BCD4 → 绿（青调并入绿）', famOf('#00BCD4') === '绿');
ok('归类：蓝色 #1E5AA8 → 蓝', famOf('#1E5AA8') === '蓝');
ok('归类：正红 #AC1E1A → 红', famOf('#AC1E1A') === '红');
ok('归类：深黑 #111111 → 黑', famOf('#111111') === '黑');
const byFam = vm.runInContext('SHADE_BY_FAMILY', ctx);
const famTotal = Object.keys(byFam).reduce((n, f) => n + byFam[f].length, 0);
ok('九大色系覆盖全部 134 色号（实际 ' + famTotal + '）', famTotal === 134);
ok('不存在空色系缺位（9 项索引）', Object.keys(byFam).length === 9);

console.log('=== 二、取色页：仅拼贴入口（无边 · 动态延伸） ===');
for(const [tag, src] of [['user.html', mine], ['user-merged.html', merged]]){
  ok(tag + '：拼贴入口存在（collage-hero）', src.includes('class="collage-hero"'));
  ok(tag + '：旧选色板已删除（无 colorSourceSeg）', !src.includes('id="colorSourceSeg"'));
  ok(tag + '：旧拼贴 CTA 已移除', !src.includes('collage-cta'));
  ok(tag + '：点击进入 paint/opening', src.includes(`onclick="go('paint/opening')"`));
  ok(tag + '：拼贴页引用 assets/hex-collage.jpg（六角品牌拼贴）', src.includes('assets/hex-collage.jpg'));
  ok(tag + '：开场六柱仍用 brand-poster.jpg（CSS 背景）', css.includes("url('brand-poster.jpg')"));
  ok(tag + '：副标题不再含「青」', !src.includes('红橙黄绿青蓝紫'));
}
ok('拼贴图片文件存在', collage);
ok('CSS：无边动态延伸（heroDrift）', css.includes('.collage-hero') && css.includes('heroDrift'));
ok('CSS：renderColors 空引用保护', mine.includes("if(!$('brandFilter')) return;"));

console.log('=== 三、开场舞台（品牌三角） ===');
for(const [tag, src] of [['user.html', mine], ['user-merged.html', merged]]){
  ok(tag + '：page-paint-opening 存在', src.includes('id="page-paint-opening"'));
  ok(tag + '：路由表含 paint/opening', src.includes(`'paint/opening'`));
  ok(tag + '：go() 分支 enterOpening', src.includes(`if(path === 'paint/opening') enterOpening();`));
  ok(tag + '：六大品牌数据齐全', ['YSL BEAUTY',"L'ORÉAL PARIS",'3CE','GIORGIO ARMANI','LANCÔME PARIS','MAYBELLINE NEW YORK']
      .every(b => src.includes(b)));
  ok(tag + '：跳过开场按钮', src.includes('finishOpening()'));
  ok(tag + '：金色光扫动画', src.includes('openSweep') || css.includes('openSweep'));
}
ok('CSS：开场舞台样式', css.includes('.open-stage') && css.includes('.open-piece'));
ok('CSS：品牌字幕样式', css.includes('.open-cap'));
ok('CSS：拼贴切片背景映射', mine.includes("background-size:100% 100%") || css.includes('.open-piece') && merged.includes('background-image:url'));
ok('CSS：跳过按钮样式', css.includes('.open-skip'));

console.log('=== 四、命运色轮 ===');
for(const [tag, src] of [['user.html', mine], ['user-merged.html', merged]]){
  ok(tag + '：conic-gradient 相融色盘', src.includes('conic-gradient(from -90deg'));
  ok(tag + '：九色扇区热区', /class=\\?"whot/.test(src));
  ok(tag + '：悬停/点击均触发', src.includes('onmouseenter="setWheelFocus') && src.includes('onclick="setWheelFocus'));
  ok(tag + '：色号面板渲染', src.includes('renderWheelPanel'));
  ok(tag + '：已选色号同步', src.includes('renderWheelChosen'));
  ok(tag + '：开始作画复用 confirmColors', src.includes(`onclick="confirmColors()"`));
  ok(tag + '：重播开场', src.includes('replayOpening()'));
}
ok('CSS：色轮样式', css.includes('.wheel-disc') && css.includes('.whot.on') && css.includes('.wheel-core'));
ok('CSS：暗色面板适配 shade-sw', css.includes('.wheel-panel .shade-sw'));

console.log('=== 五、脚本语法 ===');
for(const [tag, src] of [['user.html', mine], ['user-merged.html', merged]]){
  const re = /<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g;
  let m, allOk = true, n = 0;
  while((m = re.exec(src))){
    n++;
    try { new Function(m[1]); } catch(e){ allOk = false; console.log('    ✗ ' + tag + ' script #' + n + ': ' + e.message); }
  }
  ok(tag + '：' + n + ' 段脚本语法全部通过', allOk);
}

console.log('\n结果：' + pass + ' 通过，' + fail + ' 失败');
process.exit(fail ? 1 : 0);
