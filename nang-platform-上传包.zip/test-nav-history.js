/* 无浏览器回归测试：从 user.html 抽取真实的导航栈函数，模拟浏览器 hashchange 行为 */
const fs = require('fs');
const vm = require('vm');

const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18/nang-platform';
const userSrc = fs.readFileSync(ROOT + '/user.html', 'utf8');

/* ---------------- 抽取真实函数体（括号配平） ---------------- */
function extractFn(name){
  const start = userSrc.indexOf('function ' + name + '(');
  if(start < 0) throw new Error('未找到函数 ' + name);
  let i = userSrc.indexOf('{', start), depth = 0;
  for(let j = i; j < userSrc.length; j++){
    if(userSrc[j] === '{') depth++;
    else if(userSrc[j] === '}'){
      depth--;
      if(depth === 0) return userSrc.slice(start, j+1);
    }
  }
  throw new Error('函数未闭合 ' + name);
}

/* ---------------- DOM / 环境桩 ---------------- */
function mkEl(){ return { disabled:false, title:'', style:{}, setAttribute(){}, classList:{ toggle(){}, add(){}, remove(){} } }; }
const els = {};
const documentStub = {
  addEventListener(){}, querySelectorAll(){ return []; },
  getElementById(id){ return els[id] || (els[id] = mkEl()); },
  body: mkEl()
};
const localStorageStub = {
  _s:{}, getItem(k){ return Object.prototype.hasOwnProperty.call(this._s,k) ? this._s[k] : null; },
  setItem(k,v){ this._s[k] = String(v); }
};

const sandbox = {
  document: documentStub, window: { addEventListener(){}, innerWidth:1440 },
  localStorage: localStorageStub, console, Math, Date, JSON, Object, Array, String, Number,
  parseInt, parseFloat, Promise, setTimeout, clearTimeout, requestAnimationFrame: fn => fn()
};
sandbox.globalThis = sandbox;
sandbox.$ = function(id){ return documentStub.getElementById(id); };
sandbox.PT = function(k){
  /* 与 common.js PAINT_I18N 中文区一致的桩，供 navSync/navLabel 取标题文案 */
  const M = {
    nav_home:'首页', nav_gallery:'画作展示', nav_me:'个人中心', nav_portal:'‹ 门户',
    p_login:'登录', p_intro:'项目介绍', p_tryon:'虚拟试妆', p_tryon_r:'试妆结果',
    p_me:'个人中心', p_works:'我的作品', p_cart:'我的购物车', p_follows:'我的关注',
    p_donations:'我的捐赠', p_history:'浏览记录', p_msgs:'消息',
    p_colors:'选择颜色', p_opening:'开始作画', p_canvas:'画布作画',
    p_pattern:'AI 纹样化', p_confirm:'确认提交',
    nav_first:'已经在最前面一页', nav_last:'已经在最后面一页',
    nav_back:'返回：', nav_fwd:'前进：'
  };
  return M[k] || k;
};   /* navSync 标题走多语言 PT（common.js 提供），此处按中文区桩化 */
sandbox.location = { hash: '' };
vm.createContext(sandbox);

/* ---------------- 注入声明与函数（let/const → var 以便跨脚本读取） ---------------- */
const decls = [/let navStack = \[[^\n]*;/, /let navIdx = -1;/, /const NAV_MAX = \d+;/]
  .map(re => (userSrc.match(re) || [''])[0]).filter(Boolean).join('\n');
if(!decls) throw new Error('未找到导航栈声明');
vm.runInContext(decls.replace(/\b(let|const)\b/g, 'var'), sandbox, { filename:'nav-decls' });

['navSeed','navRecord','navSync','navLabel','navJump','navBack','navFwd'].forEach(n => {
  vm.runInContext(extractFn(n), sandbox, { filename:n });
});

/* ---------------- 忠实模拟浏览器：go() 只改 hash，事件异步触发 hashchange ---------------- */
vm.runInContext(`
  var PATHS = ['auth','home','intro','paint/rules','paint/colors','paint/canvas','paint/pattern','paint/confirm',
    'tryon/select','tryon/result','gallery',
    'me','me/works','me/cart','me/follows','me/donations','me/history','me/messages'];
  var currentUser = 'tester';
  function go(path){ location.hash = '#/' + (currentUser ? path : 'auth'); }
  function hashchange(){
    const h = location.hash.replace(/^#\\//,'');
    if(!PATHS.includes(h)) return;
    go(h);
    navRecord(h);
  }
`, sandbox, { filename:'browser-sim' });

function G(expr){ return vm.runInContext(expr, sandbox); }
function visit(path){ G('go(' + JSON.stringify(path) + ')'); G('hashchange()'); }
function press(which){ G(which === 'back' ? 'navBack()' : 'navFwd()'); G('hashchange()'); }
function cur(){ return G('navStack[navIdx]'); }

/* ---------------- 断言工具 ---------------- */
let pass = 0, fail = 0;
function ok(cond, label, extra){
  if(cond){ pass++; console.log('  ✅ ' + label); }
  else{ fail++; console.log('  ❌ ' + label + (extra !== undefined ? '  → ' + extra : '')); }
}

/* ============ 测试 1：基本前进 / 后退 ============ */
console.log('\n【测试 1】基本前进 / 后退');
G("navSeed('home')");
visit('gallery'); visit('me');
ok(G('navIdx') === 2, '连续访问三页后栈顶下标 = 2', G('navIdx'));
ok(JSON.stringify(G('navStack')) === '["home","gallery","me"]', '栈内容正确', JSON.stringify(G('navStack')));
press('back');
ok(cur() === 'gallery', '返回上一页 → gallery', cur());
press('back');
ok(cur() === 'home', '再返回 → home', cur());
ok(G("$('navBack').disabled") === true, '到最前面时「返回」按钮被禁用');
ok(G("$('navFwd').disabled") === false, '此时「前进」按钮可用');
press('forward');
ok(cur() === 'gallery', '前进 → gallery', cur());
ok(G("$('navBack').disabled") === false && G("$('navFwd').disabled") === false, '中间位置两个按钮都可用');

/* ============ 测试 2：浏览器自带后退键（Alt+←）同步 ============ */
console.log('\n【测试 2】浏览器自带后退 / 前进 同步');
G("navSeed('home')");
visit('gallery'); visit('me');
// 直接改 hash，模拟用户按浏览器后退键
G("location.hash = '#/gallery'"); G('hashchange()');
ok(G('navIdx') === 1, '浏览器后退后栈顶下标跟随回退到 1', G('navIdx'));
G("location.hash = '#/me'"); G('hashchange()');
ok(G('navIdx') === 2, '浏览器前进后栈顶下标跟随前进到 2', G('navIdx'));
ok(JSON.stringify(G('navStack')) === '["home","gallery","me"]', '浏览器前进/后退不会污染栈', JSON.stringify(G('navStack')));

/* ============ 测试 3：后退后再访问新页，前进分支被截断 ============ */
console.log('\n【测试 3】前进分支截断');
G("navSeed('home')");
visit('gallery'); visit('me');
press('back');                       // 回到 gallery
visit('paint/rules');                // 走新分支
ok(JSON.stringify(G('navStack')) === '["home","gallery","paint/rules"]',
   '旧的前进分支 me 被丢弃', JSON.stringify(G('navStack')));
ok(G("$('navFwd').disabled") === true, '截断后「前进」按钮变灰');
press('forward');
ok(cur() === 'paint/rules', '此时按前进无效，仍停在 paint/rules', cur());

/* ============ 测试 4：未登录时不允许跳转 ============ */
console.log('\n【测试 4】未登录保护');
G("navSeed('home')");
visit('gallery');
press('back');
const beforeIdx = G('navIdx');
G("currentUser = null");
press('forward');
ok(G('navIdx') === beforeIdx, '未登录时 navJump 不改变栈位置', G('navIdx'));
G("currentUser = 'tester'");

/* ============ 测试 5：按钮文案 ============ */
console.log('\n【测试 5】按钮提示文案');
G("navSeed('home')");
visit('paint/canvas');
ok(G("navLabel('paint/canvas')") === '画布作画', '中文页名映射正确', G("navLabel('paint/canvas')"));
ok(G("navLabel('paint/pattern')") === 'AI 纹样化', '纹样化页名映射正确', G("navLabel('paint/pattern')"));
ok(G("navLabel('unknown/page')") === 'unknown/page', '未知路由回退为原始路径');
ok(/返回：首页/.test(G("$('navBack').title")), '返回按钮提示含目标页名', G("$('navBack').title"));
ok(/已经在最后面一页/.test(G("$('navFwd').title")), '栈尾时前进按钮提示正确', G("$('navFwd').title"));

/* ============ 测试 6：栈长度上限 ============ */
console.log('\n【测试 6】栈长度上限');
G("navSeed('home')");
for(let i = 0; i < 90; i++) visit(i % 2 ? 'gallery' : 'me');
ok(G('navStack.length') <= G('NAV_MAX'), '栈长度不超过 NAV_MAX（' + G('NAV_MAX') + '）', G('navStack.length'));
ok(G('navIdx') === G('navStack.length') - 1, '下标始终指向栈顶', G('navIdx'));

/* ============ 测试 7：重复访问同一页不入栈 ============ */
console.log('\n【测试 7】重复访问同一页');
G("navSeed('home')");
visit('gallery');
const len = G('navStack.length');
visit('gallery');
ok(G('navStack.length') === len, '连续两次进入同一页只记录一次', G('navStack.length'));

console.log('\n════════════════════════════');
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('════════════════════════════\n');
process.exit(fail ? 1 : 0);
