/* 色号素材库回归测试：加载真实的 common.js + 抽取 user.html 的渲染函数 */
const fs = require('fs');
const vm = require('vm');

const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18/nang-platform';

/* ---------------- DOM 桩 ---------------- */
const _els = {};
function mkEl(){
  return {
    tagName:'DIV', style:{}, dataset:{}, innerHTML:'', textContent:'', value:'',
    className:'', _cls:{},
    classList:{
      add(c){ this._o._cls[c] = 1; }, remove(c){ delete this._o._cls[c]; },
      toggle(c,v){ if(v === undefined) v = !this._o._cls[c]; if(v) this._o._cls[c] = 1; else delete this._o._cls[c]; },
      contains(c){ return !!this._o._cls[c]; }
    },
    appendChild(){}, remove(){}, addEventListener(){},
    querySelectorAll(){ return []; },
    getBoundingClientRect(){ return { left:0, top:0, width:100, height:100 }; }
  };
}
function el(id){
  if(!_els[id]){ _els[id] = mkEl(); _els[id].classList._o = _els[id]; }
  return _els[id];
}
const documentStub = {
  createElement: () => { const e = mkEl(); e.classList._o = e; return e; },
  getElementById: el,
  addEventListener(){}, querySelectorAll(){ return []; },
  body: (() => { const e = mkEl(); e.classList._o = e; return e; })()
};
const sandbox = {
  document: documentStub,
  window: { addEventListener(){}, innerWidth:1440, innerHeight:900, location:{ hash:'' } },
  localStorage: { _s:{}, getItem(k){ return k in this._s ? this._s[k] : null; }, setItem(k,v){ this._s[k] = String(v); } },
  console, Math, Date, JSON, Object, Array, String, Number, parseInt, parseFloat,
  Promise, setTimeout, clearTimeout, requestAnimationFrame: fn => fn()
};
/* const/let 不挂到 vm 全局，函数里要用到的需要显式补 */
sandbox.$ = el;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

/* ---------------- 加载真实代码 ---------------- */
vm.runInContext(fs.readFileSync(ROOT + '/assets/common.js', 'utf8'), sandbox, { filename:'common.js' });

/* user.html 里 `let` 声明的页面状态，用 var 注入以便跨脚本访问 */
vm.runInContext('var familyFilter = "ALL"; var colorSource = "lib"; var chosenColors = [];', sandbox, { filename:'state' });

const userSrc = fs.readFileSync(ROOT + '/user.html', 'utf8');
function extractFn(name){
  const start = userSrc.indexOf('function ' + name + '(');
  if(start < 0) throw new Error('未找到函数 ' + name);
  let i = userSrc.indexOf('{', start), depth = 0;
  for(let j = i; j < userSrc.length; j++){
    if(userSrc[j] === '{'){ depth++; }
    else if(userSrc[j] === '}'){
      depth--;
      if(depth === 0) return userSrc.slice(start, j + 1);
    }
  }
  throw new Error('函数未闭合 ' + name);
}
['bfChip','shadeSwatch','lineGroupHtml','renderLib','renderChosen','colorLabel'].forEach(n => {
  vm.runInContext(extractFn(n), sandbox, { filename:n });
});

/* ---------------- 断言工具 ---------------- */
let pass = 0, fail = 0;
function ok(cond, label, extra){
  if(cond){ pass++; console.log('  ✅ ' + label); }
  else{ fail++; console.log('  ❌ ' + label + (extra !== undefined ? '  → ' + extra : '')); }
}
const G = expr => vm.runInContext(expr, sandbox);
const set = (expr) => vm.runInContext(expr, sandbox);

/* ============ 1. 数据完整性 ============ */
console.log('\n【测试 1】色号数据完整性');
const nBrands = G('SHADE_BRANDS.length');
const nLines  = G('SHADE_LINES.length');
const nShades = G('SHADES.length');

ok(nBrands === 6, '六大品牌齐备（' + nBrands + '）');
ok(nLines === 26, '产品线 26 条（含 L26 基础色）（' + nLines + '）');
ok(nShades === 134, '色号 134 条（113 产品色 + 21 基础色）（' + nShades + '）');

const brandIds = G('SHADE_BRANDS.map(b => b.id)');
ok(new Set(brandIds).size === brandIds.length, '品牌 id 无重复');
ok(G('SHADE_BRANDS.every(b => b.cn && b.en && /^https:\\/\\//.test(b.site))'), '每个品牌都有中文名 / 英文名 / 官网地址');

const lineIds = G('SHADE_LINES.map(l => l.id)');
const brandIdsJson = JSON.stringify(brandIds);
const lineIdsJson = JSON.stringify(lineIds);
ok(new Set(lineIds).size === lineIds.length, '产品线 id 无重复');
ok(G('SHADE_LINES.every(l => l.b === "" || ' + brandIdsJson + '.indexOf(l.b) >= 0)'), '产品线的品牌 id 都能对上（L26 基础色无品牌）');

const noUrl = G('SHADE_LINES.filter(l => l.id !== "L26" && !/^https:\\/\\//.test(l.url || "")).map(l => l.id)');
ok(noUrl.length === 0, '每条产品线都有官方商品页链接（L26 基础色豁免）', noUrl.join(','));
ok(G('SHADE_LINES.every(l => l.id === "L26" || (l.src && l.name && l.short))'), '每条产品线都有名称与链接来源说明（L26 豁免）');

const shadeIds = G('SHADES.map(s => s[0])');
ok(new Set(shadeIds).size === 134, '色号 id 唯一（134 个）', '共 ' + shadeIds.length + ' 条 / 去重后 ' + new Set(shadeIds).size);

const badHex = G('SHADES.filter(s => !/^#[0-9A-F]{6}$/.test(s[3])).map(s => s[0])');
ok(badHex.length === 0, '全部色号为合法 6 位 HEX', badHex.join(','));
ok(G('SHADES.every(s => s[2] && s[2].length > 0)'), '每个色号都有色名');
ok(G('SHADES.every(s => ' + lineIdsJson + '.indexOf(s[1]) >= 0)'), '每个色号的所属产品线都存在');

const pant = G('SHADES.filter(s => s[4] && !/^\\d{2}-\\d{4}$/.test(s[4])).map(s => s[0])');
ok(pant.length === 0, 'Pantone 编号格式统一（nn-nnnn）', pant.join(','));
ok(G('SHADES.every(s => s[1] === "L26" || (s[5] && String(s[5]).length > 0))'), '每个色号都有 Pantone 色名（L26 基础色豁免）');

const badDe = G('SHADES.filter(s => s[7] !== null && (typeof s[7] !== "number" || s[7] < 0 || s[7] > 40)).map(s => s[0])');
ok(badDe.length === 0, 'ΔE 数值都在合理区间（0–40）或为空', badDe.join(','));

/* ============ 2. 品牌分布 ============ */
console.log('\n【测试 2】品牌分布（与整理文档一致）');
const expect = { YSL:20, MAY:39, ARMANI:12, LOREAL:15, LANCOME:13, '3CE':14 };
let sum = 0;
Object.keys(expect).forEach(b => {
  const n = G('shadeCountOfBrand("' + b + '")');
  sum += n;
  ok(n === expect[b], b + ' 色号数 = ' + expect[b], '实际 ' + n);
});
ok(sum === 113, '六个品牌合计 113（' + sum + '）');
ok(G('shadeCountOfBrand("ALL")') === 134, 'shadeCountOfBrand("ALL") = 134（含 20 基础色）');
ok(G('shadeLinesOf("YSL").length') === 4, 'YSL 有 4 条产品线');
ok(G('shadeLinesOf("ALL").length') === 26, 'shadeLinesOf("ALL") 返回全部 26 条');

/* ============ 2.5 九大色系分类 ============ */
console.log('\n【测试 2.5】色系分类（红橙黄绿蓝紫棕黑白）');
ok(JSON.stringify(G('SHADE_FAMILY_ORDER')) === JSON.stringify(['红','橙','黄','绿','蓝','紫','棕','黑','白']),
   '色系顺序为 红橙黄绿蓝紫棕黑白');
ok(G('colorFamilyOf("#AC1E1A")') === '红', '正红 #AC1E1A → 红');
ok(G('colorFamilyOf("#DB988C")') === '红', '浅粉橘 #DB988C → 红（粉调归红）');
ok(G('colorFamilyOf("#744F3A")') === '橙', '棕调 #744F3A → 橙（棕归橙）');
ok(G('colorFamilyOf("#84D3BE")') === '绿', '薄荷绿 #84D3BE → 绿');
ok(G('colorFamilyOf("#97A7DC")') === '蓝', '冰川蓝 #97A7DC → 蓝');
ok(G('colorFamilyOf("#62404E")') === '紫', '暮紫 #62404E → 紫');
ok(G('colorFamilyOf("#FAE6DD")') === '白', '象牙白 #FAE6DD → 白');
ok(G('colorFamilyOf("#1A1A1A")') === '黑', '深黑 #1A1A1A → 黑');
ok(G('colorFamilyOf("#BFBFBF")') === '灰', '中灰 #BFBFBF → 灰');
const famSum = G('SHADE_FAMILY_ORDER.reduce((n,f) => n + shadeCountOfFamily(f), 0)');
ok(famSum === 134, '九个色系合计 134（' + famSum + '）');
ok(G('shadeCountOfFamily("ALL")') === 134, 'shadeCountOfFamily("ALL") = 133');
const noFam = G('SHADES.filter(s => { const o = SHADE_MAP[s[0]]; return !o || SHADE_FAMILY_ORDER.indexOf(o.family) < 0; }).map(s => s[0])');
ok(noFam.length === 0, '每个色号都归入了合法色系', noFam.slice(0,5).join(','));
const emptyFam = G('SHADE_FAMILY_ORDER.filter(f => shadeCountOfFamily(f) === 0)');
console.log('       （空色系：' + (emptyFam.join('、') || '无') + '）');
/* 产品图：路径规则 + 文件真实存在 */
ok(G('SHADE_MAP.S001.img') === 'assets/shades/S001.png', '产品图路径规则 assets/shades/<id>.png');
const imgMissing = G('SHADES.filter(s => s[1] !== "L26").map(s => s[0])').filter(id => !fs.existsSync(ROOT + '/assets/shades/' + id + '.png'));
ok(imgMissing.length === 0, '113 张产品试色图全部存在（L26 基础色无产品图，气泡用色块兜底）', imgMissing.slice(0,5).join(','));
ok(fs.statSync(ROOT + '/assets/shades/S001.png').size > 100, '图片文件非空');

/* ============ 3. 索引与取色 ============ */
console.log('\n【测试 3】索引与颜色取值');
const s1 = G('SHADE_MAP.S001');
ok(s1 && s1.id === 'S001' && s1.line && s1.name && s1.hex, 'shadeById("S001") 字段完整');
ok(G('shadeById("S999")') === null, '不存在的色号返回 null');
ok(G('colorName("S001")') === s1.hex, 'colorName 支持色号 id（' + G('colorName("S001")') + '）');
ok(G('colorName("P02")') === '#E76F51', '原有基础色 P02 取值不受影响');
ok(G('colorName("NOPE")') === '#ccc', '未知 id 兜底返回 #ccc');
ok(G('Object.keys(SHADE_MAP).length') === 134, 'SHADE_MAP 索引 134 条');
ok(G('SHADE_BY_LINE["L01"].length') === 4, 'L01 产品线索引到 4 个色号');
ok(G('SHADE_LINES.every(l => l.id === "L26" || (l.brand && l.brand.cn))'), '每条产品线都挂上了品牌对象（L26 豁免）');

/* ============ 4. 商品页链接 ============ */
console.log('\n【测试 4】商品页链接');
const badLink = G('SHADES.filter(s => s.line !== "L26" && (() => { const k = shadeLink(SHADE_MAP[s[0]]); return !k || !/^https:\\/\\//.test(k.url) || !k.label; })()).map(s => s[0])');
ok(G('shadeLink(SHADE_MAP.S001).url') === G('SHADE_LINE_MAP.L01.url'), '色号的链接取自所属产品线');
ok(G('shadeLink(SHADE_MAP.S001).label').length > 0, '链接带来源说明：' + G('shadeLink(SHADE_MAP.S001).label'));
const fb = G('shadeLink({ lineObj:{ url:"", brand:{ cn:"测试", site:"https://demo.test/" } } })');
ok(fb && fb.url === 'https://demo.test/', '产品线无链接时回落到品牌官网');

/* --- 双入口：精确商品页 + 品牌中国官网 --- */
const noLinks = G('SHADES.filter(s => s[1] !== "L26" && shadeLinks(SHADE_MAP[s[0]]).length === 0).map(s => s[0])');
ok(noLinks.length === 0, '每个产品色至少有一条可达入口（L26 用色块兜底）', noLinks.slice(0,5).join(','));
ok(G('shadeLinks(SHADE_MAP.S001).length') === 2, '海外商品页的色号额外给出品牌中国官网');
ok(G('shadeLinks(SHADE_MAP.S001)[0].url') === G('SHADE_LINE_MAP.L01.url'), '第一条为精确商品页');
ok(G('shadeLinks(SHADE_MAP.S001)[1].url') === G('SHADE_BRAND_MAP.YSL.site'), '第二条为品牌中国官网');
ok(/中国官网/.test(G('shadeLinks(SHADE_MAP.S001)[1].label')), '第二条入口标注为「品牌中国官网」');
ok(G('shadeLinks(SHADE_MAP.S001)[0].primary') === true, '商品页被标记为首选入口');
/* 同源时不重复给出（3CE 商品页与官网同域名） */
const dup = G('SHADE_LINES.filter(l => { const a = shadeLinks({ lineObj:l }); return new Set(a.map(k => k.url)).size !== a.length; }).map(l => l.id)');
ok(dup.length === 0, '入口不重复（同域名不会出现两次）', dup.join(','));
/* 中国官网域名全部可识别为品牌官方站点 */
const cnSite = G('SHADE_BRANDS.map(b => b.site.replace(/^https:\\/\\//,"").split("/")[0])');
ok(cnSite.every(h => /yslbeautycn|maybellinechina|giorgioarmanibeauty|lorealparis|lancome|3cecosmetics/.test(h)),
   '六个品牌都配了官方站点入口（均已验证可达）', cnSite.join(','));
const overseas = G('SHADE_LINES.filter(l => { const a = shadeLinks({ lineObj:l }); return a.length > 1; }).map(l => l.id)');
ok(overseas.length >= 1, '海外站产品线自动补上国内入口（' + overseas.length + ' 条）');

const hosts = G('SHADE_LINES.filter(l => l.id !== "L26").map(l => l.url.replace(/^https:\\/\\//,"").split("/")[0])');
ok(new Set(hosts).size >= 5, '链接覆盖多个官方域名（' + new Set(hosts).size + ' 个）');
ok(hosts.every(h => /lancome|yslbeauty|maybelline|armanibeauty|3cecosmetics|lorealparis|tmall|search\.jd\.com/.test(h)),
   '全部域名都是品牌官方站点或官方店铺检索页', hosts.filter(h => !/lancome|yslbeauty|maybelline|armanibeauty|3cecosmetics|lorealparis|tmall|search\.jd\.com/.test(h)).join(','));
/* 本轮升级：三个薄弱链接换成精确商品页 */
ok(/superstay-matte-ink-liquid-lipstick/.test(G('SHADE_LINE_MAP.L05.url')), 'L05 美宝莲唇釉 → Super Stay Matte Ink 商品页');
ok(/search\.jd\.com/.test(G('SHADE_LINE_MAP.L11.url')), 'L11 欧莱雅白管 → 京东官方店铺检索（不再是官网首页）');
ok(/3ce-my-ring-eye-liner/.test(G('SHADE_LINE_MAP.L24.url')), 'L24 3CE 眼线 → My Ring Eye Liner 商品页');
ok(!/^https:\/\/(www\.)?lorealparis\.com\.cn\/$/.test(G('SHADE_LINE_MAP.L11.url')), 'L11 不再是官网首页');

/* ============ 5. 色号气泡 ============ */
console.log('\n【测试 5】悬停气泡（产品 + 商品页链接）');
G('showShadeTip(SHADE_MAP.S001, { getBoundingClientRect: () => ({ left:10, top:10, width:40, height:40 }) })');
const tipEl = G('_moodTip');
ok(!!tipEl, '气泡元素已创建');
const tip = tipEl ? tipEl.innerHTML : '';
ok(tip.indexOf('S001') >= 0, '气泡含色号 id');
ok(tip.indexOf(G('SHADE_MAP.S001.name')) >= 0, '气泡含色名');
ok(tip.indexOf('圣罗兰') >= 0, '气泡含品牌名');
ok(tip.indexOf('方管') >= 0, '气泡含产品线名');
ok(tip.indexOf(G('SHADE_MAP.S001.hex')) >= 0, '气泡含实测色值');
ok(tip.indexOf('PANTONE') < 0 && tip.toLowerCase().indexOf('pantone') < 0, '气泡不再含 Pantone（Prompt 第 4 条：删色值与取色原则）');
ok(tip.indexOf(G('SHADE_MAP.S001.poem').slice(0,10)) >= 0, '气泡改为展示「一句关于生命的诗」文案');
ok(tip.indexOf(G('SHADE_LINE_MAP.L01.url')) >= 0, '普通端气泡含官方商品页链接');
ok(tip.indexOf('target="_blank"') >= 0 && tip.indexOf('rel="noopener') >= 0, '链接为新窗口打开且带 noopener');
ok(!!tipEl && tipEl.classList.contains('interactive'), '带链接的气泡开启交互（可点击）');
ok(tip.indexOf('mood-link-alt') >= 0, '气泡同时含品牌中国官网入口（次选样式）');
ok(tip.indexOf(G('SHADE_BRAND_MAP.YSL.site')) >= 0, '气泡含品牌中国官网地址');
ok((tip.match(/target="_blank"/g) || []).length === 2, '两条入口均为新窗口打开');
ok(tip.indexOf('查看商品页') >= 0 && tip.indexOf('品牌官网') >= 0, '两条入口文案可区分');
/* 产品图 */
ok(tip.indexOf('mood-tip-img') >= 0, '气泡含产品图（mood-tip-img）');
ok(tip.indexOf('src="assets/shades/S001.png"') >= 0, '产品图路径指向该色号专属试色图');
ok(tip.indexOf('onerror') >= 0, '图片加载失败时自动隐藏（onerror 兜底）');
ok(tip.indexOf('mood-tip-flex') >= 0, '图片与说明左右布局');

/* 基础色气泡仍走原情绪文案，且不可交互 */
G('showMoodTip("P07", { getBoundingClientRect: () => ({left:0,top:0,width:10,height:10}) })');
const tip2 = G('_moodTip').innerHTML;
ok(tip2.indexOf('情绪') >= 0 && tip2.indexOf('P07') >= 0, '基础色仍弹出情绪说明');
ok(!!tipEl && !tipEl.classList.contains('interactive'), '纯情绪气泡不拦截鼠标事件');

/* ============ 6. 素材库渲染（色系 → 产品 两级分类） ============ */
console.log('\n【测试 6】颜色板块渲染');
set('familyFilter = "ALL"; colorSource = "lib"; chosenColors = [];');
G('renderLib()');
const allHtml = el('shadeGroups').innerHTML;
const countSw = (h) => (h.match(/class="shade-sw/g) || []).length;
ok(countSw(allHtml) === 134, '「全部」渲染出 134 个色块', countSw(allHtml));
const nFamBlocks = (allHtml.match(/class="fam-block"/g) || []).length;
const nFamUsed = G('SHADE_FAMILY_ORDER.filter(f => shadeCountOfFamily(f) > 0).length');
ok(nFamBlocks === nFamUsed, '一级色系分组数 = 有色号的色系数（' + nFamBlocks + '/' + nFamUsed + '）', nFamBlocks);
/* 产品分组跨色系会出现（同产品线的色号分属不同色系），动态计算期望值 */
const nGroups = G('SHADE_FAMILY_ORDER.reduce((n,f) => n + new Set((SHADE_BY_FAMILY[f]||[]).map(s => s.line)).size, 0)');
ok((allHtml.match(/class="shade-group"/g) || []).length === nGroups, '二级产品分组共 ' + nGroups + ' 个（跨色系累计）');
ok((allHtml.match(/class="sg-src"/g) || []).length === nGroups - G('SHADE_FAMILY_ORDER.filter(f => (SHADE_BY_FAMILY[f]||[]).some(s => s.line === "L26")).length'), '产品分组都有商品页链接（L26 基础色分组豁免）');
ok(allHtml.indexOf('data-no="S001"') >= 0 && allHtml.indexOf('id="sw-S001"') >= 0, '色块带上 data-no 与 id（悬停 / 选中依赖）');
ok(allHtml.indexOf('色系') >= 0, '色系标题渲染出来');
/* 一级筛选：色系 */
const nRed = G('shadeCountOfFamily("红")');
set('familyFilter = "红"');
G('renderLib()');
const redHtml = el('shadeGroups').innerHTML;
ok(countSw(redHtml) === nRed, '筛选「红」只剩红系色块（' + nRed + '）', countSw(redHtml));
ok((redHtml.match(/class="fam-block"/g) || []).length === 1, '筛选后只有一个色系分组');
/* 筛选后仍按产品二级分组 */
const redLines = G('new Set((SHADE_BY_FAMILY["红"]||[]).map(s => s.line)).size');
ok((redHtml.match(/class="shade-group"/g) || []).length === redLines, '红系内部按产品分组（' + redLines + ' 个产品）');
/* 每个色系块内的色块数 = 该色系色号数 */
const nBlue = G('shadeCountOfFamily("蓝")');
set('familyFilter = "蓝"');
G('renderLib()');
ok(countSw(el('shadeGroups').innerHTML) === nBlue, '筛选「蓝」为 ' + nBlue + ' 个色块', countSw(el('shadeGroups').innerHTML));
set('familyFilter = "ALL"');
G('renderLib()');
ok(el('libMeta').innerHTML.indexOf('134') >= 0, '顶部统计显示 134');

/* 选中态 */
set('chosenColors = ["S001","S060"]');
G('renderLib()');
ok((el('shadeGroups').innerHTML.match(/class="shade-sw sel"/g) || []).length === 2, '已选色号渲染出选中态');
ok(G('colorLabel("S001")').indexOf('S001') === 0, 'colorLabel 返回「id + 色名」');
ok(G('colorLabel("P02")') === 'P02', 'colorLabel 兼容基础色');

/* 已选区 */
set('chosenColors = []');
G('renderChosen()');
ok(el('chosenRow').innerHTML.indexOf('尚未选择') >= 0, '未选色时给出空态提示');
set('chosenColors = ["S001"]');
G('renderChosen()');
const cr = el('chosenRow').innerHTML;
ok(cr.indexOf('chosen-chip') >= 0 && cr.indexOf(G('SHADE_MAP.S001.hex')) >= 0, '已选区显示色块与色名');

/* bfChip 选中态（色系筛选） */
set('familyFilter = "橙"');
ok(G('bfChip("橙","橙",2)').indexOf('bf-chip on') >= 0, '当前色系筛选项高亮');
ok(G('bfChip("ALL","全部",113)').indexOf('bf-chip on') < 0, '非当前色系筛选项不高亮');

/* ============ 7. HTML 转义 ============ */
console.log('\n【测试 7】输出转义');
const evil = G('shadeSwatch({ id:"SX1", name:"<img src=x onerror=alert(1)>", hex:"#123456", pantone:"01-0001" })');
ok(evil.indexOf('<img') < 0 && evil.indexOf('&lt;img') >= 0, '色名中的 HTML 被转义');

/* ---------- 汇总 ---------- */
console.log('\n' + '='.repeat(46));
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('='.repeat(46));
process.exit(fail ? 1 : 0);
