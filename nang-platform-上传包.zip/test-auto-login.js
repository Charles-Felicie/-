/* 无浏览器回归测试：免登录直接进站
   从 user.html / common.js 抽取真实代码，在 vm 里跑完整的启动流程，
   验证「打开页面 → 自动建立本机演示身份 → 直接落在首页」这条链路。
   ============================================================ */
const fs = require('fs');
const vm = require('vm');

const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18/nang-platform';
const userSrc = fs.readFileSync(ROOT + '/user.html', 'utf8');
const commonSrc = fs.readFileSync(ROOT + '/assets/common.js', 'utf8');

/* ---------------- 抽取真实代码片段 ---------------- */
function extractFn(name){
  const start = userSrc.indexOf('function ' + name + '(');
  if(start < 0) throw new Error('未找到函数 ' + name);
  let i = userSrc.indexOf('{', start), depth = 0;
  for(let j = i; j < userSrc.length; j++){
    if(userSrc[j] === '{') depth++;
    else if(userSrc[j] === '}'){
      depth--;
      if(depth === 0) return userSrc.slice(start, j+1);
    }
  }
  throw new Error('函数未闭合 ' + name);
}
/* 抽取 IIFE：(function name(){ ... })(); */
function extractIIFE(name){
  const start = userSrc.indexOf('(function ' + name + '(){');
  if(start < 0) throw new Error('未找到 IIFE ' + name);
  let i = userSrc.indexOf('{', start), depth = 0;
  for(let j = i; j < userSrc.length; j++){
    if(userSrc[j] === '{') depth++;
    else if(userSrc[j] === '}'){
      depth--;
      if(depth === 0) return userSrc.slice(start, j+1) + ')();';
    }
  }
  throw new Error('IIFE 未闭合 ' + name);
}
function extractLine(re, label){
  const m = userSrc.match(re);
  if(!m) throw new Error('未找到 ' + label);
  return m[0];
}

const AUTO_LINE   = extractLine(/const AUTO_LOGIN = \w+;/, 'AUTO_LOGIN');
const DEMO_LINE   = extractLine(/const DEMO_USER = '[^']*';/, 'DEMO_USER');
const PATHS_LINE  = extractLine(/const PATHS = \[[\s\S]*?\];/, 'PATHS');
const STATE_LINE  = extractLine(/let authMode = 'login', currentUser = null;/, '登录态声明');
const RESTORE     = extractIIFE('restore');
const BOOT        = extractIIFE('boot');

const FNS = ['demoLogin','demoEnter','enterApp','go','hashDest','logout','doAuth','toggleAuthMode']
  .map(extractFn);

/* ---------------- DOM / 环境桩 ---------------- */
const CANVAS_CTX = new Proxy({}, {
  get(t, k){
    if(k === 'measureText') return () => ({ width: 10 });
    if(k === 'getImageData') return () => ({ data: new Uint8ClampedArray(4), width:1, height:1 });
    if(k === 'createLinearGradient' || k === 'createRadialGradient') return () => ({ addColorStop(){} });
    if(k === 'canvas') return null;
    return () => {};
  },
  set(){ return true; }
});

function mkEl(id){
  const cls = new Set();
  return {
    id, style:{}, dataset:{}, innerHTML:'', textContent:'', value:'', disabled:false, title:'',
    width:300, height:150, files:[], childNodes:[],
    classList:{
      add: c => cls.add(c),
      remove: c => cls.delete(c),
      toggle: (c, f) => { if(f === undefined){ cls.has(c) ? cls.delete(c) : cls.add(c); } else { f ? cls.add(c) : cls.delete(c); } },
      contains: c => cls.has(c),
      _all: () => Array.from(cls)
    },
    setAttribute(){}, removeAttribute(){}, getAttribute(){ return null; },
    addEventListener(){}, removeEventListener(){},
    appendChild(){}, removeChild(){}, insertBefore(){}, focus(){}, click(){},
    querySelectorAll(){ return []; }, querySelector(){ return null; },
    getBoundingClientRect(){ return { left:0, top:0, width:100, height:100, right:100, bottom:100 }; },
    getContext(){ return CANVAS_CTX; },
    toDataURL(){ return 'data:image/png;base64,'; },
    contains(){ return false; },
    scrollIntoView(){}
  };
}

function makeApp(opt){
  opt = opt || {};
  const els = {};
  const el = id => els[id] || (els[id] = mkEl(id));
  const lsStore = {};
  /* 预置存储：模拟「上次已登录，这次刷新页面」 */
  Object.keys(opt.seed || {}).forEach(k => { lsStore[k] = opt.seed[k]; });
  const localStorageStub = opt.throwOnSet
    ? { getItem(){ return null; }, setItem(){ throw new Error('QuotaExceededError'); } }
    : { getItem(k){ return Object.prototype.hasOwnProperty.call(lsStore, k) ? lsStore[k] : null; },
        setItem(k, v){ lsStore[k] = String(v); } };

  const documentStub = {
    addEventListener(){}, removeEventListener(){},
    querySelectorAll(){ return []; }, querySelector(){ return null; },
    getElementById: el, createElement: () => mkEl('new'),
    body: mkEl('body'), documentElement: mkEl('html')
  };
  const sandbox = {
    document: documentStub,
    window: { addEventListener(){}, removeEventListener(){}, innerWidth:1440, scrollTo(){}, open(){} },
    localStorage: localStorageStub,
    location: { hash: opt.hash || '' },
    console, Math, Date, JSON, Object, Array, String, Number, Boolean,
    parseInt, parseFloat, isNaN, Promise, setTimeout, clearTimeout, setInterval, clearInterval,
    requestAnimationFrame: fn => fn(), cancelAnimationFrame(){},
    Image: function(){ this.src=''; },
    Uint8ClampedArray, Blob: function(){}, URL: { createObjectURL(){ return ''; }, revokeObjectURL(){} },
    alert(){}, confirm(){ return true; }
  };
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;
  sandbox.$ = el;
  vm.createContext(sandbox);

  /* 真实共享库 */
  vm.runInContext(commonSrc, sandbox, { filename:'common.js' });

  /* 页面里的占位渲染函数（不影响启动链路判断） */
  vm.runInContext(`
    function renderMeMain(){} function renderMyWorks(){} function renderGallery(){}
    function renderChat(){} function renderColors(){} function enterCanvas(){}
    function enterPattern(){} function renderConfirm(){} function renderTryMoods(){}
    function renderCart(){} function renderFollows(){} function renderDonations(){}
    function renderHist(){} function renderMsgs(){} function toast(){}
    function applyI18n(){}   /* Boot 起手会按语言渲染一遍（真实版在框架段，此处桩化） */
    function navSeed(p){ navStack = [p]; navIdx = 0; }
    var navStack = [], navIdx = 0;
  `, sandbox, { filename:'stubs' });

  /* 真实声明与函数 */
  let code = [AUTO_LINE, DEMO_LINE, PATHS_LINE, STATE_LINE].join('\n');
  if(opt.autoLogin === false) code = code.replace('const AUTO_LOGIN = true;', 'const AUTO_LOGIN = false;');
  vm.runInContext(code.replace(/\b(const|let)\b/g, 'var'), sandbox, { filename:'decls' });
  vm.runInContext(RESTORE, sandbox, { filename:'restore' });
  FNS.forEach(fn => vm.runInContext(fn, sandbox, { filename: fn.slice(0, 24) }));

  return {
    G: expr => vm.runInContext(expr, sandbox),
    run: src => vm.runInContext(src, sandbox),
    el, boot: BOOT,
    activePage(){ return Object.keys(els).filter(k => k.indexOf('page-') === 0 && els[k].classList.contains('active')); },
    currentUser(){ return vm.runInContext('currentUser', sandbox); }
  };
}

/* ---------------- 断言工具 ---------------- */
let pass = 0, fail = 0;
function ok(cond, label, extra){
  if(cond){ pass++; console.log('  ✅ ' + label); }
  else{ fail++; console.log('  ❌ ' + label + (extra !== undefined ? '  → ' + extra : '')); }
}

/* ============ 测试 1：开关与常量 ============ */
console.log('\n【测试 1】免登录开关');
ok(/const AUTO_LOGIN = true;/.test(userSrc), 'AUTO_LOGIN 默认开启');
ok(/const DEMO_USER = '.+';/.test(userSrc), '存在演示身份常量');
ok(/\bif\(AUTO_LOGIN\)/.test(BOOT), '启动流程里读取了 AUTO_LOGIN');
ok(!/\bif\(currentUser\) enterApp\(\); else/.test(userSrc), '旧的「未登录就回登录页」启动写法已移除');

/* ============ 测试 2：默认启动即进站 ============ */
console.log('\n【测试 2】打开页面直接进站（无需登录）');
{
  const a = makeApp({});
  a.run(a.boot);
  ok(a.currentUser() === '访客演示', '自动建立演示身份 currentUser=访客演示', a.currentUser());
  ok(a.activePage().join(',') === 'page-home', '落在首页（不经过登录页）', a.activePage().join(','));
  ok(a.el('topnav').style.display === 'block', '顶部导航已展开');
  ok(a.G('location.hash') === '#/home', '地址栏 hash 同步为 #/home', a.G('location.hash'));
  ok(a.el('page-auth').classList.contains('active') === false, '登录页处于未激活状态');
  ok(a.G("getSession() && getSession().type === 'n'"), '登录态已写入会话');
  ok(a.G("!!getUsers('n')['访客演示']"), '演示身份已登记在本机用户表');
}

/* ============ 测试 3：地址栏带路由时直达该页 ============ */
console.log('\n【测试 3】带 hash 打开时直达对应页面');
{
  const a = makeApp({ hash:'#/paint/colors' });
  a.run(a.boot);
  ok(a.activePage().join(',') === 'page-paint-colors', '直达选色页', a.activePage().join(','));
  ok(a.currentUser() === '访客演示', '依然完成免登录进入');
}
{
  const a = makeApp({ hash:'#/auth' });
  a.run(a.boot);
  ok(a.activePage().join(',') === 'page-home', '#/auth 被忽略，落回首页（不再卡在登录页）', a.activePage().join(','));
}
{
  const a = makeApp({ hash:'#/不存在的页面' });
  a.run(a.boot);
  ok(a.activePage().join(',') === 'page-home', '非法路由回落首页', a.activePage().join(','));
}

/* ============ 测试 4：已有登录态优先沿用 ============ */
console.log('\n【测试 4】已有登录态时沿用原账号');
{
  const a = makeApp({ seed: {
    'wa_session': JSON.stringify({ type:'n', name:'小明' }),
    'wa_users_n': JSON.stringify({ '小明': { pass:'1', nickname:'小明' } })
  } });
  ok(a.currentUser() === '小明', '启动时从本机恢复已有登录态', String(a.currentUser()));
  a.run(a.boot);
  ok(a.currentUser() === '小明', '沿用已登录用户，不被演示身份覆盖', a.currentUser());
  ok(a.activePage().join(',') === 'page-home', '正常进站');
}

/* ============ 测试 5：关闭开关后恢复登录页 ============ */
console.log('\n【测试 5】AUTO_LOGIN=false 时恢复原流程');
{
  const a = makeApp({ autoLogin:false });
  a.run(a.boot);
  ok(a.currentUser() === null, '不自动建立身份', String(a.currentUser()));
  ok(a.activePage().join(',') === 'page-auth', '停在登录页', a.activePage().join(','));
  ok(a.G('location.hash') === '#/auth', 'hash 为 #/auth', a.G('location.hash'));
  ok(a.el('topnav').style.display !== 'block', '顶部导航保持隐藏');
}

/* ============ 测试 6：存储不可用时仍能进站 ============ */
console.log('\n【测试 6】localStorage 被禁用时的容错');
{
  const a = makeApp({ throwOnSet:true });
  let err = null;
  try{ a.run(a.boot); }catch(e){ err = e; }
  ok(err === null, '写入失败不抛出异常', err && err.message);
  ok(a.currentUser() === '访客演示', '仍完成免登录进入', a.currentUser());
  ok(a.activePage().join(',') === 'page-home', '仍正常渲染首页', a.activePage().join(','));
  ok(a.G("Store.get('memory_fallback_probe', 'default')") === 'default', '读取缺失键返回默认值');
}

/* ============ 测试 7：演示按钮与登出仍可用 ============ */
console.log('\n【测试 7】演示按钮 / 登出');
{
  const a = makeApp({});
  a.run(a.boot);
  a.run('demoEnter()');
  ok(a.activePage().join(',') === 'page-paint-colors', '登录页「演示模式」按钮直达选色页', a.activePage().join(','));
  a.run('logout()');
  ok(a.currentUser() === null, '登出后清空身份');
  ok(a.activePage().join(',') === 'page-auth', '登出后回到登录页', a.activePage().join(','));
  ok(a.el('topnav').style.display === 'none', '登出后隐藏顶部导航');
}

/* ============ 测试 8：原有注册 / 登录逻辑未被破坏 ============ */
console.log('\n【测试 8】原注册 / 登录逻辑完好');
{
  const a = makeApp({ autoLogin:false });
  a.run(a.boot);
  ok(/\bif\(authMode === 'register'\)/.test(userSrc), '注册分支保留');
  ok(/users\[u\]\.pass !== p/.test(userSrc), '密码校验分支保留');
  ok(/该用户名已被登记/.test(userSrc), '重名提示保留');
  a.run("$('authUser').value='新用户'; $('authPass').value='pw'; authMode='register'; doAuth();");
  ok(!!a.G("getUsers('n')['新用户']"), '注册流程可正常写入用户');
  a.run("$('authUser').value='新用户'; $('authPass').value='bad'; authMode='login'; doAuth();");
  ok(a.currentUser() === null, '密码错误时拒绝登录', String(a.currentUser()));
  a.run("$('authUser').value='新用户'; $('authPass').value='pw'; authMode='login'; doAuth();");
  ok(a.currentUser() === '新用户', '密码正确时登录成功并进站', a.currentUser());
  ok(a.activePage().join(',') === 'page-home', '登录成功后进入首页', a.activePage().join(','));
}

/* ============ 测试 9：页面上的入口按钮存在 ============ */
console.log('\n【测试 9】登录页入口');
ok(userSrc.indexOf('演示模式 · 一键进入') >= 0, '登录页保留「演示模式 · 一键进入」按钮');
ok(/onclick="demoEnter\(\)"/.test(userSrc), '按钮正确绑定 demoEnter');
ok(userSrc.indexOf('自动进入') >= 0, '文案提示已按免登录更新');

console.log('\n════════════════════════════');
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('════════════════════════════\n');
process.exit(fail ? 1 : 0);
