/* 静态交叉校验：DOM id 引用 + onclick 函数定义 */
const fs = require('fs');
const ROOT = 'C:/Users/Lenovo/WorkBuddy/2026-09-23-23-16-18/nang-platform';

let pass = 0, fail = 0;
const ok = (c, label, extra) => {
  if(c){ pass++; console.log('  ✅ ' + label); }
  else{ fail++; console.log('  ❌ ' + label + (extra !== undefined ? '  → ' + extra : '')); }
};

const common = fs.readFileSync(ROOT + '/assets/common.js', 'utf8');

['user.html','charity.html','admin.html','index.html'].forEach(file => {
  const s = fs.readFileSync(ROOT + '/' + file, 'utf8');
  const inline = (s.match(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/) || ['',''])[1];

  console.log('\n【' + file + '】');

  /* 1. JS 里 $('id') 引用的元素必须存在 */
  const ids = new Set([...s.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
  const used = new Set([...inline.matchAll(/\$\('([^']+)'\)/g)].map(m => m[1]));
  const dynamic = new Set(['toast','modalMask',
    /* 选色板已移除（由命运色轮取代），JS 里保留防御性引用 */ 'libWrap','baseWrap','libMeta','shadeGroups','chosenRow','brandFilter','colorsPalette','recommendRow']);   /* 运行时动态创建 */
  const missingIds = [...used].filter(x => !ids.has(x) && !dynamic.has(x));
  ok(missingIds.length === 0, '$() 引用的 ' + used.size + ' 个元素 id 全部存在', missingIds.join(', '));

  /* 2. getElementById 同样检查 */
  const gids = new Set([...inline.matchAll(/getElementById\('([^']+)'\)/g)].map(m => m[1]));
  const missingG = [...gids].filter(x => !ids.has(x) && !dynamic.has(x) && !x.startsWith('sw-') && !x.startsWith('cp-') && !x.startsWith('tm-') && !x.startsWith('reply-'));
  ok(missingG.length === 0, 'getElementById 引用全部存在', missingG.join(', '));

  /* 3. HTML onclick / oninput 调用的函数必须有定义 */
  const called = new Set();
  [...s.matchAll(/\bon(?:click|input|change|submit)="([a-zA-Z_$][\w$]*)\s*\(/g)]
    .forEach(m => called.add(m[1]));
  const defined = new Set(
    [...(inline + common).matchAll(/function\s+([a-zA-Z_$][\w$]*)\s*\(/g)].map(m => m[1])
  );
  [...(inline + common).matchAll(/\bvar\s+([a-zA-Z_$][\w$]*)\s*=\s*(?:function|\()/g)].forEach(m => defined.add(m[1]));
  [...(inline + common).matchAll(/\b(?:const|let|var)\s+([a-zA-Z_$][\w$]*)\s*=\s*(?:async\s*)?\(?[^)]*\)?\s*=>/g)].forEach(m => defined.add(m[1]));
  /* 浏览器内置 */
  ['location','alert','confirm','prompt'].forEach(x => defined.add(x));
  const lastSegment = [...called].map(c => c);
  const undef = lastSegment.filter(c => !defined.has(c));
  ok(undef.length === 0, 'onclick/oninput 调用的 ' + called.size + ' 个函数全部有定义', undef.join(', '));

  /* 4. 本文件声明的函数没有被重复定义 */
  const fnNames = [...inline.matchAll(/function\s+([a-zA-Z_$][\w$]*)\s*\(/g)].map(m => m[1]);
  const dup = fnNames.filter((n, i) => fnNames.indexOf(n) !== i);
  ok(dup.length === 0, '无重复函数定义', [...new Set(dup)].join(', '));

  /* 5. 每个 page div 都有对应的路由（user.html 用 PATHS，charity/admin 用 PAGES） */
  const pageIds = [...s.matchAll(/class="page"\s+id="page-([^"]+)"/g)].map(m => m[1]);
  const listSrc = (inline.match(/const (?:PATHS|PAGES) = \[([\s\S]*?)\];/) || [,''])[1];
  if(!listSrc) { ok(true, '（该页不使用 PATHS/PAGES 路由，跳过）'); }
  else {
    const paths = [...listSrc.matchAll(/'([^']+)'/g)].map(m => m[1]).map(p => p.replace(/\//g,'-'));
    const orphan = pageIds.filter(p => !paths.includes(p));
    ok(orphan.length === 0, pageIds.length + ' 个 page 区块都有对应路由', orphan.join(', '));
  }
});

/* ---------------- user.html 的美妆作画专属校验 ---------------- */
console.log('\n【美妆作画板块专项】');
const u = fs.readFileSync(ROOT + '/user.html', 'utf8');
const cu = common;

/* 5 支笔 + 橡皮的定义都齐全 */
const brushIds = ['matte','glaze','blush','liner','gel','eraser'];
brushIds.forEach(id => ok(cu.includes("id:'" + id + "'"), '笔刷已定义：' + id));

/* 颜色气泡三要素 */
ok(/emotion:/.test(cu) && /imagery:/.test(cu) && /atmosphere:/.test(cu), '颜色气泡含 情绪/意象/氛围 三要素');
ok(/mouseover/.test(cu) && /touchstart/.test(cu), '气泡同时绑定 鼠标悬停 与 触摸');
ok(/positionMoodTip/.test(cu), '气泡定位函数存在（自动上下翻转避让）');

/* 纹样化能力 */
ok(/function patScan/.test(u), '纹样化：扫描作品');
ok(/function patDuplicate/.test(u), '纹样化：复制元件');
ok(/function patSelScale/.test(u) && /function patSpread/.test(u), '纹样化：调整大小');
ok(/function patSelRotate/.test(u), '纹样化：旋转元件');
ok(/function patExport/.test(u), '纹样化：导出 PNG');
ok(/'grid'/.test(u) && /'offset'/.test(u) && /'mirror'/.test(u), '纹样化：网格/半错位/镜像 三种平铺');
ok(/'scarf'/.test(u) && /'mask'/.test(u), '纹样化：头巾 / 口罩 面料预览');

/* 笔刷工具栏与橡皮入口 */
ok(/id="brushBar"/.test(u), '笔刷工具栏容器存在');
ok(/id="brushSize"/.test(u), '笔刷大小滑块存在');
ok(/undoPaint\(\)/.test(u), '撤销按钮存在');

/* 数据键名沿用团队规范 */
ok(/wa_/.test(cu) && /nnj_|draft_|pattern_/.test(u), '存储键名沿用 wa_ / draft_ / pattern_ 规范');

console.log('\n════════════════════════════');
console.log('  通过 ' + pass + ' 项，失败 ' + fail + ' 项');
console.log('════════════════════════════');
process.exit(fail ? 1 : 0);
